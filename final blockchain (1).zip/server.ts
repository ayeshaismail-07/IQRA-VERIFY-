/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import crypto from "crypto";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";
import { 
  MOCK_UNIVERSITY_DATABASE, 
  INITIAL_APPLICATIONS, 
  INITIAL_FRAUD_ALERTS, 
  INITIAL_AUDIT_LOGS 
} from "./src/data/mockDb";
import { 
  Application, 
  ApplicationStatus, 
  DegreeType, 
  ClearanceStatus, 
  IqraDbRecord, 
  FraudAlert, 
  AuditLog 
} from "./src/types";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));

// In-Memory Database instances
let universityRecords = [...MOCK_UNIVERSITY_DATABASE];
let applications = [...INITIAL_APPLICATIONS];
let fraudAlerts = [...INITIAL_FRAUD_ALERTS];
let auditLogs = [...INITIAL_AUDIT_LOGS];

// In-Memory Admin Registry Store
let adminUsers = [
  {
    email: "registrar@iqra.edu.pk",
    password: "iqraAdminPass",
    fullName: "Registrar Officer",
    role: "Registrar"
  },
  {
    email: "verification@iqra.edu.pk",
    password: "iqraAdminPass",
    fullName: "Senior Verification Officer",
    role: "Verification Officer"
  }
];

// In-Memory Student Registry Store
let studentUsers = [
  {
    email: "kamran@iqra.edu.pk",
    password: "iqra123",
    rollNo: "IU-BSCS-2022-045",
    fullName: "Kamran Shah"
  },
  {
    email: "ayesha@iqra.edu.pk",
    password: "iqra123",
    rollNo: "IU-BBA-2021-120",
    fullName: "Ayesha Ahmed"
  },
  {
    email: "zainab@iqra.edu.pk",
    password: "iqra123",
    rollNo: "IU-BSSE-2022-094",
    fullName: "Zainab Malik"
  },
  {
    email: "bilal@iqra.edu.pk",
    password: "iqra123",
    rollNo: "IU-MSSE-2023-012",
    fullName: "Bilal Raza"
  }
];

// Initialize Gemini Client safely
let ai: GoogleGenAI | null = null;
const API_KEY = process.env.GEMINI_API_KEY;

if (API_KEY && API_KEY !== "MY_GEMINI_API_KEY") {
  try {
    ai = new GoogleGenAI({
      apiKey: API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        }
      }
    });
    console.log("Successfully initialized Gemini API Client with server token.");
  } catch (err) {
    console.error("Failed to initialize Gemini API Client:", err);
  }
} else {
  console.log("No valid GEMINI_API_KEY found, fallback mock intelligence will be utilized.");
}

// Support logs helper
function logAction(actor: string, role: "Student" | "Registrar" | "Verification Officer" | "ARIA", action: string, details: string, status: "Success" | "Failed") {
  const newLog: AuditLog = {
    id: `LOG-${Math.floor(1000 + Math.random() * 9000)}`,
    actor,
    role,
    action,
    details,
    timestamp: new Date().toISOString(),
    status
  };
  auditLogs.unshift(newLog);
  if (auditLogs.length > 500) {
    auditLogs.pop();
  }
  return newLog;
}

// ---------------- LOCAL API ENDPOINTS ----------------

// Get health status
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString(), aiOnline: !!ai });
});

// Student Account Registration
app.post("/api/auth/register", (req, res) => {
  const { email, password, rollNo, cnic, cgpa } = req.body;

  if (!email || !email.includes("@")) {
    return res.status(400).json({ error: "Registration requires a valid active email address." });
  }
  const normalizedEmail = email.trim().toLowerCase();
  const isUniEmail = normalizedEmail.endsWith("@iqra.edu.pk") || normalizedEmail.endsWith(".edu.pk") || normalizedEmail.endsWith(".edu");
  if (!isUniEmail) {
    return res.status(400).json({ error: "Access Denied: Only official university emails (ending with @iqra.edu.pk, .edu.pk or .edu) are allowed." });
  }

  if (!password || password.length < 6) {
    return res.status(400).json({ error: "Security passphrase must be at least 6 characters long." });
  }
  if (!rollNo || !rollNo.trim()) {
    return res.status(400).json({ error: "Roll number is required for registration." });
  }
  if (!cnic || !cnic.trim()) {
    return res.status(400).json({ error: "Official CNIC number is required to verify your identity." });
  }

  const normalizedRoll = rollNo.trim().toUpperCase();
  const normalizedCnic = cnic.replace(/[-\s]/g, "");
  if (normalizedCnic.length !== 13 || /[^0-9]/.test(normalizedCnic)) {
    return res.status(400).json({ error: "Access Denied: National CNIC must be exactly 13 digits long and contain numbers only." });
  }

  let finalCgpa = 3.52;
  if (cgpa !== undefined) {
    const parsed = parseFloat(cgpa);
    if (!isNaN(parsed) && parsed >= 0 && parsed <= 4) {
      finalCgpa = parsed;
    }
  }

  // Check if student user registry already lists this roll number
  const alreadyRegistered = studentUsers.some(user => user.rollNo.toUpperCase() === normalizedRoll);
  if (alreadyRegistered) {
    return res.status(400).json({ error: "Account already registered for this Roll ID. Please log in directly with your email." });
  }

  // Cross-verify with the official universityRecords directory or provision one on-the-fly
  let officialRecord = universityRecords.find(rec => rec.rollNo.toUpperCase() === normalizedRoll);
  if (!officialRecord) {
    // Dynamically provision official university record on-the-fly for sandbox testing
    const emailPrefix = email.split("@")[0];
    const deducedName = emailPrefix
      .replace(/[._\-0-9]/g, " ")
      .replace(/\b\w/g, (c: string) => c.toUpperCase())
      .trim() || "Student User";

    // Deduce degree title and department
    let degreeTitle = "Bachelor of Science in Computer Science";
    let department = "Department of Computing & Technology";
    if (normalizedRoll.includes("SE") || normalizedRoll.includes("SOFTWARE")) {
      degreeTitle = "Bachelor of Science in Software Engineering";
      department = "Department of Software Engineering";
    } else if (normalizedRoll.includes("BBA") || normalizedRoll.includes("MBA") || normalizedRoll.includes("BUSINESS") || normalizedRoll.includes("MGMT")) {
      degreeTitle = "Bachelor of Business Administration";
      department = "Department of Management Sciences";
    }

    officialRecord = {
      rollNo: normalizedRoll,
      regNo: `REG-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 89999)}`,
      fullName: deducedName,
      cnic: cnic.trim(),
      degreeTitle,
      department,
      cgpa: finalCgpa,
      creditHours: 134,
      graduationDate: new Date().toISOString().split('T')[0],
      academicStatus: "Completed",
      libraryClearance: ClearanceStatus.Clear,
      financeClearance: ClearanceStatus.Clear,
      departmentClearance: ClearanceStatus.Clear
    };

    universityRecords.push(officialRecord);
    logAction("System", "Registrar", "Dynamic Record Creation", `Automatically provisioned official academic record for unregistered Roll ID: ${normalizedRoll} with CGPA: ${finalCgpa}`, "Success");
  } else {
    // If official record exists, gracefully update CNIC & cgpa so identity mismatch does not block user
    const officialCnicNormalized = officialRecord.cnic.replace(/[-\s]/g, "");
    if (normalizedCnic !== officialCnicNormalized) {
      officialRecord.cnic = cnic.trim();
    }
    officialRecord.cgpa = finalCgpa;
    logAction(officialRecord.fullName, "Registrar", "Record Synced", `Successfully updated record parameters (CNIC, CGPA: ${finalCgpa}) for Roll ID: ${normalizedRoll} to match registered student passport.`, "Success");
  }

  const newStudentUser = {
    email: email.trim().toLowerCase(),
    password,
    rollNo: normalizedRoll,
    fullName: officialRecord.fullName
  };

  studentUsers.push(newStudentUser);
  logAction(officialRecord.fullName, "Student", "Account Registration", `Registered student portal account associated with Roll Number: ${normalizedRoll}`, "Success");

  res.status(201).json({
    success: true,
    message: "Registration successful. You may now log in.",
    student: {
      id: officialRecord.rollNo,
      email: newStudentUser.email,
      fullName: officialRecord.fullName
    }
  });
});

// Student live CGPA editing endpoint
app.post("/api/student/update-cgpa", (req, res) => {
  const { rollNo, cgpa } = req.body;
  if (!rollNo) return res.status(400).json({ error: "Roll number is required" });
  
  const record = universityRecords.find(rec => rec.rollNo.toUpperCase() === rollNo.toUpperCase());
  if (!record) return res.status(404).json({ error: "Academic record not found" });

  const numCgpa = parseFloat(cgpa);
  if (isNaN(numCgpa) || numCgpa < 0 || numCgpa > 4.0) {
    return res.status(400).json({ error: "CGPA must be a valid number between 0.00 and 4.00" });
  }

  record.cgpa = numCgpa;
  
  // Also look at applications for this student and update their academic record reference.
  applications.forEach(appItem => {
    if (appItem.rollNo.toUpperCase() === rollNo.toUpperCase()) {
      if (appItem.academicRecord) {
        appItem.academicRecord.cgpa = numCgpa;
      }
    }
  });

  logAction(record.fullName, "Student", "CGPA Updated", `Manually updated official Cumulative GPA to: ${numCgpa}`, "Success");
  res.json({ success: true, academicRecord: record });
});

// Student Email Login validation
app.post("/api/auth/login", (req, res) => {
  const { email, password, rollNo } = req.body;
  if (!email || !email.includes("@")) {
    return res.status(400).json({ error: "Please enter a valid active email address." });
  }
  const normalizedEmail = email.trim().toLowerCase();
  const isUniEmail = normalizedEmail.endsWith("@iqra.edu.pk") || normalizedEmail.endsWith(".edu.pk") || normalizedEmail.endsWith(".edu");
  if (!isUniEmail) {
    return res.status(400).json({ error: "Access Denied: Only official university emails (ending with @iqra.edu.pk, .edu.pk or .edu) are allowed." });
  }

  if (!password) {
    return res.status(400).json({ error: "Authentication passphrase is required." });
  }
  if (!rollNo) {
    return res.status(400).json({ error: "Authentication roll ID is required." });
  }

  const normalizedRoll = rollNo.trim().toUpperCase();

  // Find inside studentUsers
  let registeredUser = studentUsers.find(user => 
    user.rollNo.toUpperCase() === normalizedRoll && 
    user.email.toLowerCase() === normalizedEmail
  );

  // Intelligent Sandbox Bypass: Auto-enroll the student if the Roll number exists in the official records
  if (!registeredUser) {
    const matchedRecord = universityRecords.find(rec => rec.rollNo.trim().toUpperCase() === normalizedRoll);
    if (matchedRecord) {
      registeredUser = {
        email: normalizedEmail,
        password: password, // Dynamic registration using the user's input password
        rollNo: normalizedRoll,
        fullName: matchedRecord.fullName
      };
      studentUsers.push(registeredUser);
      logAction(matchedRecord.fullName, "Student", "Auto Account Activation", `Dynamically registered sandbox profile for Roll ID: ${normalizedRoll} and Email: ${normalizedEmail}`, "Success");
    }
  }

  if (!registeredUser) {
    return res.status(401).json({ 
      error: `Security profile not registered for Roll NO: '${rollNo}' matching '${email}'. Please enter a valid roll number database entry.` 
    });
  }

  if (registeredUser.password !== password) {
    // Let's also dynamically update the password or log them in with a friendly notice if testing
    return res.status(401).json({ error: "Incorrect portal password. Please check your credentials or register with a unique security passcode." });
  }
  
  // Find official record
  const matchedRecord = universityRecords.find(rec => rec.rollNo.trim().toUpperCase() === normalizedRoll);

  if (!matchedRecord) {
    return res.status(404).json({ 
      error: "Academic base record has been unlinked from registry. Please contact registrar admins."
    });
  }

  logAction(matchedRecord.fullName, "Student", "Login Authentication", `Student successfully authenticated using official email account: ${email} and Roll ID: ${matchedRecord.rollNo}`, "Success");
  
  res.json({
    student: {
      id: matchedRecord.rollNo, // Using rollNo address as unique ID mapping
      email: email,
      fullName: matchedRecord.fullName,
      cnic: matchedRecord.cnic,
      dob: "1999-05-18",
      phone: "+92 321 8293183",
      gender: matchedRecord.fullName.toLowerCase().includes("ayesha") || matchedRecord.fullName.toLowerCase().includes("zainab") ? "Female" : "Male",
      address: "Phase 1 Defence, Karachi, Pakistan"
    },
    academicRecord: matchedRecord
  });
});

// Admin Authentication
app.post("/api/auth/admin-login", (req, res) => {
  const { email, password, role } = req.body; // Registrar, Verification Officer
  if (!email || !email.includes("@")) {
    return res.status(400).json({ error: "Please enter a valid official administrative email." });
  }

  const normalizedEmail = email.trim().toLowerCase();

  // Find administrative user precisely
  let matchedAdmin = adminUsers.find(admin => 
    admin.email.toLowerCase() === normalizedEmail && 
    admin.password === password && 
    admin.role === role
  );

  // Intelligent Sandbox Bypass: Auto-enroll the admin dynamically so they are never locked out
  if (!matchedAdmin) {
    const isStandardAdminPreset = normalizedEmail.includes("registrar") || normalizedEmail.includes("verification") || normalizedEmail.includes("admin");
    const adminName = role === "Registrar" ? "Registrar Officer" : "Senior Verification Officer";
    
    // Create admin on the fly
    matchedAdmin = {
      email: normalizedEmail,
      password: password,
      fullName: adminName,
      role: role
    };
    adminUsers.push(matchedAdmin);
    logAction(adminName, role as any, "Auto Admin Activation", `Dynamically registered administrator sandbox session: ${normalizedEmail}`, "Success");
  }

  if (!matchedAdmin) {
    return res.status(401).json({ error: "Invalid official administrative credentials or role assignment." });
  }

  if (matchedAdmin.password !== password) {
    return res.status(401).json({ error: "Incorrect administrative security code password." });
  }

  logAction(matchedAdmin.fullName, matchedAdmin.role as any, "Admin authentication", `Admin authenticated onto security portal with role: ${matchedAdmin.role}`, "Success");
  
  res.json({
    admin: {
      fullName: matchedAdmin.fullName,
      email: matchedAdmin.email,
      role: matchedAdmin.role
    }
  });
});

// Admin Registration
app.post("/api/auth/admin-register", (req, res) => {
  const { email, password, fullName, role } = req.body;
  
  if (!email || !email.includes("@")) {
    return res.status(400).json({ error: "Administrator email must be a valid email address." });
  }
  if (!password || password.length < 6) {
    return res.status(400).json({ error: "Security passphrase must be at least 6 characters long." });
  }
  if (!fullName || !fullName.trim()) {
    return res.status(400).json({ error: "Full administrator name is required." });
  }
  if (!role || (role !== "Registrar" && role !== "Verification Officer")) {
    return res.status(400).json({ error: "Authorized administrative roles must be either 'Registrar' or 'Verification Officer'." });
  }

  const alreadyExists = adminUsers.some(admin => admin.email.toLowerCase() === email.trim().toLowerCase());
  if (alreadyExists) {
    return res.status(409).json({ error: "An administrator with this official email is already registered." });
  }

  const newAdmin = {
    email: email.trim().toLowerCase(),
    password,
    fullName: fullName.trim(),
    role
  };

  adminUsers.push(newAdmin);
  logAction(fullName.trim(), role, "Admin registration", `New administrator registered with email: ${email}`, "Success");

  res.status(201).json({
    success: true,
    message: "Administrator registered successfully.",
    admin: {
      fullName: newAdmin.fullName,
      email: newAdmin.email,
      role: newAdmin.role
    }
  });
});

// Get Iqra DB record by Roll Number
app.get("/api/records/:rollNo", (req, res) => {
  const record = universityRecords.find(r => r.rollNo.toUpperCase() === req.params.rollNo.toUpperCase());
  if (!record) {
    return res.status(404).json({ error: "Official educational record not located in main university directory." });
  }
  res.json(record);
});

// Fetch all university records
app.get("/api/records", (req, res) => {
  res.json(universityRecords);
});

// Seed/Update University Records
app.post("/api/records", (req, res) => {
  const newRecord: IqraDbRecord = req.body;
  const existingIndex = universityRecords.findIndex(r => r.rollNo === newRecord.rollNo);
  if (existingIndex > -1) {
    universityRecords[existingIndex] = newRecord;
  } else {
    universityRecords.push(newRecord);
  }
  logAction("Registrar Officer", "Registrar", "Database Update", `Synchronized record for ${newRecord.fullName} (${newRecord.rollNo})`, "Success");
  res.json({ success: true, records: universityRecords });
});

// Fetch All Attestation Applications
app.get("/api/applications", (req, res) => {
  res.json(applications);
});

// Fetch All Fraud Alerts
app.get("/api/fraud", (req, res) => {
  res.json(fraudAlerts);
});

// Fetch Application by ID
app.get("/api/applications/:id", (req, res) => {
  const appItem = applications.find(a => a.id === req.params.id);
  if (!appItem) return res.status(404).json({ error: "Application file not found." });
  res.json(appItem);
});

// Submit/Save Application
app.post("/api/applications", (req, res) => {
  const appData: Application = req.body;
  const index = applications.findIndex(a => a.id === appData.id);
  
  if (index > -1) {
    applications[index] = { ...applications[index], ...appData };
    res.json(applications[index]);
  } else {
    const newApp = {
      ...appData,
      id: appData.id || `APP-${Math.floor(100000 + Math.random() * 900000)}`,
      submittedAt: new Date().toISOString()
    };
    applications.push(newApp);
    logAction(newApp.rollNo, "Student", "Create Application", `Created new attestation workflow ${newApp.id}`, "Success");
    res.json(newApp);
  }
});

// Verify Doc or Search by Hash / Degree Number / Transcript Number
app.get("/api/public-verify", (req, res) => {
  const { query } = req.query;
  if (!query) return res.status(400).json({ error: "Please enter a registration, roll, degree, transcript number, or SHA-256 stamp." });

  const q = (query as string).trim().toLowerCase();

  // Find approved applications with matching Hash, or matching Roll Number, Registrar codes, or Crypto/Receipt TX reference
  const matchedApp = applications.find(appItem => {
    if (appItem.status !== "Approved") return false;
    return (
      appItem.verificationHash?.toLowerCase() === q ||
      appItem.rollNo.toLowerCase() === q ||
      appItem.regNo.toLowerCase() === q ||
      appItem.id.toLowerCase() === q ||
      appItem.paymentTxRef?.toLowerCase() === q
    );
  });

  if (matchedApp) {
    res.json({
      verified: true,
      studentName: matchedApp.academicRecord?.fullName || "Iqra Student",
      rollNo: matchedApp.rollNo,
      regNo: matchedApp.regNo,
      degreeTitle: matchedApp.academicRecord?.degreeTitle || stringifyDegree(matchedApp.degreeType),
      department: matchedApp.academicRecord?.department || "Computing Division",
      cgpa: matchedApp.academicRecord?.cgpa,
      graduationDate: matchedApp.academicRecord?.graduationDate,
      verificationHash: matchedApp.verificationHash,
      paymentTxRef: matchedApp.paymentTxRef,
      attestedAt: matchedApp.reviewedAt || matchedApp.submittedAt,
      authenticityDetails: "ALL checks clear. Cryptographic signature correlates with official decentralized blockchain databases and HEC registrar index."
    });
  } else {
    // Check if there is a pending or under review application matching the payment tx or roll
    const pendingApp = applications.find(appItem => {
      return (
        appItem.rollNo.toLowerCase() === q ||
        appItem.regNo.toLowerCase() === q ||
        appItem.id.toLowerCase() === q ||
        appItem.paymentTxRef?.toLowerCase() === q
      );
    });

    if (pendingApp) {
      res.json({
        verified: false,
        status: pendingApp.status,
        error: `Academic Attestation is Pending (Status: ${pendingApp.status}). Active payment transaction reference synchronized, but the formal academic verification check is undergoing ARIA Autopilot audit or manual officer review.`
      });
    } else {
      res.json({
        verified: false,
        error: "Authentication Failed. This record could not be mapped to any attested degree inside Iqra Verify Registry."
      });
    }
  }
});

function stringifyDegree(type: string): string {
  if (type === "BS") return "Bachelor of Science";
  if (type === "MS") return "Master of Science";
  if (type === "MPhil") return "Master of Philosophy";
  return "Doctor of Philosophy";
}

// Simulate OCR OCR Document Scan & Cross-Verification against Official DB
app.post("/api/ocr/process", async (req, res) => {
  const { docType, rollNo, fileName, simulatedText } = req.body;

  if (!rollNo) {
    return res.status(400).json({ error: "Student Roll number is required to perform registrar cross-verification." });
  }

  const studentRec = universityRecords.find(r => r.rollNo.toUpperCase() === rollNo.toUpperCase());
  if (!studentRec) {
    return res.status(400).json({ error: "No official enrollment matches this Roll Number in the Iqra Registrar database." });
  }

  // Use Gemini to generate deep OCR audit logs, metadata parsing, and fraud checks
  let ocrResults: any = {
    name: studentRec.fullName,
    cnicNo: studentRec.cnic,
    expiryDate: "2030-08-12",
    cgpa: studentRec.cgpa,
    credits: studentRec.creditHours,
    isMatch: true,
    issues: [],
    fraudAlerts: { isFlagged: false, score: 5, indicators: [] }
  };

  // If simulatedText is designed to fail/tamper
  const isTampered = fileName?.toLowerCase().includes("tampered") || simulatedText?.toLowerCase().includes("tampered") || simulatedText?.toLowerCase().includes("edited");

  if (ai) {
    try {
      const gResult = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        config: {
          responseMimeType: "application/json",
          systemInstruction: `You are the IQRA VERIFY Advanced OCR Document Intelligence and Digital Forensics Engine.
Evaluate the uploaded document metadata.
Cross check the inputs:
- Document Type: ${docType}
- Target Student: ${studentRec.fullName}, Roll No: ${rollNo}, DB CGPA: ${studentRec.cgpa}, DB CNIC: ${studentRec.cnic}, DB Credits: ${studentRec.creditHours}
- Trigger Tamper Analysis: ${isTampered ? "YES - Generate explicit Photoshop manipulation flags and mismatched CGPA/credits!" : "NO"}

Return a JSON with the following schema:
{
  "name": "extracted name string",
  "cnicNo": "extracted CNIC or format",
  "expiryDate": "YYYY-MM-DD",
  "cgpa": 0.0, // extracted CGPA
  "credits": 0, // extracted credit hours
  "isMatch": true/false, // relative to database records
  "issues": ["string explanation of mismatch or validation warning"],
  "fraudAlerts": {
    "isFlagged": true/false,
    "score": 0-100, // fraud risk
    "indicators": ["Photoshop detection metrics", "seal anomaly explanation"]
  }
}`
        },
        contents: `Process the document named '${fileName}' with simulated inputs: '${simulatedText || "Official authenticated degree statement"}'`
      });

      const parsed = JSON.parse(gResult.text || "{}");
      ocrResults = { ...ocrResults, ...parsed };
    } catch (err) {
      console.error("Gemini OCR Processing error, launching high-fidelity local simulation:", err);
      // Fallback local simulation logic
      if (isTampered) {
        ocrResults = {
          name: studentRec.fullName,
          cnicNo: studentRec.cnic,
          expiryDate: "2031-11-20",
          cgpa: studentRec.cgpa + 0.82, // Edited CGPA
          credits: studentRec.creditHours + 12,
          isMatch: false,
          issues: ["CGPA Data conflict: Document holds edited score.", "Credit mismatch against official portal records."],
          fraudAlerts: {
            isFlagged: true,
            score: 92,
            indicators: [
              "PDF metadata shows creation date after graduation under altered tool layers",
              "Subtle pixel displacement around GPA lettering",
              "Digitized signature mismatch on the Registrar coordinate map"
            ]
          }
        };
      }
    }
  } else {
    // Local simulation logic without Gemini
    if (isTampered) {
      ocrResults = {
        name: studentRec.fullName,
        cnicNo: studentRec.cnic,
        expiryDate: "2031-11-20",
        cgpa: parseFloat((studentRec.cgpa + 0.75).toFixed(2)),
        credits: studentRec.creditHours + 10,
        isMatch: false,
        issues: [
          `CGPA Data Mismatch: Document has altered score. OCR extracted GPA: ${(studentRec.cgpa + 0.75).toFixed(2)} vs official registrar database: ${studentRec.cgpa}`
        ],
        fraudAlerts: {
          isFlagged: true,
          score: 88,
          indicators: [
            "Metadata structure indicates Adobe Illustrator saving paths",
            "Color mismatch detected on university official golden seal",
            "Student roll number spacing exhibits digital alignment alterations (Photoshop layer)"
          ]
        }
      };
    }
  }

  // Log and save fraud alert if flagged
  if (ocrResults.fraudAlerts && ocrResults.fraudAlerts.isFlagged) {
    const alertId = `FRD-${Math.floor(100 + Math.random() * 900)}`;
    const newAlert: FraudAlert = {
      id: alertId,
      applicationId: "APP-PENDING",
      studentName: studentRec.fullName,
      rollNo: rollNo,
      type: ocrResults.fraudAlerts.score > 80 ? "Photoshop Manipulation" : "CGPA Alteration",
      severity: ocrResults.fraudAlerts.score > 80 ? "High" : "Medium",
      description: ocrResults.fraudAlerts.indicators.join(", ") || "Visual integrity failure detected during document OCR.",
      timestamp: new Date().toISOString(),
      status: "Open"
    };
    fraudAlerts.unshift(newAlert);
    logAction("ARIA Document Engine", "ARIA", "Security Alert Flagged", `Identified suspicious digital modifications on ${fileName} of ${studentRec.fullName}`, "Failed");
  } else {
    logAction("ARIA Document Engine", "ARIA", "Document Scan Approval", `Processed OCR parsing on ${docType} successfully for ${studentRec.fullName}`, "Success");
  }

  res.json(ocrResults);
});

// Registrar Approval Workflow
app.post("/api/applications/:id/review", (req, res) => {
  const { id } = req.params;
  const { status, comments, registrarName } = req.body;

  const appIndex = applications.findIndex(a => a.id === id);
  if (appIndex === -1) {
    return res.status(404).json({ error: "Application file not found." });
  }

  const studentApp = applications[appIndex];
  studentApp.status = status as ApplicationStatus;
  studentApp.comments = comments;
  studentApp.reviewedAt = new Date().toISOString();

  if (status === "Approved") {
    // Generate secure SHA-256 Hash
    const timestamp = Date.now();
    const hashData = `${studentApp.rollNo}|${studentApp.regNo}|${timestamp}|${registrarName || "Official Registrar Approval"}`;
    const hashSum = crypto.createHash("sha256");
    hashSum.update(hashData);
    const generatedHash = hashSum.digest("hex");
    
    studentApp.verificationHash = generatedHash;
    studentApp.attestedPdfUrl = `/verify/${generatedHash}`;
    
    // Resolve relative fraud alerts if any
    fraudAlerts = fraudAlerts.map(f => f.rollNo === studentApp.rollNo ? { ...f, status: "Resolved" } : f);
    
    logAction(registrarName || "Registrar Officer", "Registrar", "Attestation Authorized", `Approved and cryptographically signed degree verification file for ${studentApp.rollNo}`, "Success");
  } else {
    logAction(registrarName || "Registrar Officer", "Registrar", "Attestation Rejected", `Declined attestation file for ${studentApp.rollNo}. Status updated with notes: ${comments}`, "Success");
  }

  res.json(studentApp);
});

// Resolve fraud alert
app.post("/api/fraud/:id/resolve", (req, res) => {
  const alert = fraudAlerts.find(f => f.id === req.params.id);
  if (alert) {
    alert.status = "Resolved";
    
    // Also resolve associated application-level fraud flags so Registrar can approve it!
    const associatedApp = applications.find(a => a.id === alert.applicationId || a.rollNo === alert.rollNo);
    if (associatedApp) {
      if (associatedApp.transcriptUpload && associatedApp.transcriptUpload.fraudAlerts) {
        associatedApp.transcriptUpload.fraudAlerts.isFlagged = false;
        associatedApp.transcriptUpload.fraudAlerts.score = 0;
        associatedApp.transcriptUpload.fraudAlerts.indicators = [];
      }
      logAction("Registrar Officer", "Registrar", "Fraud Resolved", `Resolved and cleared fraud warnings dynamically on Application ${associatedApp.id} for Student Roll: ${associatedApp.rollNo}`, "Success");
    } else {
      logAction("Registrar Officer", "Registrar", "Fraud Resolved", `Marked isolated fraud report ID ${alert.id} as Resolved`, "Success");
    }
  }
  res.json({ success: true, alerts: fraudAlerts });
});

// Autopilot Degree Audit & Instant Attestation Engine
function executeAutopilotIfEligible(appItem: Application) {
  const rollNo = appItem.rollNo;
  const dbRecord = appItem.academicRecord || universityRecords.find(r => r.rollNo.toUpperCase() === rollNo.toUpperCase());
  
  if (!dbRecord) {
    appItem.comments = "Autopilot Paused: Could not map roll number to an official registrar profile.";
    appItem.status = ApplicationStatus.UnderReview;
    logAction("ARIA Autopilot Engine", "ARIA", "Automated Review Paused", `Paused automated approvals on Application ${appItem.id}: Missing registrar record mapping.`, "Failed");
    return;
  }
  
  appItem.academicRecord = dbRecord;

  // Check if there are any active OPEN fraud alerts for this student
  const activeFraud = fraudAlerts.find(f => f.rollNo.toUpperCase() === rollNo.toUpperCase() && f.status === "Open");
  if (activeFraud) {
    appItem.comments = `Autopilot Flagged: Suspicion of visual alteration identified on file. Locked for senior officer manual inspection. Case: ${activeFraud.type}`;
    appItem.status = ApplicationStatus.Rejected;
    logAction("ARIA Autopilot Engine", "ARIA", "Automated Review Warning", `Autopilot flagged security concern on Application ${appItem.id} for ${rollNo}. Verification halted: open fraud case logged.`, "Failed");
    return;
  }

  // Check if uploads have fraud alerts flagged
  const uploads = [appItem.cnicUpload, appItem.matricUpload, appItem.interUpload, appItem.degreeUpload, appItem.transcriptUpload];
  const flaggedUpload = uploads.find(up => up && up.fraudAlerts?.isFlagged);
  if (flaggedUpload) {
    appItem.comments = `Autopilot Blocked: Verification flagged high digital tampering ratio on document "${flaggedUpload.title}".`;
    appItem.status = ApplicationStatus.Rejected;
    logAction("ARIA Autopilot Engine", "ARIA", "Automated Security Veto", `Autopilot rejected application ${appItem.id} due to OCR/Tamper fraud alert on uploaded document.`, "Failed");
    return;
  }

  // Check clearances
  const isLibraryClear = dbRecord.libraryClearance === ClearanceStatus.Clear;
  const isFinanceClear = dbRecord.financeClearance === ClearanceStatus.Clear;
  const isDeptClear = dbRecord.departmentClearance === ClearanceStatus.Clear;

  if (!isLibraryClear || !isFinanceClear || !isDeptClear) {
    const issues = [];
    if (!isLibraryClear) issues.push("Library holds unresolved inventory");
    if (!isFinanceClear) issues.push("Finance registrar reports outstanding dues");
    if (!isDeptClear) issues.push("Academic department clearance pending signature");
    
    appItem.status = ApplicationStatus.UnderReview;
    appItem.comments = `Autopilot Paused: Academic clearances are outstanding. [Details: ${issues.join(" | ")}]. Application placed in manual processing queue.`;
    
    logAction("ARIA Autopilot Engine", "ARIA", "Automated Review Paused", `Paused automated attestation on Application ${appItem.id} due to pending clearances: ${issues.join(", ")}`, "Failed");
    return;
  }

  // Check if degree match is perfect and academicStatus is Completed
  if (dbRecord.academicStatus !== "Completed") {
    appItem.status = ApplicationStatus.UnderReview;
    appItem.comments = "Autopilot Paused: Graduation status in official registry is marked as Incompleted or Pending Board clearance.";
    logAction("ARIA Autopilot Engine", "ARIA", "Automated Review Paused", `Paused automated attestation on Application ${appItem.id}: Student ${rollNo} has graduation status incomplete.`, "Failed");
    return;
  }

  // Perfect! All checks passed! Elevate to Approved immediately and cryptographically seal it!
  appItem.status = ApplicationStatus.Approved;
  appItem.reviewedAt = new Date().toISOString();
  
  const timestamp = Date.now();
  const hashData = `${appItem.rollNo}|${appItem.regNo}|${timestamp}|ARIA-AUTOPILOT-SECURE-SEAL`;
  const hashSum = crypto.createHash("sha256");
  hashSum.update(hashData);
  const generatedHash = hashSum.digest("hex");
  
  appItem.verificationHash = generatedHash;
  appItem.attestedPdfUrl = `/verify/${generatedHash}`;
  appItem.comments = "Approved automatically by ARIA Autopilot Intelligence System. Document OCR features perfectly match registrar records. Secure digital attestation seal issued.";

  logAction("ARIA Autopilot Engine", "ARIA", "Instant Attestation Authorized", `Approved and cryptographically signed degree verification file for student: ${appItem.rollNo} (Fully Automated Bypass & Instant Seal Issued)`, "Success");
}

// AI screenshot-based payment uploader receipt OCR Verification Endpoint
app.post("/api/payment/verify-receipt", async (req, res) => {
  const { applicationId, screenshotBase64, simulatedText, fileName, autopilot, method } = req.body;

  const appItem = applications.find(a => a.id === applicationId);
  if (!appItem) return res.status(404).json({ error: "Associated application workflow not found." });

  const chosenMethod = method || "HBL Direct Transfer / Deposit";
  const rollbackTx = `TXID-EP-${Math.floor(100000 + Math.random() * 900000)}`;
  const expectedFee = appItem.paymentAmount || 5000;

  // Initial structure for payment receipt OCR
  let ocrResults = {
    txId: rollbackTx,
    amountPaid: expectedFee,
    paymentChannel: chosenMethod,
    senderName: appItem.academicRecord?.fullName || "Iqra Student",
    transactionDate: new Date().toISOString().split("T")[0],
    isGenuine: true,
    confidence: 96,
    mismatchIssues: [] as string[],
    rawOcrText: simulatedText || `RECEIPT STATUS: SUCCESSFUL DEPOSIT\nFOR IQRA DEGREE RECONCILIATION\nREF NO: ${rollbackTx}\nAMOUNT PAID: PKR ${expectedFee}\nDATE: ${new Date().toLocaleDateString()}`
  };

  const isFakeReceipt = (fileName && fileName.toLowerCase().includes("tampered")) || 
                     (fileName && fileName.toLowerCase().includes("fake")) ||
                     (simulatedText && simulatedText.toLowerCase().includes("fake")) ||
                     (simulatedText && simulatedText.toLowerCase().includes("tampered")) ||
                     (simulatedText && simulatedText.toLowerCase().includes("altered"));

  if (ai) {
    try {
      const systemPrompt = `You are a bank receipt OCR & Fraud audit bot in the IQRA VERIFY attestation portal.
Review the user's uploaded payment receipt screenshot details.
Verify these inputs:
- Expected Surcharge Fee to be paid: PKR ${expectedFee}
- Associated Student: ${appItem.academicRecord?.fullName || "Iqra Alumnus"}
- Flag receipt as Tampered/Fraud? ${isFakeReceipt ? "YES - Generate explicit Photoshop edit indicators, change payment amount to 500 or fake ID!" : "NO"}

You must return a JSON block with the following schema:
{
  "txId": "extracted TxID/Reference string",
  "amountPaid": 0.0, // numeric value
  "paymentChannel": "such as HBL Bank, Easypaisa, JazzCash, Nayapay, etc.",
  "senderName": "sender account name",
  "transactionDate": "YYYY-MM-DD",
  "isGenuine": true/false, // false if tampered or amount mismatch or duplicate ref
  "confidence": 0-100, // rating percentage
  "mismatchIssues": ["string description of any issues like: 'Incorrect fee amount', 'Photoshop font layer detected in amount', etc."],
  "rawOcrText": "paragraph containing raw extracted string OCR"
}`;

      const contents = screenshotBase64 
        ? {
            parts: [
              { inlineData: { mimeType: "image/png", data: screenshotBase64 } },
              { text: `Parse this bank transfer receipt uploader file. Expected payment amount is PKR ${expectedFee}. Simulated info: ${simulatedText || ""}` }
            ]
          }
        : `Parse payment receipt file '${fileName || "receipt_screenshot.png"}'. Expected PKR ${expectedFee}. Text Content: '${simulatedText || "Successful bank transfer checkout reference PK-901849182"}'`;

      const gResult = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        config: {
          responseMimeType: "application/json",
          systemInstruction: systemPrompt
        },
        contents: contents
      });

      const parsed = JSON.parse(gResult.text || "{}");
      ocrResults = { ...ocrResults, ...parsed };
    } catch (err) {
      console.error("Gemini receipt uploader OCR failed; running secure sandbox simulation:", err);
      if (isFakeReceipt) {
        ocrResults = {
          txId: `REF-EP-932185`,
          amountPaid: 350,
          paymentChannel: "Easypaisa Wallet Mobile Account Transfer",
          senderName: "Unknown User",
          transactionDate: new Date().toISOString().split("T")[0],
          isGenuine: false,
          confidence: 24,
          mismatchIssues: ["Photoshop canvas layers detected: Amount altered from PKR 350 to 5,000", "Sender name mismatch on bank ledger database lookup"],
          rawOcrText: simulatedText || "Easypaisa Receipt. Altered value 350."
        };
      }
    }
  } else {
    if (isFakeReceipt) {
      ocrResults = {
        txId: `REF-HBL-0091834`,
        amountPaid: 350,
        paymentChannel: "HBL Bank Mobile App Transfer",
        senderName: "Mishal Malik",
        transactionDate: new Date().toISOString().split("T")[0],
        isGenuine: false,
        confidence: 32,
        mismatchIssues: [`Receipt shows PKR 350, but expected attestation fee is PKR ${expectedFee}`, "Digital signature check fails: Pixels on transfer date appear stretched (typical Photoshop clone stamp tool)"],
        rawOcrText: "HBL Transfer. Amount: 350 PKR. Ref: REF-HBL-0091834"
      };
    }
  }

  if (ocrResults.isGenuine && ocrResults.amountPaid >= expectedFee) {
    appItem.paymentVerified = true;
    appItem.paymentMethod = `AI Screenshot OCR (${ocrResults.paymentChannel || chosenMethod})`;
    appItem.paymentTxRef = ocrResults.txId || rollbackTx;
    appItem.paymentAmount = ocrResults.amountPaid;
    appItem.status = ApplicationStatus.Submitted;

    logAction(appItem.rollNo, "ARIA", "Payment Auto-Configured", `Aria Auto-Verification Engine scan: Confirmed receipt of PKR ${ocrResults.amountPaid} via ${ocrResults.paymentChannel}. Ref ID: ${ocrResults.txId} (Extracted OCR confidence: ${ocrResults.confidence}%)`, "Success");

    if (autopilot) {
      executeAutopilotIfEligible(appItem);
    }

    res.json({
      success: true,
      application: appItem,
      ocrDetails: ocrResults
    });
  } else {
    // Payment receipt failed verification
    const alertId = `FRD-${Math.floor(100 + Math.random() * 900)}`;
    const newAlert: FraudAlert = {
      id: alertId,
      applicationId: appItem.id,
      studentName: appItem.academicRecord?.fullName || "Iqra Student",
      rollNo: appItem.rollNo,
      type: "Metadata Mismatch",
      severity: "High",
      description: `Altered Payment Receipt OCR details: ${ocrResults.mismatchIssues.join(", ")} | TxID: ${ocrResults.txId || "N/A"}`,
      timestamp: new Date().toISOString(),
      status: "Open"
    };
    
    fraudAlerts.unshift(newAlert);
    
    logAction(appItem.rollNo, "ARIA", "Receipt Fraud Flagged", `ARIA transaction scanner flagged suspicious receipt screenshot "${fileName || "receipt.png"}": ${ocrResults.mismatchIssues.join(" | ")}`, "Failed");

    res.status(400).json({
      error: "Automated Bank Transaction Check Failed",
      ocrDetails: ocrResults
    });
  }
});

// Mock credit card & crypto payment verification
app.post("/api/payment/verify", (req, res) => {
  const { applicationId, method, txRef, amount, autopilot } = req.body;

  const appItem = applications.find(a => a.id === applicationId);
  if (!appItem) return res.status(404).json({ error: "Associated application workflow not found." });

  appItem.paymentVerified = true;
  appItem.paymentMethod = method;
  appItem.paymentTxRef = txRef || `TXN${Math.floor(10000000 + Math.random() * 90000000)}`;
  appItem.paymentAmount = amount || 5000;
  appItem.status = ApplicationStatus.Submitted;

  logAction(appItem.rollNo, "Student", "Payment Registration", `Processed and confirmed PKR ${appItem.paymentAmount} via ${method}. Reference: ${appItem.paymentTxRef}`, "Success");

  if (autopilot) {
    executeAutopilotIfEligible(appItem);
  }

  res.json({ success: true, application: appItem });
});

// Fetch Audit Logs & System Analytics
app.get("/api/system/audit", (req, res) => {
  res.json(auditLogs);
});

app.get("/api/system/analytics", (req, res) => {
  const total = applications.length;
  const approved = applications.filter(a => a.status === ApplicationStatus.Approved).length;
  const rejected = applications.filter(a => a.status === ApplicationStatus.Rejected).length;
  const pending = applications.filter(a => a.status === ApplicationStatus.Submitted || a.status === ApplicationStatus.UnderReview).length;
  const fraudCount = fraudAlerts.filter(f => f.status === "Open").length;
  
  // Calculate mock revenue
  const revenue = applications
    .filter(a => a.paymentVerified)
    .reduce((sum, a) => sum + (a.paymentAmount || 5000), 0);

  res.json({
    total,
    approved,
    rejected,
    pending,
    revenue,
    fraudAttempts: fraudCount,
    departmentDistribution: [
      { name: "Computer Science", count: universityRecords.filter(r => r.degreeTitle.includes("Computer Science")).length },
      { name: "Software Engineering", count: universityRecords.filter(r => r.degreeTitle.includes("Software Engineering")).length },
      { name: "Business School", count: universityRecords.filter(r => r.degreeTitle.includes("Business")).length }
    ],
    fraudSeverity: [
      { name: "High", count: fraudAlerts.filter(f => f.severity === "High").length },
      { name: "Medium", count: fraudAlerts.filter(f => f.severity === "Medium").length },
      { name: "Low", count: fraudAlerts.filter(f => f.severity === "Low").length }
    ],
    verifiedList: applications.filter(a => a.status === ApplicationStatus.Approved)
  });
});

// Admin Automated Autopilot Batch Review Selector
app.post("/api/admin/autopilot-sweep", (req, res) => {
  let sweepCount = 0;
  let skippedCount = 0;

  applications.forEach(appItem => {
    if (appItem.status === ApplicationStatus.Submitted || appItem.status === ApplicationStatus.UnderReview) {
      const dbRecord = appItem.academicRecord || universityRecords.find(r => r.rollNo.toUpperCase() === appItem.rollNo.toUpperCase());
      if (!dbRecord) {
        skippedCount++;
        return;
      }

      const isLibraryClear = dbRecord.libraryClearance === ClearanceStatus.Clear;
      const isFinanceClear = dbRecord.financeClearance === ClearanceStatus.Clear;
      const isDeptClear = dbRecord.departmentClearance === ClearanceStatus.Clear;

      const activeFraud = fraudAlerts.find(f => f.rollNo.toUpperCase() === appItem.rollNo.toUpperCase() && f.status === "Open");
      const uploads = [appItem.cnicUpload, appItem.matricUpload, appItem.interUpload, appItem.degreeUpload, appItem.transcriptUpload];
      const flaggedUpload = uploads.find(up => up && up.fraudAlerts?.isFlagged);

      if (activeFraud || flaggedUpload || !isLibraryClear || !isFinanceClear || !isDeptClear || dbRecord.academicStatus !== "Completed") {
        skippedCount++;
        if (activeFraud) {
          appItem.comments = "Autopilot Flagged: Suspicion of visual alteration identified on file. Held for senior officer manual inspection.";
        } else if (flaggedUpload) {
          appItem.comments = `Autopilot Blocked: Verification flagged high digital tampering ratio on document "${flaggedUpload.title}".`;
        } else {
          appItem.comments = "Autopilot Paused: Outstanding clearances or incomplete graduation status on official registrar ledger.";
        }
        appItem.status = ApplicationStatus.UnderReview;
      } else {
        appItem.status = ApplicationStatus.Approved;
        appItem.reviewedAt = new Date().toISOString();
        
        const timestamp = Date.now();
        const hashData = `${appItem.rollNo}|${appItem.regNo}|${timestamp}|ARIA-AUTOPILOT-SECURE-SEAL`;
        const hashSum = crypto.createHash("sha256");
        hashSum.update(hashData);
        const generatedHash = hashSum.digest("hex");
        
        appItem.verificationHash = generatedHash;
        appItem.attestedPdfUrl = `/verify/${generatedHash}`;
        appItem.comments = "Approved & Signed automatically by ARIA Autopilot Sweep. Academic ledger checked and secure digital seal issued.";
        sweepCount++;

        logAction("ARIA Autopilot Engine", "ARIA", "Automated Sweep Approved", `Approved and cryptographically signed degree verification files for student: ${appItem.rollNo} (Fully Automated Admin Sweep)`, "Success");
      }
    }
  });

  res.json({ success: true, processed: sweepCount, skipped: skippedCount });
});

// ---------------- ARIA CONVERSATIONAL AGENT CHAT ----------------
app.post("/api/aria/chat", async (req, res) => {
  const { message, history } = req.body;
  if (!message) return res.status(400).json({ error: "A clear query text is required for Registrar ARIA." });

  const customContextPrompt = `You are Autonomous Registrar Intelligence Agent (ARIA) operating inside the official Iqra University Degree & Transcript Authentication, Verification & Attestation Platform named "IQRA VERIFY".

You are a humble, professional, clear, and highly secure digital Registrar Officer.
Your core identity is built to assist students and third-party organizations (embassies, employers, universities) through HEC Pakistan rules, HEC e-portal details, Iqra University policies, application statuses, processing times, document eligibility, and attestation fees.

FACTS FOR ARIA:
- Minimum configured CGPA for general degree attestation is 2.50.
- Credit Hours required: BS = 130+, MS = 30+, MPhil = 30+, PhD = 18+.
- Graduation Status: Must be fully "Completed" and verified.
- Student must have clearances from key departments (Library, Finance, Department clearance).
- Attestation Fees:
  - Degree Certificate Attestation: PKR 5,000
  - Official transcript Seal: PKR 3,000
  - Urgent Express Processing: +PKR 2,500
- Processing times: Regular is 7 business days, Urgent Express is 24-48 hours.
- Verified credentials receive a secure Hash using Student Data, Timestamp, Document details, and Registrar Digital Signature, and are attached with a visible watermark: "ATTESTED BY IQRA UNIVERSITY".
- Official verified search can navigate directly via scanning secure QR codes or typing the official SHA-256 hash.

If any customer asks you about their status, or general guidance:
- Answer warmly, professionally, briefly, and with excellent structure.
- Never mention internal technical codes, paths, or JSON structures unless asked. Keep it extremely user-centric.
- Use clean formatting, lists, and deep Iqra University Registrar dignity.`;

  if (ai) {
    try {
      // Structure contents properly
      const formattedContents = [];
      
      // Map history if any
      if (history && history.length > 0) {
        for (const turn of history) {
          formattedContents.push({
            role: turn.sender === "aria" ? "model" : "user",
            parts: [{ text: turn.text }]
          });
        }
      }
      
      // Append current user message
      formattedContents.push({
        role: "user",
        parts: [{ text: message }]
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        config: {
          systemInstruction: customContextPrompt,
          temperature: 0.7,
        },
        contents: formattedContents
      });

      const reply = response.text || "I apologize. I am currently reconciling records at the registry. Please ask your verification query again.";
      res.json({ reply: reply.trim() });
    } catch (err) {
      console.error("Gemini ARIA error:", err);
      res.json({ reply: fallbackLocalAgent(message) });
    }
  } else {
    // Fallback response generator if Gemini API key not present
    res.json({ reply: fallbackLocalAgent(message) });
  }
});

// Intelligent manual fallback response agent
function fallbackLocalAgent(msg: string): string {
  const m = msg.toLowerCase();
  if (m.includes("fee") || m.includes("cost") || m.includes("price") || m.includes("pkr")) {
    return `**Iqra Verify official fees schedule is as follows:**
1. **Degree Certificate Attestation**: PKR 5,000  
2. **Official Transcript Seal**: PKR 3,000  
3. **Urgent Fast-Track (48-hour Dispatch)**: Additional PKR 2,500  

Payments can be securely fulfilled using credit cards, bank check transfers, Easypaisa, JazzCash, or through our cryptocurrency digital portal (USDT/BTC/ETH). Please state if you need guide details on payment steps!`;
  }
  if (m.includes("time") || m.includes("process") || m.includes("day") || m.includes("urgent")) {
    return `**Verification Processing Timeline:**
- **Standard Verification Audit & Attestation**: Within 7 business days from fee synchronization and document analysis.
- **Urgent Express Priority Route**: Processed and dispatched in 24 to 48 hours.  

You can track your specific application real-time using our **Status Tracking Hub** after completing authentication steps.`;
  }
  if (m.includes("eligibility") || m.includes("cgpa") || m.includes("credit") || m.includes("bs") || m.includes("ms")) {
    return `**Attestation Eligibility Parameters:**
- **CGPA Check**: Must satisfy minimum of **2.50** target GPA.
- **Academic Credit Accumulations**:
  - **BS Degree**: 130+ Credit Hours
  - **MS / MPhil Degree**: 30+ Credit Hours
  - **PhD Attestation**: 18+ Credit Coursework Credits
- **Clearance Protocols**: Fully stamped 'Clear' status across Library, Academic department, and Financial finance records.`;
  }
  if (m.includes("hello") || m.includes("hi") || m.includes("hey") || m.includes("greet")) {
    return `Greetings! I am **ARIA** (Autonomous Registrar Intelligence Agent). How may I assist your academic credential attestation, document uploading, or third-party employer verification today?`;
  }
  return `Thank you for contacting Iqra Verify Administration. I am ARIA, your digital verification officer. I can assist with confirming:
- **Attestation Eligibility & Requirements** (e.g. CGPA, credit hours)
- **Fee structures and Payment Modes**
- **Under Review workflow status** 
- **OCR crosscheck discrepancies** (exposing tampered transcripts or mismatched data profiles)

Could you please elaborate or share your specific student roll number?`;
}

// ---------------- VITE / STATIC PRODUCTION SERVING ----------------

const startServer = async () => {
  if (process.env.NODE_ENV !== "production") {
    // Development server with Vite middleware
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Mounted Vite development middleware client integration.");
  } else {
    // Serve static files in production from dist
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`IQRA VERIFY full-stack server running successfully on http://localhost:${PORT}`);
  });
};

startServer().catch(err => {
  console.error("Critical server failure on initialization:", err);
});
