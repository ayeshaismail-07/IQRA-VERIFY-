/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { MessageSquare, Send, Sparkles, X, ChevronUp, Bot, HelpCircle, History } from "lucide-react";
import { ChatMessage } from "../types";

interface AriaAgentProps {
  initialPrompt?: string;
  className?: string;
  compactMode?: boolean;
}

export default function AriaAgent({ initialPrompt = "", className = "", compactMode = false }: AriaAgentProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      sender: "aria",
      text: "Greetings! I am ARIA (Autonomous Registrar Intelligence Agent). I handle degree/transcript attestations, clearance checks, and security audits for Iqra University. How can I guide you today?",
      timestamp: new Date().toISOString()
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialPrompt && isOpen) {
      handleSendMessage(initialPrompt);
    }
  }, [initialPrompt, isOpen]);

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMessage: ChatMessage = {
      id: `m-${Date.now()}`,
      sender: "user",
      text: textToSend,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);

    try {
      // Map simple message array structure matching Node-side history schema
      const mappedHistory = messages.slice(-8).map(m => ({
        sender: m.sender,
        text: m.text
      }));

      const res = await fetch("/api/aria/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: textToSend,
          history: mappedHistory
        })
      });

      const data = await res.json();
      
      const ariaMessage: ChatMessage = {
        id: `m-${Date.now() + 1}`,
        sender: "aria",
        text: data.reply || "I encountered an issue connecting to the main Registrar Records. Please query me again.",
        timestamp: new Date().toISOString()
      };
      
      setMessages(prev => [...prev, ariaMessage]);
    } catch (err) {
      console.error("ARIA assistant link disrupted:", err);
      // Fallback local response
      setTimeout(() => {
        setMessages(prev => [...prev, {
          id: `m-err-${Date.now()}`,
          sender: "aria",
          text: "My apologies. Connection is unstable, but as security officer I can confirm the minimum HEC required CGPA is **2.50**, minimum BS credit hours is **130**, and our regular attestation fee is **PKR 5,000**.",
          timestamp: new Date().toISOString()
        }]);
      }, 1000);
    } finally {
      setIsTyping(false);
    }
  };

  const quickPrompts = [
    { label: "What is the attestation fee?", text: "What is the fee structure for degree & transcript attestation?" },
    { label: "Check HEC minimum CGPA constraints", text: "What are the HEC minimum CGPA and credit requirements?" },
    { label: "How to resolve Photoshop alerts?", text: "Why does my document raise Photoshop fraud alerts?" },
    { label: "How long does processing take?", text: "What are the processing timelines for regular vs urgent?" }
  ];

  if (compactMode) {
    return (
      <div className={`flex flex-col bg-white border border-gray-100 rounded-xl shadow-lg h-[500px] overflow-hidden ${className}`}>
        {/* Compact Header */}
        <div className="bg-iqra-green text-white px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1 px-1.5 bg-white/10 rounded-lg">
              <Bot className="w-5 h-5 text-iqra-gold" />
            </div>
            <div>
              <h4 className="font-display font-semibold text-sm">ARIA AI Registrar Agent</h4>
              <p className="text-[10px] text-iqra-green-light flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Autonomous Intelligence Officer
              </p>
            </div>
          </div>
          <Sparkles className="w-4 h-4 text-iqra-gold animate-bounce" />
        </div>

        {/* Messages list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50/50">
          {messages.map(msg => (
            <div
              key={msg.id}
              className={`flex flex-col max-w-[85%] ${msg.sender === "user" ? "ml-auto items-end" : "mr-auto items-start"}`}
            >
              <div
                className={`p-3 rounded-2xl text-xs leading-relaxed ${
                  msg.sender === "user"
                    ? "bg-iqra-green text-white rounded-br-none"
                    : "bg-white text-gray-800 border border-gray-100 rounded-bl-none shadow-sm"
                }`}
              >
                {/* Parse basic bold text */}
                <div className="whitespace-pre-wrap">
                  {msg.text.split("\n").map((line, idx) => (
                    <p key={idx} className={idx > 0 ? "mt-1.5" : ""}>
                      {line.split("**").map((chunk, cIdx) => 
                        cIdx % 2 === 1 ? <strong key={cIdx} className="font-semibold text-iqra-gold">{chunk}</strong> : chunk
                      )}
                    </p>
                  ))}
                </div>
              </div>
              <span className="text-[9px] text-gray-400 mt-1 px-1">
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </span>
            </div>
          ))}

          {isTyping && (
            <div className="mr-auto items-start flex flex-col max-w-[80%]">
              <div className="bg-white text-gray-800 border border-gray-100 rounded-2xl p-3 shadow-sm rounded-bl-none flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"></span>
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-100"></span>
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-200"></span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Mini Quick options */}
        <div className="p-2 border-t border-gray-100 bg-white overflow-x-auto flex gap-1.5 scrollbar-none whitespace-nowrap">
          {quickPrompts.slice(0, 2).map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(p.text)}
              className="text-[10px] text-iqra-green bg-iqra-green-light border border-iqra-green/10 rounded-full px-2.5 py-1 hover:bg-iqra-green hover:text-white transition-all cursor-pointer font-medium"
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Input */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage(inputValue);
          }}
          className="p-2.5 border-t border-gray-100 bg-white flex gap-1.5"
        >
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Query ARIA about attestation policies..."
            className="flex-1 bg-gray-50 border border-gray-200 text-xs rounded-xl px-3 py-2 outline-none focus:border-iqra-green focus:bg-white text-gray-800 transition-all font-sans"
          />
          <button
            type="submit"
            disabled={!inputValue.trim()}
            className="bg-iqra-green text-white p-2 rounded-xl hover:bg-iqra-green-dark disabled:opacity-40 transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    );
  }

  return (
    <>
      {/* Floating trigger widget */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
        {isOpen && (
          <div className="bg-white border border-gray-100 rounded-2xl shadow-2xl w-[400px] h-[550px] flex flex-col overflow-hidden mb-3 animate-in fade-in slide-in-from-bottom-6 duration-300">
            {/* Header branding */}
            <div className="bg-iqra-green text-white px-5 py-4 flex items-center justify-between relative">
              <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-iqra-gold to-iqra-gold-dark z-10" />
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center border border-white/10">
                  <Bot className="w-6 h-6 text-iqra-gold" />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-sm leading-tight flex items-center gap-1.5">
                    ARIA Agent
                    <span className="text-[10px] bg-iqra-gold/20 text-iqra-gold font-mono uppercase tracking-wider px-1.5 py-0.5 rounded border border-iqra-gold/30">
                      v2.5
                    </span>
                  </h3>
                  <p className="text-[10px] text-iqra-green-light flex items-center gap-1 mt-0.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                    Verification Security Officer Online
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 hover:bg-white/10 text-white/80 hover:text-white rounded-xl transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Chat list */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-gray-50/50">
              {messages.map(msg => (
                <div
                  key={msg.id}
                  className={`flex flex-col max-w-[85%] ${
                    msg.sender === "user" ? "ml-auto items-end" : "mr-auto items-start"
                  }`}
                >
                  <div
                    className={`p-3.5 rounded-2xl text-xs leading-relaxed shadow-sm ${
                      msg.sender === "user"
                        ? "bg-iqra-green text-white rounded-tr-none hover:bg-iqra-green-dark transition-all"
                        : "bg-white text-gray-800 border border-gray-100 rounded-tl-none"
                    }`}
                  >
                    <div className="whitespace-pre-wrap font-sans">
                      {msg.text.split("\n").map((line, idx) => (
                        <p key={idx} className={idx > 0 ? "mt-2" : ""}>
                          {line.split("**").map((chunk, cIdx) => 
                            cIdx % 2 === 1 ? <strong key={cIdx} className="font-semibold text-iqra-gold font-display">{chunk}</strong> : chunk
                          )}
                        </p>
                      ))}
                    </div>
                  </div>
                  <span className="text-[9px] text-gray-400 mt-1 px-1">
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </span>
                </div>
              ))}

              {isTyping && (
                <div className="mr-auto items-start flex flex-col max-w-[80%]">
                  <div className="bg-white text-gray-800 border border-gray-100 rounded-2xl px-4 py-3 shadow-sm rounded-tl-none flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-iqra-green rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-1.5 bg-iqra-green rounded-full animate-bounce delay-150"></span>
                    <span className="w-1.5 h-1.5 bg-iqra-green rounded-full animate-bounce delay-300"></span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Direct Quick Suggestion Prompts */}
            <div className="px-4 py-2 border-t border-gray-100 bg-white grid grid-cols-2 gap-1.5 shrink-0">
              {quickPrompts.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(p.text)}
                  className="text-[9px] text-left text-gray-600 bg-gray-50 border border-gray-100 hover:bg-iqra-green-light hover:text-iqra-green hover:border-iqra-green/20 rounded-lg p-2 transition-all cursor-pointer truncate"
                  title={p.text}
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Input submission box */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage(inputValue);
              }}
              className="p-4 border-t border-gray-100 bg-white flex gap-2 shrink-0"
            >
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask ARIA: e.g. HEC regular attestation fee?"
                className="flex-1 bg-gray-50 border border-gray-200 text-xs rounded-xl px-4 py-2.5 outline-none focus:border-iqra-green focus:bg-white text-gray-800 transition-all font-sans"
              />
              <button
                type="submit"
                disabled={!inputValue.trim()}
                className="bg-iqra-green text-white p-2.5 rounded-xl hover:bg-iqra-green-dark disabled:opacity-40 transition-all cursor-pointer flex items-center justify-center shrink-0"
              >
                <Send className="w-4.5 h-4.5" />
              </button>
            </form>
          </div>
        )}

        {/* Toggle Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`flex items-center gap-2 px-5 py-4.5 rounded-full shadow-2xl transition-all cursor-pointer border ${
            isOpen 
              ? "bg-white text-iqra-green border-gray-100 hover:bg-gray-50" 
              : "bg-iqra-green hover:bg-iqra-green-dark text-white border-iqra-green/10"
          }`}
        >
          {isOpen ? (
            <X className="w-5 h-5 text-iqra-green" />
          ) : (
            <div className="flex items-center gap-2">
              <Bot className="w-5 h-5 text-iqra-gold animate-bounce" />
              <span className="font-display font-semibold text-xs tracking-wider">CHATTING WITH ARIA</span>
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
            </div>
          )}
        </button>
      </div>
    </>
  );
}
