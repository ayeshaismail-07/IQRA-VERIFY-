/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Search, ShieldAlert, ShieldCheck, FileText, QrCode, Download, Calendar, Mail, GraduationCap, Award, Printer, ArrowRight } from "lucide-react";

interface VerificationPortalProps {
  onBackToHome: () => void;
  addToast: (message: string, type: "success" | "error" | "info") => void;
}

export default function VerificationPortal({ onBackToHome, addToast }: VerificationPortalProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [verificationResult, setVerificationResult] = useState<any | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  // Read URL Hash stamp on load if available (verify via routing hash)
  useEffect(() => {
    const checkHash = async () => {
      const hash = window.location.hash;
      if (hash && hash.startsWith("#verify-")) {
        const hashVal = hash.substring(8);
        setSearchQuery(hashVal);
        await performSearch(hashVal);
      }
    };
    checkHash();
    
    window.addEventListener("hashchange", checkHash);
    return () => window.removeEventListener("hashchange", checkHash);
  }, []);

  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      addToast("Please input a valid SHA-256 seal hash or registrar number.", "error");
      return;
    }
    await performSearch(searchQuery);
  };

  const performSearch = async (query: string) => {
    setIsSearching(true);
    setVerificationResult(null);
    setHasSearched(true);

    try {
      const res = await fetch(`/api/public-verify?query=${encodeURIComponent(query)}`);
      const data = await res.json();
      
      if (res.ok && data.verified) {
        setVerificationResult(data);
        addToast("Cryptographic certification record verified and authentified!", "success");
      } else {
        setVerificationResult({ verified: false, error: data.error });
        addToast("Authentication Failed: Record has not been localized.", "error");
      }
    } catch (err) {
      addToast("Failed to connect with security verify index.", "error");
    } finally {
      setIsSearching(false);
    }
  };

  const handleDownloadPdf = (student: any) => {
    // Generate a beautiful, clean, well-formatted printable text/structured payload styled as an official certificate
    const content = `========================================================================
                      IQRA UNIVERSITY ATTESTED DEGREE CERTIFICATE
========================================================================

Official registrar-attested academic credential. Verified by ARIA Autopilot.

Student Profile:
---------------
Full Name:        ${student.studentName}
Roll Number:      ${student.rollNo}
Registration ID:  ${student.regNo}

Academic Credentials:
--------------------
Degree Major:     ${student.degreeTitle}
School/Dept:      ${student.department}
Cumulative GPA:   ${student.cgpa}
Graduation Date:  ${student.graduationDate}

Attestation Metadata Security:
-----------------------------
Cryptographic Hash:   ${student.verificationHash || "N/A"}
Payment Tx Hash:      ${student.paymentTxRef || "N/A"}
Attestation Timestamp: ${new Date(student.attestedAt).toUTCString()}
Attested Authority:   Aiman Fareed, Registrar

------------------------------------------------------------------------
AUTHENTICITY GUARANTEED. Digital seal registered secure.
========================================================================`;
    
    // Create download trigger
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Iqra_Attested_Degree_${student.rollNo.replace(/[^a-zA-Z0-9-]/g, "_")}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    addToast("Cryptographic attestation credentials file downloaded successfully!", "success");
  };

  const recentLookups = [
    { label: "Kamran Shah (Approved Degree)", hash: "8f7bc2246a48d89e9f3b89e3a39b2cf47fd39af183d29a513bf89df201de38e2" },
    { label: "Ayesha Ahmed (Under Review)", hash: "APP-551029" },
    { label: "Zainab Malik (Flagged Fraud Case)", hash: "APP-110293" }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-10 animate-in fade-in duration-300">
      
      {/* Brand Header */}
      <div className="text-center mb-10">
        <button 
          onClick={onBackToHome}
          className="text-xs text-gray-500 hover:text-iqra-green inline-flex items-center gap-1.5 mb-3 cursor-pointer"
        >
          ← Back to primary landing
        </button>
        <h1 className="text-3xl md:text-4xl font-display font-extrabold text-gray-900 tracking-tight">
          IQRA VERIFY <span className="text-iqra-gold font-light">Validation Hub</span>
        </h1>
        <p className="text-xs text-gray-500 mt-2 max-w-lg mx-auto">
          International Public Registry for instant cryptographic attestation auditing of degrees, certificates, and official transcript scrolls.
        </p>
      </div>

      {/* Main search bar */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-xl p-6 md:p-8 mb-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-iqra-green to-iqra-gold" />
        
        <form onSubmit={handleSearchSubmit} className="space-y-4">
          <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider">
            Cryptographic Search Query
          </label>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Paste SHA-256 seal stamp hash, Degree serialization ID, or Roll ID..."
                className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 pl-10 pr-4 text-xs font-mono outline-none focus:bg-white focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all shadow-inner"
              />
              <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
            </div>
            <button
              type="submit"
              disabled={isSearching}
              className="bg-iqra-green hover:bg-iqra-green-dark text-white rounded-xl px-8 py-3 text-xs font-display font-bold shadow-md tracking-wider cursor-pointer whitespace-nowrap transition-all"
            >
              {isSearching ? "Querying registry..." : "Verify Certificate"}
            </button>
          </div>
        </form>

        {/* Suggested presets for testing */}
        <div className="mt-6 border-t border-gray-100 pt-4">
          <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest block mb-2">Institutional Test Stems</span>
          <div className="flex flex-wrap gap-2">
            {recentLookups.map((lookup, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setSearchQuery(lookup.hash);
                  performSearch(lookup.hash);
                }}
                className="text-[10px] text-left bg-gray-50 border border-gray-100 hover:bg-iqra-gold-light hover:border-iqra-gold/20 hover:text-iqra-gold-dark rounded-lg p-2 px-3 transition-all cursor-pointer font-medium"
              >
                {lookup.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Query Search Results */}
      {hasSearched && (
        <div className="animate-in slide-in-from-bottom-5 duration-300">
          
          {isSearching ? (
            <div className="text-center py-20 bg-white rounded-2xl border border-gray-100 shadow-sm space-y-3">
              <QrCode className="w-10 h-10 text-iqra-green animate-pulse mx-auto" />
              <p className="text-xs font-bold text-gray-600 font-mono">Conducting digital record validation checks across HEC indices...</p>
            </div>
          ) : verificationResult?.verified ? (
            /* VERIFIED ATTESTED RECORD PRESENTATION CARD */
            <div className="bg-white rounded-2xl border border-emerald-100 shadow-2xl overflow-hidden text-left relative watermark-container">
              
              {/* Card top banner branding */}
              <div className="bg-emerald-600 text-white p-5 px-6 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-white/15 flex items-center justify-center border border-white/15 shadow-inner">
                    <ShieldCheck className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-display font-extrabold text-sm uppercase tracking-wider">Officially Attested Degree Verified</h3>
                    <p className="text-[10px] text-emerald-100 mt-0.5">Iqra University Central Registrary System Secure stamp</p>
                  </div>
                </div>
                <Award className="w-7 h-7 text-iqra-gold animate-bounce shrink-0" />
              </div>

              {/* Certificate Layout */}
              <div className="p-6 md:p-8 space-y-6 relative">
                
                {/* Gold Crest */}
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <p className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Registrary Reference</p>
                    <p className="text-xs font-bold font-mono text-gray-800">{verificationResult.verificationHash}</p>
                  </div>
                  <div className="h-12 border border-blue-200 rounded-lg flex items-center justify-center p-1.5 bg-[#005596] shadow-sm shrink-0 max-w-[150px]">
                    <img 
                      src="https://seeklogo.com/images/I/iqra-university-logo-D5BDE7EAA7-seeklogo.com.png" 
                      alt="Iqra University Official Logo" 
                      className="h-9 object-contain select-none"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </div>

                {/* Main Attestation Statement */}
                <div className="space-y-4 border-y border-gray-100 py-6">
                  <p className="text-xs text-gray-500 italic">This document officially confirms and validates the academic record of:</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <span className="text-[10px] text-gray-400 font-semibold uppercase block">Student Full Name</span>
                      <span className="text-base font-display font-bold text-gray-900">{verificationResult.studentName}</span>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] text-gray-400 font-semibold uppercase block">Roll / Registration Number</span>
                      <span className="text-xs font-mono font-bold text-gray-800">{verificationResult.rollNo} / {verificationResult.regNo}</span>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] text-gray-400 font-semibold uppercase block">Degree Certification Title</span>
                      <span className="text-sm font-semibold text-gray-900">{verificationResult.degreeTitle}</span>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] text-gray-400 font-semibold uppercase block">Academic Department Division</span>
                      <span className="text-xs text-gray-700">{verificationResult.department}</span>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] text-gray-400 font-semibold uppercase block">CGPA Record</span>
                      <span className="text-xs font-mono font-bold text-gray-950">{verificationResult.cgpa}</span>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] text-gray-400 font-semibold uppercase block">Graduation Date</span>
                      <span className="text-xs font-mono text-gray-800">{verificationResult.graduationDate}</span>
                    </div>
                  </div>
                </div>

                {/* Signatures and QR Verification Block */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pt-4 gap-6">
                  <div className="flex items-center gap-4">
                    {/* QR Stamp */}
                    <div className="w-20 h-20 bg-gray-50 p-1.5 border border-gray-100 rounded-lg shrink-0 flex items-center justify-center">
                      <QrCode className="w-16 h-16 text-gray-800" />
                    </div>
                    <div className="text-xs space-y-1 leading-normal max-w-sm">
                      <p className="font-bold text-gray-900">Scan QR Code verification</p>
                      <p className="text-[10px] text-gray-500">Scanning redirects to direct live registrar security index confirm checks.</p>
                      <p className="text-[10px] text-iqra-green font-semibold">Attested Stamp Date: {new Date(verificationResult.attestedAt).toLocaleDateString()}</p>
                    </div>
                  </div>

                  <div className="text-center sm:text-right border-t sm:border-t-0 pt-4 sm:pt-0 shrink-0 self-stretch sm:self-center flex flex-col justify-end">
                    <p className="text-[10px] text-gray-400 uppercase font-semibold">Signature of Registrar Authorized Officer</p>
                    <div className="h-8 font-serif italic text-sm text-gray-750 select-none mt-2">
                       Aiman Fareed
                    </div>
                    <p className="text-[9px] font-mono text-gray-400 mt-1 border-t border-dashed border-gray-200 pt-1">DIGITAL SECURED INTEGRITY LOCKED</p>
                  </div>
                </div>

              </div>

              {/* Bottom Print / Copy Option */}
              <div className="bg-gray-50 px-6 py-4 border-t border-gray-100 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => handleDownloadPdf(verificationResult)}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 px-4 rounded-xl cursor-pointer flex items-center gap-1.5 shadow-sm transition-all"
                >
                  <Download className="w-4 h-4" /> Download Official Degree (PDF/Text)
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="bg-white border hover:bg-gray-100 border-gray-200 text-gray-700 font-semibold text-xs py-2 px-4 rounded-xl cursor-pointer flex items-center gap-1.5 shadow-xs transition-all"
                >
                  <Printer className="w-4 h-4" /> Print Attestation Certificate
                </button>
              </div>

            </div>
          ) : (
            /* INVALID OR MOCK EXCEPTION SCREEN */
            <div className="bg-white rounded-2xl border border-red-100 shadow-xl p-8 py-12 text-center max-w-xl mx-auto space-y-4">
              <div className="w-16 h-16 rounded-full bg-red-50 text-red-600 flex items-center justify-center mx-auto border border-red-100 shadow-sm animate-bounce">
                <ShieldAlert className="w-8 h-8" />
              </div>
              <div className="space-y-1 bg-red-50/50 p-4 rounded-xl border border-red-50">
                <h3 className="text-base font-display font-bold text-red-950">AUTHENTICATION PROTOCOL EXCEPTION</h3>
                <p className="text-xs text-red-700 leading-normal font-sans text-left mt-2">
                  {verificationResult?.error || "We could not find any attested digital degree registry correlating with the supplied metadata."}
                </p>
              </div>
              <p className="text-[10px] text-gray-400 max-w-md mx-auto">
                If you believe this to be an error, please coordinate with Iqra University's Registrar Office of Education or have the applicant student provide their official SHA-256 stamp.
              </p>
            </div>
          )}

        </div>
      )}

    </div>
  );
}
