/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  User, Mail, ArrowRight, UploadCloud, CheckCircle2, AlertTriangle, Play, CheckCircle, 
  HelpCircle, CreditCard, ShieldCheck, Download, RefreshCw, Layers, FileText, Phone, 
  MapPin, Calendar, Clock, BookOpen, DollarSign, Wallet, QrCode, Bot, Cpu, FileImage, X,
  GraduationCap, TrendingUp
} from "lucide-react";
import { StudentProfile, IqraDbRecord, Application, ApplicationStatus, DegreeType, ClearanceStatus } from "../types";
import AriaAgent from "./AriaAgent";

interface StudentPortalProps {
  onBackToHome: () => void;
  applications: Application[];
  onRefreshApplications: () => Promise<void>;
  addToast: (message: string, type: "success" | "error" | "info") => void;
}

export default function StudentPortal({ onBackToHome, applications: globalApps, onRefreshApplications, addToast }: StudentPortalProps) {
  const [student, setStudent] = useState<StudentProfile | null>(null);
  const [academicRecord, setAcademicRecord] = useState<IqraDbRecord | null>(null);
  
  // Auth Form State
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rollNo, setRollNo] = useState("");
  const [cnic, setCnic] = useState("");
  const [registerCgpa, setRegisterCgpa] = useState("3.50");
  const [isEditingCgpa, setIsEditingCgpa] = useState(false);
  const [newCgpaVal, setNewCgpaVal] = useState("3.50");
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isRegisteringStudent, setIsRegisteringStudent] = useState(false);
  const [showSeedAcc, setShowSeedAcc] = useState(true);

  // Wizard Process State
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [wizardStep, setWizardStep] = useState(1);
  const [selectedDegree, setSelectedDegree] = useState<DegreeType>(DegreeType.BS);
  const [currentAppId, setCurrentAppId] = useState<string | null>(null);

  // Upload States
  const [cnicFile, setCnicFile] = useState<File | null>(null);
  const [matricFile, setMatricFile] = useState<File | null>(null);
  const [interFile, setInterFile] = useState<File | null>(null);
  const [degreeFile, setDegreeFile] = useState<File | null>(null);
  const [transcriptFile, setTranscriptFile] = useState<File | null>(null);
  
  const [isScanning, setIsScanning] = useState<Record<string, boolean>>({});
  const [ocrResults, setOcrResults] = useState<Record<string, any>>({});
  const [simulateTamper, setSimulateTamper] = useState(false);
  const [scannerLogs, setScannerLogs] = useState<string[]>([]);
  const [isProcessingOcr, setIsProcessingOcr] = useState(false);

  // Payment State
  const [paymentMethod, setPaymentMethod] = useState("Credit / Debit Card");
  const [paymentAmount, setPaymentAmount] = useState(5000); // PKR
  const [isPaying, setIsPaying] = useState(false);
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvc, setCardCvc] = useState("");
  const [cryptoCurrency, setCryptoCurrency] = useState("USDT");
  const [cryptoTx, setCryptoTx] = useState("");
  const [isUrgent, setIsUrgent] = useState(false);
  const [selectedCertApp, setSelectedCertApp] = useState<Application | null>(null);

  // AI Screenshot OCR Receipt & Autopilot States
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [isScanningReceipt, setIsScanningReceipt] = useState(false);
  const [receiptOcrResult, setReceiptOcrResult] = useState<any>(null);
  const [autopilotEnabled, setAutopilotEnabled] = useState(true);
  const [activePaymentTab, setActivePaymentTab] = useState<"screenshot" | "manual">("screenshot");

  // Local apps filter for current student
  const studentApps = globalApps.filter(app => app.studentId === student?.id || (student && app.rollNo === student.id));

  const handleSeedSelect = (seedRoll: string) => {
    setRollNo(seedRoll);
    if (seedRoll === "IU-BSCS-2022-045") {
      setEmail("kamran@iqra.edu.pk");
      setCnic("4210183921831");
    } else if (seedRoll === "IU-BSSE-2022-094") {
      setEmail("zainab@iqra.edu.pk");
      setCnic("3740583918232");
    } else if (seedRoll === "IU-BBA-2021-120") {
      setEmail("ayesha@iqra.edu.pk");
      setCnic("3520192837122");
    }
    setPassword("iqra123");
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !rollNo.trim() || !password.trim() || !cnic.trim()) {
      addToast("Please input all student registration details.", "error");
      return;
    }
    if (!email.includes("@")) {
      addToast("Please enter a valid format email address.", "error");
      return;
    }
    
    const isUniEmail = email.toLowerCase().trim().endsWith("@iqra.edu.pk") || email.toLowerCase().trim().endsWith(".edu.pk") || email.toLowerCase().trim().endsWith(".edu");
    if (!isUniEmail) {
      addToast("Access Denied: Only official university emails (ending with @iqra.edu.pk, .edu.pk or .edu) are allowed.", "error");
      return;
    }

    const cleanCnic = cnic.replace(/[^0-9]/g, "");
    if (cleanCnic.length !== 13) {
      addToast("Access Denied: National CNIC must be exactly 13 digits long and contain numbers only.", "error");
      return;
    }

    setIsLoggingIn(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, rollNo, cnic, cgpa: 3.50 })
      });
      const data = await res.json();
      if (res.ok) {
        addToast(`Registered associated account successfully! You may now sign in.`, "success");
        setIsRegisteringStudent(false);
      } else {
        addToast(data.error || "Registration denied.", "error");
      }
    } catch (err) {
      addToast("Failed to connect with central student registration API.", "error");
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !rollNo.trim() || !password.trim()) {
      addToast("Please fill in official student authentication parameters.", "error");
      return;
    }
    if (!email.includes("@")) {
      addToast("Please enter a valid format email address.", "error");
      return;
    }
    
    const isUniEmail = email.toLowerCase().trim().endsWith("@iqra.edu.pk") || email.toLowerCase().trim().endsWith(".edu.pk") || email.toLowerCase().trim().endsWith(".edu");
    if (!isUniEmail) {
      addToast("Access Denied: Only official university emails (ending with @iqra.edu.pk, .edu.pk or .edu) are allowed.", "error");
      return;
    }

    setIsLoggingIn(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, rollNo })
      });
      const data = await res.json();
      
      if (res.ok) {
        setStudent(data.student);
        setAcademicRecord(data.academicRecord);
        if (data.academicRecord?.cgpa !== undefined) {
          setNewCgpaVal(data.academicRecord.cgpa.toString());
        }
        addToast(`Authenticated successfully as ${data.student.fullName}`, "success");
      } else {
        addToast(data.error || "Authentication route denied.", "error");
      }
    } catch (err) {
      addToast("Failed to connect with Iqra central auth directory.", "error");
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleUpdateCgpa = async () => {
    if (!academicRecord) return;
    const parseFloatVal = parseFloat(newCgpaVal);
    if (isNaN(parseFloatVal) || parseFloatVal < 0 || parseFloatVal > 4) {
      addToast("CGPA must be a valid float between 0.00 and 4.00.", "error");
      return;
    }
    try {
      const res = await fetch("/api/student/update-cgpa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rollNo: academicRecord.rollNo, cgpa: parseFloatVal })
      });
      const data = await res.json();
      if (res.ok) {
        setAcademicRecord(data.academicRecord);
        addToast(`Successfully updated Cumulative GPA in registrar log to ${parseFloatVal.toFixed(2)}`, "success");
        setIsEditingCgpa(false);
        await onRefreshApplications();
      } else {
        addToast(data.error || "Update rejected", "error");
      }
    } catch (e) {
      addToast("Failed to connect with registrar API.", "error");
    }
  };

  const handleStartAttestation = () => {
    if (!academicRecord) return;
    
    // Initiate application draft
    const appId = `APP-${Math.floor(100000 + Math.random() * 900000)}`;
    setCurrentAppId(appId);
    setWizardStep(1);
    setIsWizardOpen(true);
    setOcrResults({});
    setScannerLogs([]);
    setCnicFile(null);
    setMatricFile(null);
    setInterFile(null);
    setDegreeFile(null);
    setTranscriptFile(null);
  };

  const appendScannerLog = (msg: string) => {
    setScannerLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  const handleOcrFileProcess = async (docType: string, file: File) => {
    if (!student || !academicRecord) return;
    
    setIsScanning(prev => ({ ...prev, [docType]: true }));
    appendScannerLog(`Initializing ARIA Document Intelligence Engine...`);
    appendScannerLog(`Scanning file: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`);
    appendScannerLog(`Injecting advanced neural OCR layers for document structure recognition...`);
    
    // Laser sweep simulation duration
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    appendScannerLog(`OCR Extraction phase complete. Verifying integrity hashes...`);
    appendScannerLog(`Cross-referencing record against main Iqra University Registrar database...`);

    try {
      const isTamperedFile = simulateTamper && (docType === "transcript" || docType === "cnic");
      const simulatedFileName = isTamperedFile ? "tampered_transcript.pdf" : file.name;

      const res = await fetch("/api/ocr/process", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          docType,
          rollNo: academicRecord.rollNo,
          fileName: simulatedFileName,
          simulatedText: isTamperedFile 
            ? "Simulated Tampered Document. CGPA 3.90 edited using Photoshop layers." 
            : `Official certificate for ${student.fullName}, Roll: ${academicRecord.rollNo}, CGPA: ${academicRecord.cgpa}`
        })
      });

      const data = await res.json();
      setOcrResults(prev => ({ ...prev, [docType]: data }));

      if (data.fraudAlerts?.isFlagged) {
        addToast(`SECURITY SUSPICION ALERT: Forensic engine flagged discrepancies on ${docType}!`, "error");
        appendScannerLog(`⚠️ CRITICAL ERROR: Forensic scanner flagged potential discrepancies!`);
        data.fraudAlerts.indicators.forEach((indicator: string) => {
          appendScannerLog(`   - FLAG: ${indicator}`);
        });
      } else {
        addToast(`${docType.toUpperCase()} file processed with perfect database correlation!`, "success");
        appendScannerLog(`✓ SUCCESS: Perfect verification match. Document authenticated.`);
      }
    } catch (e) {
      appendScannerLog(`Error connecting with OCR analysis route. Falling back to secure default match.`);
    } finally {
      setIsScanning(prev => ({ ...prev, [docType]: false }));
    }
  };

  const submitApplicationMetadata = async (stepToSet: number) => {
    if (!student || !currentAppId || !academicRecord) return;

    const dummyUpload = (title: string, file: File | null, ocrKey: string) => {
      if (!file) return undefined;
      const details = ocrResults[ocrKey];
      return {
        id: `doc-${Math.floor(Math.random() * 10000)}`,
        title,
        fileName: file.name,
        fileSize: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
        status: details?.fraudAlerts?.isFlagged ? "Error" as const : "Processed" as const,
        ocrExtracted: details,
        crossVerifyResult: {
          isMatch: details ? !details.fraudAlerts?.isFlagged : true,
          issues: details?.issues || []
        },
        fraudAlerts: details?.fraudAlerts
      };
    };

    const newApp: Application = {
      id: currentAppId,
      studentId: student.id,
      rollNo: academicRecord.rollNo,
      regNo: academicRecord.regNo,
      degreeType: selectedDegree,
      academicRecord: academicRecord,
      status: ApplicationStatus.Draft,
      step: stepToSet,
      cnicUpload: dummyUpload("CNIC Identification", cnicFile, "cnic"),
      matricUpload: dummyUpload("Matriculation Marksheet", matricFile, "matric"),
      interUpload: dummyUpload("Intermediate Marksheet", interFile, "inter"),
      degreeUpload: dummyUpload("Degree Certificate", degreeFile, "degree"),
      transcriptUpload: dummyUpload("Academic Transcript", transcriptFile, "transcript"),
      paymentVerified: false,
      paymentAmount: isUrgent ? 7500 : 5000
    };

    try {
      const res = await fetch("/api/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newApp)
      });
      if (res.ok) {
        await onRefreshApplications();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleNextStep = async () => {
    if (wizardStep === 1) {
      setWizardStep(2);
      await submitApplicationMetadata(2);
    } else if (wizardStep === 2) {
      if (!cnicFile) {
        addToast("Please provide an identity CNIC certification file.", "error");
        return;
      }
      if (!ocrResults["cnic"]) {
        addToast("Please run OCR scan on your CNIC first.", "error");
        return;
      }
      setWizardStep(3);
      await submitApplicationMetadata(3);
    } else if (wizardStep === 3) {
      if (!degreeFile || !transcriptFile || !matricFile || !interFile) {
        addToast("Please upload all four academic credentials (Matric, Inter, Transcript, and Degree scroll).", "error");
        return;
      }
      if (!ocrResults["transcript"] || !ocrResults["degree"] || !ocrResults["matric"] || !ocrResults["inter"]) {
        addToast("Please run OCR scans on all four uploaded academic documents to check authenticity.", "error");
        return;
      }
      // Advance to payment step
      setWizardStep(4);
      setPaymentAmount(isUrgent ? 7500 : 5000);
      await submitApplicationMetadata(4);
    }
  };

  const handleUrgentToggle = (val: boolean) => {
    setIsUrgent(val);
    setPaymentAmount(val ? 7500 : 5000);
  };

  const handleProcessPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentAppId) return;

    if (paymentMethod.includes("Crypto")) {
      const cleanTx = cryptoTx.trim();
      if (cleanTx.length < 8) {
        addToast("Please input a valid transaction TX hash (at least 8 characters long).", "error");
        return;
      }
    }

    setIsPaying(true);
    addToast(paymentMethod.includes("Crypto") ? "Verifying cryptographic transaction block confirm seals..." : "Synchronizing with centralized HBL banking routing...", "info");

    // Simulate payment transaction delays
    await new Promise(resolve => setTimeout(resolve, 2000));

    try {
      const txRef = paymentMethod.includes("Crypto") 
        ? cryptoTx.trim()
        : `HBL-${Math.floor(1000000 + Math.random() * 9000000)}`;

      const res = await fetch("/api/payment/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          applicationId: currentAppId,
          method: paymentMethod,
          txRef,
          amount: paymentAmount,
          autopilot: autopilotEnabled
        })
      });

      if (res.ok) {
        if (autopilotEnabled) {
          addToast("Instant ARIA Autopilot Audit Triggered! Verifying database clearance parameters...", "info");
        }
        if (paymentMethod.includes("Crypto")) {
          addToast(`Cryptocurrency payment verified! Your TX reference is: ${txRef}. You can search this hash instantly in the Verification Registry.`, "success");
        } else {
          addToast("Congratulations! Payment matched, dynamic verification queue initialized.", "success");
        }
        setIsWizardOpen(false);
        await onRefreshApplications();
      } else {
        addToast("Failed to lock secure checkout parameters.", "error");
      }
    } catch (err) {
      addToast(paymentMethod.includes("Crypto") ? "Failed to synchronize with blockchain node API." : "Network failure interfacing with HBL OneLink Gateway.", "error");
    } finally {
      setIsPaying(false);
    }
  };

  const handleReceiptUploadAndVerify = async (selectedFile?: File, simType?: "success" | "tampered") => {
    const fileToScan = selectedFile || receiptFile;
    if (!fileToScan && !simType) {
      addToast("Please choose or drag a bank transaction receipt screenshot file first.", "error");
      return;
    }

    if (!currentAppId) return;

    setIsScanningReceipt(true);
    addToast("Interfacing with ARIA Receipt OCR Engine... Parsing transaction details.", "info");

    let base64String = "";
    if (fileToScan) {
      try {
        base64String = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => {
            const resStr = reader.result as string;
            const base = resStr.split(",")[1] || resStr;
            resolve(base);
          };
          reader.onerror = (e) => reject(e);
          reader.readAsDataURL(fileToScan);
        });
      } catch (err) {
        console.error("Base64 reading error:", err);
      }
    }

    let simulatedText = "";
    let fileNameStr = fileToScan?.name || "receipt.png";

    if (simType === "success") {
      fileNameStr = "hbl_payment_success_receipt.png";
      simulatedText = `HBL DIGITAL TRANSACTION RECEIPT
REFERENCE: HBL-90184288
AMOUNT DEPOSITED: PKR ${paymentAmount}
BANK CODE: 023-IQRA-REGISTRY
TIME: ${new Date().toISOString()}
SENDER: ${student?.fullName || "Kamran Shah"}
STATUS: COMPLETED / SECURED`;
    } else if (simType === "tampered") {
      fileNameStr = "tampered_receipt_edited.png";
      simulatedText = `HBL DIGITAL TRANSACTION RECEIPT
REFERENCE: HBL-77121303
AMOUNT DEPOSITED: PKR 350
BANK CODE: 023-IQRA-REGISTRY
TIME: ${new Date().toISOString()}
SENDER: Mishal Malik
STATUS: COMPLETED`;
    }

    try {
      const res = await fetch("/api/payment/verify-receipt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          applicationId: currentAppId,
          screenshotBase64: base64String,
          simulatedText,
          fileName: fileNameStr,
          autopilot: autopilotEnabled,
          method: paymentMethod
        })
      });

      const data = await res.json();
      if (res.ok) {
        if (autopilotEnabled) {
          addToast("Instant ARIA Autopilot Audit Triggered! Verifying database clearance parameters...", "info");
        }
        setReceiptOcrResult(data.ocrDetails);
        addToast("Transaction authenticated! payment verified successfully.", "success");
        setIsWizardOpen(false);
        await onRefreshApplications();
      } else {
        setReceiptOcrResult(data.ocrDetails || { isGenuine: false, mismatchIssues: ["Database comparison fails"] });
        addToast(data.error || "Bank receipt failed auto-verification.", "error");
        await onRefreshApplications();
      }
    } catch (err) {
      console.error(err);
      addToast("Failed to verify transaction receipt via bank connector.", "error");
    } finally {
      setIsScanningReceipt(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 animate-in fade-in duration-300">
      
      {/* Header Panel */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-gray-200 pb-6 mb-8 gap-4">
        <div>
          <button 
            onClick={onBackToHome}
            className="text-xs text-gray-500 hover:text-iqra-green flex items-center gap-1.5 mb-2 cursor-pointer"
          >
            ← Back to institutional entryway
          </button>
          <h1 className="text-3xl font-display font-bold text-gray-900 tracking-tight flex items-center gap-2">
            IQRA VERIFY <span className="text-iqra-gold font-light">Student Hub</span>
          </h1>
          <p className="text-xs text-gray-500 mt-1">Official Degree Attestation and Cryptographic Authenticity Management Portal</p>
        </div>

        {student && (
          <div className="flex items-center gap-3 bg-white p-2.5 px-4 rounded-xl border border-gray-100 shadow-sm">
            <div className="w-10 h-10 rounded-full bg-iqra-green-light flex items-center justify-center text-iqra-green font-bold">
              {student.fullName[0]}
            </div>
            <div>
              <p className="text-xs font-semibold text-gray-900">{student.fullName}</p>
              <p className="text-[10px] text-gray-500 font-mono">{academicRecord?.rollNo}</p>
            </div>
            <button 
              onClick={() => {
                setStudent(null);
                setAcademicRecord(null);
                addToast("Logged out of secure administrative session.", "info");
              }}
              className="text-[10px] text-red-500 hover:underline border-l border-gray-100 pl-3 ml-2 cursor-pointer font-medium"
            >
              Sign out
            </button>
          </div>
        )}
      </div>

      {/* Authentication Phase */}
      {!student ? (
        <div className="max-w-md mx-auto bg-white rounded-2xl border border-gray-100 shadow-xl p-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-iqra-green to-iqra-gold" />
          
          <div className="text-center mb-6">
            <div className="w-14 h-14 rounded-2xl bg-iqra-green-light flex items-center justify-center text-iqra-green mx-auto mb-3 border border-iqra-green/10">
              <User className="w-7 h-7" />
            </div>
            <h2 className="text-xl font-display font-bold text-gray-950">
              {isRegisteringStudent ? "Activate Student Account" : "Student Security Verification"}
            </h2>
            <p className="text-xs text-gray-500 mt-1.5">
              {isRegisteringStudent 
                ? "Register your security profile to access attestation workflows"
                : "Provide official credentials to authorize data synchronization"
              }
            </p>
          </div>

          {/* Toggle Tab */}
          <div className="flex bg-gray-100 p-1 rounded-xl mb-6">
            <button
              type="button"
              onClick={() => {
                setIsRegisteringStudent(false);
                setPassword("");
              }}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer text-center ${!isRegisteringStudent ? "bg-white text-gray-900 shadow-xs font-bold" : "text-gray-500 hover:text-gray-900"}`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setIsRegisteringStudent(true);
                setPassword("");
              }}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer text-center ${isRegisteringStudent ? "bg-white text-gray-900 shadow-xs font-bold" : "text-gray-500 hover:text-gray-900"}`}
            >
              Register Student
            </button>
          </div>

          {!isRegisteringStudent ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">Official Student Email</label>
                <div className="relative">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="student@iqra.edu.pk"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2.5 pl-9 pr-4 text-xs focus:bg-white focus:ring-1 focus:ring-iqra-green outline-none text-gray-800 transition-all font-mono"
                    required
                  />
                  <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">Personal Roll Number</label>
                <div className="relative">
                  <input
                    type="text"
                    value={rollNo}
                    onChange={(e) => setRollNo(e.target.value)}
                    placeholder="IU-BSCS-2022-045"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2.5 pl-9 pr-4 text-xs focus:bg-white focus:ring-1 focus:ring-iqra-green outline-none text-gray-800 transition-all font-mono"
                    required
                  />
                  <Layers className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">Portal Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2.5 px-4 text-xs focus:bg-white focus:ring-1 focus:ring-iqra-green outline-none text-gray-800 transition-all font-mono"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full bg-iqra-green hover:bg-iqra-green-dark text-white rounded-xl py-3 text-xs font-display font-semibold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer mt-2"
              >
                {isLoggingIn ? "Authenticating security channels..." : "Access verified campus directory"}
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">Official Student Email</label>
                <div className="relative">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="student@iqra.edu.pk"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2.5 pl-9 pr-4 text-xs focus:bg-white focus:ring-1 focus:ring-iqra-green outline-none text-gray-800 transition-all font-mono"
                    required
                  />
                  <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">Personal Roll Number</label>
                <div className="relative">
                  <input
                    type="text"
                    value={rollNo}
                    onChange={(e) => setRollNo(e.target.value)}
                    placeholder="IU-BSCS-2022-045"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2.5 pl-9 pr-4 text-xs focus:bg-white focus:ring-1 focus:ring-iqra-green outline-none text-gray-800 transition-all font-mono"
                    required
                  />
                  <Layers className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">National CNIC (13 Digits Only)</label>
                <div className="relative">
                  <input
                    type="text"
                    value={cnic}
                    onChange={(e) => setCnic(e.target.value.replace(/[^0-9]/g, "").slice(0, 13))}
                    maxLength={13}
                    placeholder="4210183921831"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2.5 pl-9 pr-4 text-xs focus:bg-white focus:ring-1 focus:ring-iqra-green outline-none text-gray-800 transition-all font-mono"
                    required
                  />
                  <FileText className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">Created Account Password (Min 6 Characters)</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2.5 px-4 text-xs focus:bg-white focus:ring-1 focus:ring-iqra-green outline-none text-gray-800 transition-all font-mono"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full bg-iqra-gold hover:bg-iqra-gold-dark text-white rounded-xl py-3 text-xs font-display font-semibold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer mt-2"
              >
                {isLoggingIn ? "Interfacing credentials directory..." : "Register Academic Portal Account"}
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* Seed accounts helper list */}
          {showSeedAcc && (
            <div className="mt-8 border-t border-gray-100 pt-5 bg-gray-50/50 p-4 rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded bg-iqra-gold animate-pulse"></span>
                  Quick Access Testing Directory
                </span>
                <button 
                  className="text-[10px] text-gray-400 hover:underline cursor-pointer"
                  onClick={() => setShowSeedAcc(false)}
                >
                  Dismiss
                </button>
              </div>
              <div className="grid grid-cols-1 gap-2">
                <div 
                  onClick={() => handleSeedSelect("IU-BSCS-2022-045")}
                  className="bg-white border hover:border-iqra-green border-gray-200 rounded-lg p-2.5 text-left cursor-pointer transition-all active:scale-95"
                >
                  <p className="text-[11px] font-bold text-gray-800 flex justify-between">
                    Kamran Shah <span className="text-[9px] bg-emerald-50 text-emerald-700 rounded px-1 mt-0.5 font-normal">Eligible (CGPA 3.42)</span>
                  </p>
                  <p className="text-[9px] text-gray-500 font-mono mt-0.5">Roll: IU-BSCS-2022-045 (BSCS)</p>
                </div>
                
                <div 
                  onClick={() => handleSeedSelect("IU-BSSE-2022-094")}
                  className="bg-white border hover:border-red-400 border-gray-200 rounded-lg p-2.5 text-left cursor-pointer transition-all active:scale-95"
                >
                  <p className="text-[11px] font-bold text-gray-800 flex justify-between">
                    Zainab Malik <span className="text-[9px] bg-red-50 text-red-700 rounded px-1 mt-0.5 font-normal">Tamper Simulation (CGPA 2.31)</span>
                  </p>
                  <p className="text-[9px] text-gray-500 font-mono mt-0.5">Roll: IU-BSSE-2022-094 (Low CGPA / Clearance Issue)</p>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Authenticated dashboard area */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Dashboard & applications queue */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* Student metadata Overview card */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 relative overflow-hidden">
              <div className="absolute right-0 top-0 opacity-10 font-display font-extrabold text-9xl text-iqra-green -mr-8 -mt-8 select-none">
                IU
              </div>
              
              <h2 className="text-lg font-display font-bold text-gray-900 mb-4 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-iqra-green" />
                Registrar Enrollment Status
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-gray-50 rounded-xl p-5 border border-gray-100">
                <div className="space-y-2.5 text-xs text-gray-600">
                  <p className="flex justify-between border-b pb-1.5"><span className="font-semibold text-gray-500">Degree Registrant:</span> <span className="text-gray-900 font-semibold">{academicRecord?.degreeTitle}</span></p>
                  <p className="flex justify-between border-b pb-1.5"><span className="font-semibold text-gray-500">Department:</span> <span className="text-gray-900">{academicRecord?.department}</span></p>
                  <p className="flex justify-between border-b pb-1.5"><span className="font-semibold text-gray-500">Registration ID:</span> <span className="text-gray-900 font-mono">{academicRecord?.regNo}</span></p>
                  <p className="flex justify-between pb-0.5"><span className="font-semibold text-gray-500">Graduation Status:</span> <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${academicRecord?.academicStatus === "Completed" ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>{academicRecord?.academicStatus}</span></p>
                </div>

                <div className="space-y-2.5 text-xs text-gray-600">
                  <p className="flex justify-between border-b pb-1.5 items-center">
                    <span className="font-semibold text-gray-500 flex items-center gap-1">
                      Cumulative CGPA:
                      {!isEditingCgpa && (
                        <button
                          onClick={() => {
                            setNewCgpaVal(academicRecord?.cgpa?.toString() || "3.50");
                            setIsEditingCgpa(true);
                          }}
                          className="text-iqra-green hover:underline cursor-pointer font-bold text-[10px]"
                        >
                          (Edit)
                        </button>
                      )}
                    </span>
                    {isEditingCgpa ? (
                      <span className="flex items-center gap-1">
                        <input
                          type="number"
                          step="0.01"
                          min="0.0"
                          max="4.0"
                          value={newCgpaVal}
                          onChange={(e) => setNewCgpaVal(e.target.value)}
                          className="w-16 bg-white border border-gray-200 rounded px-1.5 py-0.5 text-xs text-right font-bold text-gray-900 focus:outline-none font-mono"
                        />
                        <button
                          onClick={handleUpdateCgpa}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] px-2 py-0.5 rounded cursor-pointer"
                        >
                          Save
                        </button>
                        <button
                          onClick={() => setIsEditingCgpa(false)}
                          className="bg-gray-200 hover:bg-gray-300 text-gray-700 text-[10px] px-2 py-0.5 rounded cursor-pointer"
                        >
                          X
                        </button>
                      </span>
                    ) : (
                      <span className="text-gray-900 font-bold font-mono">{academicRecord?.cgpa}</span>
                    )}
                  </p>
                  <p className="flex justify-between border-b pb-1.5"><span className="font-semibold text-gray-500">Completed Credits:</span> <span className="text-gray-900 font-mono">{academicRecord?.creditHours} Hours</span></p>
                  <p className="flex justify-between border-b pb-1.5"><span className="font-semibold text-gray-500">Graduation Date:</span> <span className="text-gray-900 font-mono">{academicRecord?.graduationDate}</span></p>
                  <p className="flex justify-between pb-0.5"><span className="font-semibold text-gray-500">Institutional Clearances:</span> 
                    <span className="flex gap-1">
                      <span className={`w-2.5 h-2.5 rounded-full`} title="Library" style={{ backgroundColor: academicRecord?.libraryClearance === ClearanceStatus.Clear ? "#0A4D2E" : "#C59B27" }}></span>
                      <span className={`w-2.5 h-2.5 rounded-full`} title="Finance" style={{ backgroundColor: academicRecord?.financeClearance === ClearanceStatus.Clear ? "#0A4D2E" : academicRecord?.financeClearance === ClearanceStatus.Flagged ? "#DC2626" : "#C59B27" }}></span>
                      <span className={`w-2.5 h-2.5 rounded-full`} title="Department" style={{ backgroundColor: academicRecord?.departmentClearance === ClearanceStatus.Clear ? "#0A4D2E" : "#C59B27" }}></span>
                    </span>
                  </p>
                </div>
              </div>

              {/* Clearance detailed warnings if Zainab */}
              {academicRecord?.academicStatus === "Incompleted" && (
                <div className="mt-4 bg-red-50 border border-red-100 rounded-xl p-4 flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                  <div className="text-xs">
                    <p className="font-bold text-red-800">Prerequisite Clearances Unresolved</p>
                    <p className="text-red-700 mt-0.5">Your student account contains flagged clearance directives from **Finance & Library divisions**. Academic credits do not satisfy HEC limits (Completed: 110 of 130). You can proceed to upload documents for forensic scanning, but final attestation is blocked at Registrar review.</p>
                  </div>
                </div>
              )}

              {/* Attestation launcher bar */}
              <div className="mt-6 flex flex-col md:flex-row items-stretch md:items-center justify-between border-t border-gray-100 pt-5 gap-3">
                <p className="text-xs text-gray-500 font-light">Verify authenticity elements or launch a new attestation verification request</p>
                <button
                  onClick={handleStartAttestation}
                  className="bg-iqra-green hover:bg-iqra-green-dark text-white text-xs font-display font-semibold py-2 px-5 rounded-xl transition-all shadow cursor-pointer text-center"
                >
                  Apply for Attestation & Verification
                </button>
              </div>

            </div>

            {/* Applications List */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
              <h3 className="text-base font-display font-bold text-gray-950 mb-5 flex items-center gap-1.5">
                <Layers className="w-4.5 h-4.5 text-iqra-gold" />
                Your Verification History ({studentApps.length})
              </h3>

              {studentApps.length === 0 ? (
                <div className="text-center py-10 bg-gray-50/50 rounded-xl border border-dashed border-gray-200">
                  <FileText className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-gray-700">No active applications found</p>
                  <p className="text-[10px] text-gray-400 mt-1 max-w-sm mx-auto">Click 'Apply for Attestation' to initiate the secure 4-step registrar submission wizard.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {studentApps.map((app) => (
                    <div 
                      key={app.id} 
                      className="border border-gray-100 rounded-xl p-5 hover:bg-gray-50 transition-all flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative overflow-hidden"
                    >
                      {app.status === ApplicationStatus.Approved && (
                        <div className="absolute top-0 right-0 w-2 h-full bg-iqra-green" />
                      )}
                      
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-gray-900">{app.id}</span>
                          <span className={`text-[9px] font-mono tracking-wider px-2 py-0.5 rounded-full uppercase font-bold ${
                            app.status === ApplicationStatus.Approved ? "bg-emerald-50 text-emerald-700" :
                            app.status === ApplicationStatus.Rejected ? "bg-red-50 text-red-700" :
                            "bg-amber-50 text-amber-700"
                          }`}>
                            {app.status}
                          </span>
                        </div>
                        <p className="text-[11px] text-gray-600 font-display font-semibold">{app.academicRecord?.degreeTitle}</p>
                        <p className="text-[10px] text-gray-400 font-mono flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5" /> Registered: {new Date(app.submittedAt || "").toLocaleDateString()}
                        </p>
                      </div>

                      {/* Display Actions based on Stage */}
                      <div className="flex flex-wrap items-center gap-2">
                        {app.status === ApplicationStatus.Approved && (
                          <div className="bg-white border border-gray-200 p-2 rounded-lg flex items-center gap-3 shadow-sm hover:border-iqra-gold transition-all">
                            <div className="bg-iqra-gold-light p-1.5 rounded text-iqra-gold">
                              <ShieldCheck className="w-4 h-4" />
                            </div>
                            <div className="text-left text-xs font-mono">
                              <p className="text-[8px] uppercase text-gray-400 leading-none">Security Hash</p>
                              <p className="text-[9px] text-gray-700 font-bold truncate w-28 mt-0.5">{app.verificationHash}</p>
                            </div>
                            {/* Attested Document Link */}
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedCertApp(app);
                                addToast("Inaugurating attested academic certificate viewport.", "success");
                              }}
                              className="text-[10px] text-iqra-green font-bold hover:underline border-l border-gray-150 pl-4 shrink-0 flex items-center gap-1 cursor-pointer bg-transparent border-0"
                            >
                              <FileText className="w-3.5 h-3.5 text-iqra-gold animate-bounce" /> View Certificate
                            </button>
                          </div>
                        )}

                        {app.status === ApplicationStatus.Rejected && (
                          <div className="bg-red-50/50 border border-red-100 p-3 rounded-lg text-left text-xs max-w-sm">
                            <p className="font-bold text-red-800 flex items-center gap-1">
                              <AlertTriangle className="w-3.5 h-3.5" /> Registrar Review Alert:
                            </p>
                            <p className="text-red-700 mt-1 leading-normal text-[10px]">{app.comments || "Credential inconsistencies flagged during identity check."}</p>
                          </div>
                        )}

                        {app.status === ApplicationStatus.Submitted && (
                          <p className="text-[10px] text-amber-700 flex items-center gap-1.5 max-w-xs bg-amber-50 p-2.5 rounded-lg border border-amber-100">
                            <Clock className="w-4 h-4 animate-spin" />
                            Academic files safely routed to HEC & IQRA Review team. Verified instantly / within 1-2 hours.
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

          {/* Right sidebar: Interactive ARIA chatbot module */}
          <div className="lg:col-span-1">
            <div className="sticky top-6 space-y-6">
              
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <h3 className="font-display font-semibold text-sm leading-tight mb-2 text-gray-900 flex items-center gap-2">
                  <Bot className="w-5 h-5 text-iqra-green" />
                  ARIA Registrar Assistant
                </h3>
                <p className="text-[10px] text-gray-500 leading-normal mb-4">
                  Autonomous registrar helper to review missing files, clarify fees, verify matric guidelines, or discuss credit hour validations.
                </p>
                
                <AriaAgent compactMode={true} className="border-0 shadow-none h-[420px]" />
              </div>

              <div className="bg-gradient-to-r from-iqra-green to-iqra-green-dark text-white rounded-2xl p-5 shadow relative overflow-hidden">
                <div className="absolute right-0 bottom-0 text-white/5 -mr-4 -mb-4 font-extrabold text-7xl select-none font-display">
                  IU
                </div>
                <h4 className="font-display font-bold text-xs uppercase tracking-widest text-iqra-gold flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" /> Registrar Code Compliance
                </h4>
                <p className="text-[10px] text-iqra-green-light mt-2.5 leading-relaxed">
                  IQRA VERIFY executes document authentication in total correlation with Pakistan's Higher Education Commission (HEC) and NADRA databases. Attempts to upload photocopied or altered transcript layouts will run into deep digital layer signatures inspection and trigger instant fraud alerts.
                </p>
              </div>

            </div>
          </div>

        </div>
      )}

      {/* --- APPLICATION ATTESTATION WIZARD MODAL --- */}
      {isWizardOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 overflow-y-auto backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full overflow-hidden relative flex flex-col max-h-[90vh]">
            
            {/* Modal Header bar */}
            <div className="bg-iqra-green text-white px-6 py-4 flex items-center justify-between relative shrink-0">
              <div className="absolute top-0 left-0 right-0 h-1 bg-iqra-gold" />
              <div>
                <h2 className="font-display font-bold text-base">Attestation & Verification Application Wizard</h2>
                <p className="text-[10px] text-iqra-green-light mt-0.5 font-mono">App reference ID: {currentAppId}</p>
              </div>
              <button 
                onClick={() => {
                  setIsWizardOpen(false);
                  addToast("Application draft dismissed. State changes discarded.", "info");
                }}
                className="text-xs text-white/80 hover:text-white hover:underline cursor-pointer"
              >
                Cancel Draft
              </button>
            </div>

            {/* Stepper bar */}
            <div className="bg-gray-50 border-b border-gray-100 py-3.5 px-6 grid grid-cols-4 gap-2 text-center text-xs shrink-0">
              {[
                { step: 1, label: "Degree Parameters" },
                { step: 2, label: "CNIC Identification" },
                { step: 3, label: "Academics Upload" },
                { step: 4, label: "Payment Checkout" }
              ].map(s => (
                <div 
                  key={s.step} 
                  className={`flex flex-col md:flex-row items-center justify-center gap-2 ${
                    wizardStep === s.step ? "text-iqra-green font-bold border-b-2 border-iqra-green pb-1" :
                    wizardStep > s.step ? "text-emerald-600 font-medium" : "text-gray-400"
                  }`}
                >
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                    wizardStep === s.step ? "bg-iqra-green text-white" :
                    wizardStep > s.step ? "bg-emerald-500 text-white" : "bg-gray-200 text-gray-500"
                  }`}>
                    {s.step}
                  </span>
                  <span className="hidden md:inline leading-none">{s.label}</span>
                </div>
              ))}
            </div>

            {/* Sub-Step Content */}
            <div className="flex-1 overflow-y-auto p-6 md:p-8">
              
              {/* STEP 1: Degree details and prechecks */}
              {wizardStep === 1 && (
                <div className="space-y-6 max-w-xl mx-auto">
                  <div className="text-center">
                    <h3 className="font-display font-bold text-lg text-gray-900">Define Attestation Target</h3>
                    <p className="text-xs text-gray-500 mt-1">Select matching graduation credentials issued by Iqra University registrar</p>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">Official Degree Coursework Type</label>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {[
                          { id: DegreeType.BS, label: "BS Degree" },
                          { id: DegreeType.MS, label: "MS Degree" },
                          { id: DegreeType.MPhil, label: "MPhil" },
                          { id: DegreeType.PhD, label: "PhD Degree" }
                        ].map(t => (
                          <button
                            key={t.id}
                            type="button"
                            onClick={() => setSelectedDegree(t.id)}
                            className={`border rounded-xl p-3 text-xs font-semibold flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                              selectedDegree === t.id 
                                ? "bg-iqra-green-light border-iqra-green text-iqra-green" 
                                : "bg-white border-gray-200 text-gray-700 hover:bg-gray-50"
                            }`}
                          >
                            {t.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="bg-gray-50 rounded-xl p-4.5 border border-gray-100 flex items-start gap-3">
                      <ShieldCheck className="w-5 h-5 text-iqra-green shrink-0 mt-0.5" />
                      <div className="text-xs text-gray-600">
                        <p className="font-bold text-gray-900">Pre-Attestation Checklist</p>
                        <ul className="list-disc list-inside mt-1.5 space-y-1">
                          <li>National Tax compliance verified.</li>
                          <li>All semesters successfully complete in core academic matrix.</li>
                          <li>CGPA holds minimum value of 2.50 (for attestation).</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-gray-100 flex justify-end">
                    <button
                      onClick={handleNextStep}
                      className="bg-iqra-green hover:bg-iqra-green-dark text-white rounded-xl py-2.5 px-6 text-xs font-display font-semibold transition-all shadow cursor-pointer flex items-center gap-1.5"
                    >
                      Verify parameters & advance <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 2: Identity CNIC Upload */}
              {wizardStep === 2 && (
                <div className="space-y-6 max-w-2xl mx-auto">
                  <div className="text-center">
                    <h3 className="font-display font-bold text-lg text-gray-900 font-sans">Identity Certification System</h3>
                    <p className="text-xs text-gray-500 mt-1">Upload a clear JPG/PNG digital image of your National Identity CNIC card</p>
                  </div>

                  {/* Drag and drop upload */}
                  <div className="border-2 border-dashed border-gray-200 rounded-2xl p-6 text-center hover:bg-gray-50/50 transition-all relative">
                    {cnicFile ? (
                      <div className="space-y-4">
                        <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-100">
                          <CheckCircle2 className="w-8 h-8" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-gray-900">{cnicFile.name}</p>
                          <p className="text-[10px] text-gray-400 mt-0.5">Size: {(cnicFile.size / 1024).toFixed(1)} KB</p>
                        </div>
                        
                        {isScanning["cnic"] ? (
                          <div className="py-2 space-y-1.5 max-w-xs mx-auto">
                            <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                              <div className="h-full bg-iqra-green rounded-full animate-pulse w-2/3"></div>
                            </div>
                            <p className="text-[9px] text-iqra-green font-mono uppercase tracking-widest flex items-center justify-center gap-1">
                              <RefreshCw className="w-3 h-3 animate-spin" /> Performing OCR Forensics...
                            </p>
                          </div>
                        ) : ocrResults["cnic"] ? (
                          <div className="bg-emerald-50/50 border border-emerald-100 rounded-xl p-4 text-left max-w-md mx-auto text-xs space-y-1">
                            <p className="font-bold text-emerald-900">OCR Extracted Metadata:</p>
                            <p className="flex justify-between"><span className="text-gray-500">FullName:</span> <span className="font-mono font-bold text-gray-900">{ocrResults["cnic"].name}</span></p>
                            <p className="flex justify-between"><span className="text-gray-500">CNIC Number:</span> <span className="font-mono text-gray-950 font-bold">{ocrResults["cnic"].cnicNo}</span></p>
                            <p className="flex justify-between"><span className="text-gray-500">Expiry Date:</span> <span className="font-mono text-gray-900">{ocrResults["cnic"].expiryDate}</span></p>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleOcrFileProcess("cnic", cnicFile)}
                            className="bg-iqra-green text-white font-semibold rounded-xl text-xs px-4 py-2 hover:bg-iqra-green-dark transition-all cursor-pointer inline-flex items-center gap-1.5"
                          >
                            <Play className="w-3.5 h-3.5" /> Start OCR Scanning
                          </button>
                        )}
                      </div>
                    ) : (
                      <label className="cursor-pointer space-y-3 block">
                        <UploadCloud className="w-12 h-12 text-gray-300 mx-auto" />
                        <div className="text-xs text-gray-600">
                          <span className="text-iqra-green font-bold hover:underline">Select document</span> or drop file parameters here
                          <p className="text-[10px] text-gray-400 mt-1">PNG, JPG formats up to 5 MB</p>
                        </div>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            if (e.target.files?.[0]) setCnicFile(e.target.files[0]);
                          }}
                          className="hidden"
                        />
                      </label>
                    )}
                  </div>

                  <div className="pt-4 border-t border-gray-100 flex justify-between">
                    <button
                      onClick={() => setWizardStep(1)}
                      className="border border-gray-200 text-gray-600 rounded-xl py-2.5 px-5 text-xs transition-all hover:bg-gray-50 cursor-pointer"
                    >
                      Back
                    </button>
                    <button
                      onClick={handleNextStep}
                      disabled={!ocrResults["cnic"]}
                      className="bg-iqra-green hover:bg-iqra-green-dark text-white rounded-xl py-2.5 px-6 text-xs font-display font-semibold transition-all shadow disabled:opacity-40 cursor-pointer flex items-center gap-1.5"
                    >
                      Continue <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 3: Academic Record Upload and Sweep Scanning */}
              {wizardStep === 3 && (
                <div className="space-y-6">
                  <div className="text-center">
                    <h3 className="font-display font-bold text-lg text-gray-900">Academic Records Submission Portal</h3>
                    <p className="text-xs text-gray-500 mt-1">Upload officially issued academic credentials for OCR forensics inspection & registrar comparisons</p>
                  </div>

                  {/* Inject Tamper Toggle */}
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-center justify-between">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                      <div className="text-xs text-amber-800">
                        <p className="font-bold">Digital Forensics Testing Simulator</p>
                        <p className="text-amber-700 mt-0.5">Toggle this setting to simulate a **manipulated/tampered document alert**. Ideal for demonstrating OCR CGPA fraud detection!</p>
                      </div>
                    </div>
                    <label className="flex items-center gap-2 cursor-pointer shrink-0 ml-4">
                      <span className="text-[10px] font-bold text-amber-900 uppercase">Tamper Files</span>
                      <input
                        type="checkbox"
                        checked={simulateTamper}
                        onChange={(e) => setSimulateTamper(e.target.checked)}
                        className="w-4.5 h-4.5 accent-amber-600 cursor-pointer rounded"
                      />
                    </label>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    {/* Left: Quad upload boxes */}
                    <div className="space-y-4 max-h-[440px] overflow-y-auto pr-2 scrollbar-thin">
                      
                      {/* Matriculation Marksheet Upload */}
                      <div className="bg-white p-4 rounded-xl border border-gray-150 shadow-sm space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Document 1: Matric Marksheet / O-Level Cert</span>
                          <span className="text-[9px] bg-red-150 text-red-800 font-extrabold uppercase px-1 rounded-sm">Required</span>
                        </div>
                        {matricFile ? (
                          <div className="flex items-center justify-between bg-gray-50 p-2.5 rounded-lg">
                            <div className="text-xs truncate max-w-[170px]">
                              <p className="font-bold text-gray-900 truncate">{matricFile.name}</p>
                              <p className="text-[9px] text-gray-400 font-mono mt-0.5">Uploaded • {(matricFile.size / (1024 * 1024)).toFixed(1)} MB</p>
                            </div>
                            <div className="flex gap-2 shrink-0">
                              {ocrResults["matric"] ? (
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${ocrResults["matric"].fraudAlerts?.isFlagged ? "bg-red-50 text-red-600" : "bg-emerald-50 text-emerald-600"}`}>
                                  {ocrResults["matric"].fraudAlerts?.isFlagged ? "Flagged" : "Cleared"}
                                </span>
                              ) : isScanning["matric"] ? (
                                <span className="text-[10px] text-iqra-green font-mono flex items-center gap-1">
                                  <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Scanning
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleOcrFileProcess("matric", matricFile)}
                                  className="text-[10px] bg-iqra-green hover:bg-iqra-green-dark text-white rounded-lg px-2 py-1 cursor-pointer font-semibold"
                                >
                                  Process file
                                </button>
                              )}
                              <button onClick={() => { setMatricFile(null); setOcrResults(prev => { const {...rest} = prev; delete rest.matric; return rest; }); }} className="text-xs text-red-500 hover:underline cursor-pointer">Discard</button>
                            </div>
                          </div>
                        ) : (
                          <label className="border border-dashed border-gray-200 hover:bg-gray-50 rounded-xl p-3 block text-center cursor-pointer transition-all">
                            <UploadCloud className="w-6 h-6 text-gray-300 mx-auto mb-1" />
                            <p className="text-xs font-bold text-gray-700">Official Matric Certificate</p>
                            <p className="text-[9px] text-gray-400 mt-0.5">Drag & drop or Click to browse</p>
                            <input
                              type="file"
                              accept="image/*,application/pdf"
                              onChange={(e) => { if (e.target.files?.[0]) setMatricFile(e.target.files[0]); }}
                              className="hidden"
                            />
                          </label>
                        )}
                      </div>

                      {/* Intermediate Marksheet Upload */}
                      <div className="bg-white p-4 rounded-xl border border-gray-150 shadow-sm space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Document 2: Intermediate Marksheet / A-Level Cert</span>
                          <span className="text-[9px] bg-red-150 text-red-800 font-extrabold uppercase px-1 rounded-sm">Required</span>
                        </div>
                        {interFile ? (
                          <div className="flex items-center justify-between bg-gray-50 p-2.5 rounded-lg">
                            <div className="text-xs truncate max-w-[170px]">
                              <p className="font-bold text-gray-900 truncate">{interFile.name}</p>
                              <p className="text-[9px] text-gray-400 font-mono mt-0.5">Uploaded • {(interFile.size / (1024 * 1024)).toFixed(1)} MB</p>
                            </div>
                            <div className="flex gap-2 shrink-0">
                              {ocrResults["inter"] ? (
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${ocrResults["inter"].fraudAlerts?.isFlagged ? "bg-red-50 text-red-600" : "bg-emerald-50 text-emerald-600"}`}>
                                  {ocrResults["inter"].fraudAlerts?.isFlagged ? "Flagged" : "Cleared"}
                                </span>
                              ) : isScanning["inter"] ? (
                                <span className="text-[10px] text-iqra-green font-mono flex items-center gap-1">
                                  <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Scanning
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleOcrFileProcess("inter", interFile)}
                                  className="text-[10px] bg-iqra-green hover:bg-iqra-green-dark text-white rounded-lg px-2 py-1 cursor-pointer font-semibold"
                                >
                                  Process file
                                </button>
                              )}
                              <button onClick={() => { setInterFile(null); setOcrResults(prev => { const {...rest} = prev; delete rest.inter; return rest; }); }} className="text-xs text-red-500 hover:underline cursor-pointer">Discard</button>
                            </div>
                          </div>
                        ) : (
                          <label className="border border-dashed border-gray-200 hover:bg-gray-50 rounded-xl p-3 block text-center cursor-pointer transition-all">
                            <UploadCloud className="w-6 h-6 text-gray-300 mx-auto mb-1" />
                            <p className="text-xs font-bold text-gray-700">Official Inter Marksheet</p>
                            <p className="text-[9px] text-gray-400 mt-0.5">Drag & drop or Click to browse</p>
                            <input
                              type="file"
                              accept="image/*,application/pdf"
                              onChange={(e) => { if (e.target.files?.[0]) setInterFile(e.target.files[0]); }}
                              className="hidden"
                            />
                          </label>
                        )}
                      </div>

                      {/* Transcript Upload */}
                      <div className="bg-white p-4 rounded-xl border border-gray-150 shadow-sm space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Document 3: University Transcript</span>
                          <span className="text-[9px] bg-red-150 text-red-800 font-extrabold uppercase px-1 rounded-sm">Required</span>
                        </div>
                        {transcriptFile ? (
                          <div className="flex items-center justify-between bg-gray-50 p-2.5 rounded-lg">
                            <div className="text-xs truncate max-w-[170px]">
                              <p className="font-bold text-gray-900 truncate">{transcriptFile.name}</p>
                              <p className="text-[9px] text-gray-400 font-mono mt-0.5">Uploaded • {(transcriptFile.size / (1024 * 1024)).toFixed(1)} MB</p>
                            </div>
                            <div className="flex gap-2 shrink-0">
                              {ocrResults["transcript"] ? (
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${ocrResults["transcript"].fraudAlerts?.isFlagged ? "bg-red-50 text-red-600" : "bg-emerald-50 text-emerald-600"}`}>
                                  {ocrResults["transcript"].fraudAlerts?.isFlagged ? "Failed Flag" : "Cleared"}
                                </span>
                              ) : isScanning["transcript"] ? (
                                <span className="text-[10px] text-iqra-green font-mono flex items-center gap-1">
                                  <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Scanning
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleOcrFileProcess("transcript", transcriptFile)}
                                  className="text-[10px] bg-iqra-green hover:bg-iqra-green-dark text-white rounded-lg px-2 py-1 cursor-pointer font-semibold"
                                >
                                  Process file
                                </button>
                              )}
                              <button onClick={() => { setTranscriptFile(null); setOcrResults(prev => { const {...rest} = prev; delete rest.transcript; return rest; }); }} className="text-xs text-red-500 hover:underline cursor-pointer">Discard</button>
                            </div>
                          </div>
                        ) : (
                          <label className="border border-dashed border-gray-200 hover:bg-gray-50 rounded-xl p-3 block text-center cursor-pointer transition-all">
                            <UploadCloud className="w-6 h-6 text-gray-300 mx-auto mb-1" />
                            <p className="text-xs font-bold text-gray-700">Official Transcript Cert</p>
                            <p className="text-[9px] text-gray-400 mt-0.5">Drag & drop or Click to browse</p>
                            <input
                              type="file"
                              accept="image/*,application/pdf"
                              onChange={(e) => { if (e.target.files?.[0]) setTranscriptFile(e.target.files[0]); }}
                              className="hidden"
                            />
                          </label>
                        )}
                      </div>

                      {/* Degree certificate Upload */}
                      <div className="bg-white p-4 rounded-xl border border-gray-150 shadow-sm space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Document 4: Graduation Degree Certificate</span>
                          <span className="text-[9px] bg-red-150 text-red-800 font-extrabold uppercase px-1 rounded-sm">Required</span>
                        </div>
                        {degreeFile ? (
                          <div className="flex items-center justify-between bg-gray-50 p-2.5 rounded-lg">
                            <div className="text-xs truncate max-w-[170px]">
                              <p className="font-bold text-gray-900 truncate">{degreeFile.name}</p>
                              <p className="text-[9px] text-gray-400 font-mono mt-0.5">Uploaded • {(degreeFile.size / (1024 * 1024)).toFixed(1)} MB</p>
                            </div>
                            <div className="flex gap-2 shrink-0">
                              {ocrResults["degree"] ? (
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${ocrResults["degree"].fraudAlerts?.isFlagged ? "bg-red-50 text-red-600" : "bg-emerald-50 text-emerald-600"}`}>
                                  {ocrResults["degree"].fraudAlerts?.isFlagged ? "Rejected" : "Scanned"}
                                </span>
                              ) : isScanning["degree"] ? (
                                <span className="text-[10px] text-iqra-green font-mono flex items-center gap-1">
                                  <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Scanning
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleOcrFileProcess("degree", degreeFile)}
                                  className="text-[10px] bg-iqra-green hover:bg-iqra-green-dark text-white rounded-lg px-2 py-1 cursor-pointer font-semibold"
                                >
                                  Process file
                                </button>
                              )}
                              <button onClick={() => { setDegreeFile(null); setOcrResults(prev => { const {...rest} = prev; delete rest.degree; return rest; }); }} className="text-xs text-red-500 hover:underline cursor-pointer">Discard</button>
                            </div>
                          </div>
                        ) : (
                          <label className="border border-dashed border-gray-200 hover:bg-gray-50 rounded-xl p-3 block text-center cursor-pointer transition-all">
                            <UploadCloud className="w-6 h-6 text-gray-300 mx-auto mb-1" />
                            <p className="text-xs font-bold text-gray-700">Official Degree Scroll</p>
                            <p className="text-[9px] text-gray-400 mt-0.5">Drag & drop or Click to browse</p>
                            <input
                              type="file"
                              accept="image/*,application/pdf"
                              onChange={(e) => { if (e.target.files?.[0]) setDegreeFile(e.target.files[0]); }}
                              className="hidden"
                            />
                          </label>
                        )}
                      </div>
                    </div>

                    {/* Right: AI OCR laser sweep & live output log */}
                    <div className="bg-gray-900 rounded-2xl p-5 flex flex-col h-[440px] shadow-inner relative overflow-hidden">
                      <div className="absolute top-0 left-0 right-0 h-1 bg-emerald-500/50 shadow-[0_0_10px_#10B981] animate-laser" />
                      
                      <div className="flex items-center justify-between border-b border-gray-800 pb-2 mb-3 z-10">
                        <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1.5 uppercase tracking-wider">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                          ARIA Real-Time OCR Analyzer
                        </span>
                        <span className="text-[8px] font-mono text-gray-500 font-bold uppercase">Console-Log V2.0</span>
                      </div>

                      <div className="flex-1 overflow-y-auto space-y-1 text-[9px] font-mono text-gray-300 z-10 scrollbar-none">
                        {scannerLogs.length === 0 ? (
                          <p className="text-gray-500 italic mt-8 text-center text-xs">Waiting for active document scanning sequence...</p>
                        ) : (
                          scannerLogs.map((log, idx) => (
                            <p key={idx} className={log.includes("CRITICAL") || log.includes("FLAG") ? "text-red-400" : log.includes("SUCCESS") ? "text-emerald-400" : ""}>
                              {log}
                            </p>
                          ))
                        )}
                      </div>
                    </div>

                  </div>

                  {/* Warning message if Tampered */}
                  {ocrResults["transcript"]?.fraudAlerts?.isFlagged && (
                    <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-xs font-medium text-red-800 space-y-1.5">
                      <p className="font-bold flex items-center gap-1.5"><AlertTriangle className="w-5 h-5 text-red-600" /> INSTITUTIONAL SUSPICION METRIC EXPLAINED</p>
                      <p className="text-red-700 leading-relaxed font-normal">
                        Your uploaded transcript exhibits alterations in Cumulative GPA (Detected: {ocrResults["transcript"].cgpa} vs Database: {academicRecord?.cgpa}). Forensic analysis has registered this file. You can still proceed to complete the submit sequence, but the Registrar reviewer will see active deep fraud notifications.
                      </p>
                    </div>
                  )}

                  <div className="pt-4 border-t border-gray-100 flex justify-between">
                    <button
                      onClick={() => setWizardStep(2)}
                      className="border border-gray-200 text-gray-600 rounded-xl py-2.5 px-5 text-xs transition-all hover:bg-gray-50 cursor-pointer"
                    >
                      Back
                    </button>
                    <button
                      onClick={handleNextStep}
                      disabled={!ocrResults["transcript"] || !ocrResults["degree"] || !ocrResults["matric"] || !ocrResults["inter"]}
                      className="bg-iqra-green hover:bg-iqra-green-dark text-white rounded-xl py-2.5 px-6 text-xs font-display font-semibold transition-all shadow disabled:opacity-40 cursor-pointer flex items-center gap-1.5"
                    >
                      Authenticate credentials & pay <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 4: Checkout Payment Portal */}
              {wizardStep === 4 && (
                <div className="max-w-2xl mx-auto space-y-6">
                  <div className="text-center">
                    <h3 className="font-display font-bold text-lg text-gray-900">University Attestation Fee Checkout</h3>
                    <p className="text-xs text-gray-500 mt-1">Settle registrar service fees to lock-in credentials validation workflow</p>
                  </div>

                  {/* AI Autopilot Settings (Glowing Box at the top) */}
                  <div className="bg-gradient-to-r from-emerald-500/10 via-teal-500/5 to-transparent border border-emerald-500/20 rounded-2xl p-4 flex items-start gap-4 shadow-sm">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center shrink-0 border border-emerald-500/25">
                      <Cpu className="w-5 h-5 animate-pulse" />
                    </div>
                    <div className="flex-1 space-y-1 text-left">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold text-gray-950 flex items-center gap-1.5 cursor-pointer select-none">
                          Enable ARIA AI Autopilot Instant Processing
                          <span className="bg-emerald-100 text-emerald-800 text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded-full animate-bounce">
                            Agentless Bypass
                          </span>
                        </label>
                        <input
                          type="checkbox"
                          checked={autopilotEnabled}
                          onChange={(e) => setAutopilotEnabled(e.target.checked)}
                          className="w-5.5 h-5.5 accent-emerald-600 cursor-pointer rounded"
                        />
                      </div>
                      <p className="text-[10px] text-gray-500 leading-relaxed">
                        By checking this option, ARIA will bypass all manual queues. Upon payment clearance, she will automatically crosscheck your document OCR files, verify details against the registry database, check finance and library balances, and instantly grant a secure, signed digital certificate.
                      </p>
                    </div>
                  </div>

                  {/* Payment Verification Mode Tabs */}
                  <div className="grid grid-cols-2 bg-gray-100/80 p-1.5 rounded-xl border border-gray-200">
                    <button
                      type="button"
                      onClick={() => {
                        setActivePaymentTab("screenshot");
                        setPaymentMethod("AI Screenshot OCR");
                      }}
                      className={`py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        activePaymentTab === "screenshot"
                          ? "bg-white text-gray-950 shadow-sm"
                          : "text-gray-500 hover:text-gray-900"
                      }`}
                    >
                      <FileImage className="w-4 h-4" /> AI Screenshot Scan
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setActivePaymentTab("manual");
                        setPaymentMethod("Credit / Debit Card");
                      }}
                      className={`py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        activePaymentTab === "manual"
                          ? "bg-white text-gray-950 shadow-sm"
                          : "text-gray-500 hover:text-gray-900"
                      }`}
                    >
                      <CreditCard className="w-4 h-4" /> Manual Gateway Checkout
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                    
                    {/* LEFT PANEL: Fee summary & Surcharge toggle */}
                    <div className="space-y-4">
                      {/* Fee Card */}
                      <div className="bg-gray-50 rounded-2xl p-5 border border-gray-150 text-left space-y-4">
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Fee Account Details</span>
                        <div className="flex justify-between border-b border-gray-150 pb-3">
                          <span className="text-xs text-gray-500">Degree Attestation Surcharge</span>
                          <span className="font-mono text-gray-900 font-medium">PKR 5,000</span>
                        </div>
                        {isUrgent && (
                          <div className="flex justify-between border-b border-gray-150 pb-3 text-iqra-gold font-bold">
                            <span className="text-xs">Urgent Fast-Track Priority</span>
                            <span className="font-mono">PKR 2,550</span>
                          </div>
                        )}
                        <div className="flex justify-between pt-1">
                          <span className="text-xs font-bold text-gray-900">Total Payable Amount</span>
                          <span className="font-display font-black text-iqra-green text-sm font-mono pb-0.5 border-b-2 border-iqra-green/30">
                            PKR {paymentAmount.toLocaleString()}
                          </span>
                        </div>
                      </div>

                      {/* Fast track toggle */}
                      <div className="border border-gray-100 rounded-xl p-4 bg-gray-50/55 space-y-2 text-left">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-bold text-gray-950 flex flex-col">
                            Urgent Express Priority Route
                            <span className="text-[10px] text-gray-400 font-normal">Dispatched and approved immediately (within 60 seconds via autopilot)</span>
                          </label>
                          <input
                            type="checkbox"
                            checked={isUrgent}
                            onChange={(e) => handleUrgentToggle(e.target.checked)}
                            className="w-5.5 h-5.5 accent-iqra-green cursor-pointer rounded"
                          />
                        </div>
                        <p className="text-[10px] text-iqra-gold font-bold">+ PKR 2,500 priority surcharge applied</p>
                      </div>
                    </div>

                    {/* RIGHT PANEL: Dynamic inputs depending on Tab */}
                    <div>
                      {activePaymentTab === "screenshot" ? (
                        <div className="space-y-4 text-left">
                          <div>
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Step 1: Select Your Payment Method / Channel</span>
                            <select
                              value={paymentMethod}
                              onChange={(e) => setPaymentMethod(e.target.value)}
                              className="w-full bg-white border border-gray-200 rounded-lg py-2 px-3 text-xs outline-none focus:border-iqra-green text-gray-850 transition-all font-bold"
                            >
                              <option value="Easypaisa Wallet Transfer">Easypaisa App Transfer</option>
                              <option value="JazzCash Mobile Wallet">JazzCash App Transfer</option>
                              <option value="HBL University Account Direct Transfer">Habit Bank Limited (HBL) Account Transfer</option>
                              <option value="NayaPay Digital Wallet payment">NayaPay Wallet Account</option>
                              <option value="Iqra National Bank Deposit Slip">Physical Bank Counter Deposit Receipt</option>
                            </select>
                          </div>

                          <div>
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Step 2: Upload Payment Proof Screenshot</span>
                            
                            {/* Receipt Screnshot Drag&Drop Box */}
                            <div className="border-2 border-dashed border-gray-200 rounded-2xl p-5 text-center hover:bg-gray-50/50 transition-all relative">
                            {receiptFile ? (
                              <div className="space-y-4">
                                <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-100">
                                  <CheckCircle2 className="w-6 h-6" />
                                </div>
                                <div className="text-xs">
                                  <p className="font-bold text-gray-900 truncate max-w-[200px] mx-auto">{receiptFile.name}</p>
                                  <p className="text-[9px] text-gray-400">Size: {(receiptFile.size / 1024).toFixed(1)} KB</p>
                                </div>
                              </div>
                            ) : (
                              <label className="cursor-pointer space-y-3 block">
                                <UploadCloud className="w-10 h-10 text-gray-300 mx-auto" />
                                <div className="text-xs text-gray-600">
                                  <span className="text-iqra-green font-bold hover:underline">Select receipt</span> or drag payment screenshot
                                  <p className="text-[9px] text-gray-400 mt-1">HBL, Easypaisa, Nayapay, or deposit slip (Up to 5MB)</p>
                                </div>
                                <input
                                  type="file"
                                  accept="image/*"
                                  onChange={(e) => {
                                    if (e.target.files?.[0]) setReceiptFile(e.target.files[0]);
                                  }}
                                  className="hidden"
                                />
                              </label>
                            )}

                            {isScanningReceipt && (
                              <div className="absolute inset-0 bg-white/95 rounded-2xl flex flex-col justify-center items-center p-4 space-y-2 z-10">
                                <RefreshCw className="w-8 h-8 text-iqra-green animate-spin" />
                                <span className="text-xs font-mono font-bold text-gray-900 animate-pulse tracking-wide uppercase">ARIA SCANNING TRANSACTION...</span>
                                <span className="text-[9px] text-gray-400 text-center">Comparing receipt metadata layer parameters against Pakistani banking gateways.</span>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Quick sandbox simulators */}
                          <div className="bg-gray-50 border border-gray-200 rounded-xl p-3 space-y-2">
                            <span className="text-[9px] font-bold text-gray-500 uppercase tracking-wider block">Sandbox Evaluation Presets</span>
                            <div className="grid grid-cols-1 gap-1.5">
                              <button
                                type="button"
                                disabled={isScanningReceipt}
                                onClick={() => handleReceiptUploadAndVerify(undefined, "success")}
                                className="w-full bg-white hover:bg-emerald-50 text-gray-700 hover:text-emerald-950 border border-gray-250 hover:border-emerald-250 text-left p-2 rounded-lg text-[10px] transition-all cursor-pointer flex items-center justify-between font-medium"
                              >
                                <span className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Success Easypaisa Deposit</span>
                                <span className="text-[9px] font-mono text-emerald-600 font-bold">PKR {paymentAmount}</span>
                              </button>
                              <button
                                type="button"
                                disabled={isScanningReceipt}
                                onClick={() => handleReceiptUploadAndVerify(undefined, "tampered")}
                                className="w-full bg-white hover:bg-rose-50 text-gray-700 hover:text-rose-950 border border-gray-255 hover:border-rose-255 text-left p-2 rounded-lg text-[10px] transition-all cursor-pointer flex items-center justify-between font-medium"
                              >
                                <span className="flex items-center gap-1"><AlertTriangle className="w-3.5 h-3.5 text-rose-500" /> Tampered Slip (Photoshop)</span>
                                <span className="text-[9px] font-mono text-rose-600 font-bold">Ref Flag: Fake PKR 350</span>
                              </button>
                            </div>
                          </div>

                          {/* Trigger scan for custom file */}
                          {receiptFile && (
                            <button
                              type="button"
                              onClick={() => handleReceiptUploadAndVerify()}
                              disabled={isScanningReceipt}
                              className="w-full bg-iqra-green hover:bg-iqra-green-dark text-white rounded-xl py-2.5 font-bold text-xs tracking-wide transition-all shadow cursor-pointer text-center flex items-center justify-center gap-1.5"
                            >
                              <Play className="w-4 h-4" /> Extract & Authorize Custom Receipt
                            </button>
                          )}
                        </div>
                      ) : (
                        <div className="bg-gray-50 rounded-2xl p-5 border border-gray-100 text-xs text-left">
                          {/* Method Selector Dropdown helper */}
                          <div className="mb-4">
                            <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Billing Channel</label>
                            <select
                              value={paymentMethod}
                              onChange={(e) => setPaymentMethod(e.target.value)}
                              className="w-full bg-white border border-gray-200 rounded-lg py-2 px-3 text-xs outline-none focus:border-iqra-green text-gray-800 transition-all font-bold"
                            >
                              <option value="Credit / Debit Card">Credit / Debit Card</option>
                              <option value="Easypaisa Wallet Direct payment">Easypaisa Mobile account billing</option>
                              <option value="JazzCash Portal Direct payment">JazzCash account billing</option>
                              <option value="Secured Cryptocurrency (BTC/USDT)">Secured Cryptocurrency (BTC/USDT)</option>
                            </select>
                          </div>

                          <form onSubmit={handleProcessPayment} className="space-y-4">
                            {paymentMethod.includes("Card") ? (
                              <div className="space-y-3">
                                <div>
                                  <label className="block text-[10px] font-bold text-gray-500 uppercase mb-0.5">Debit Card Number</label>
                                  <input
                                    type="text"
                                    value={cardNumber}
                                    onChange={(e) => setCardNumber(e.target.value)}
                                    placeholder="4321 9081 2132 8923"
                                    className="w-full bg-white border border-gray-200 rounded-lg py-2 px-3 text-xs outline-none focus:border-iqra-green text-gray-800 transition-all font-mono"
                                    required
                                  />
                                </div>
                                <div className="grid grid-cols-2 gap-3">
                                  <div>
                                    <label className="block text-[10px] font-bold text-gray-500 uppercase mb-0.5">Expiry Date</label>
                                    <input
                                      type="text"
                                      value={cardExpiry}
                                      onChange={(e) => setCardExpiry(e.target.value)}
                                      placeholder="MM/YY"
                                      className="w-full bg-white border border-gray-200 rounded-lg py-2 px-3 text-xs outline-none focus:border-iqra-green text-gray-800 transition-all font-mono"
                                      required
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[10px] font-bold text-gray-500 uppercase mb-0.5">CVC Stamp</label>
                                    <input
                                      type="text"
                                      value={cardCvc}
                                      onChange={(e) => setCardCvc(e.target.value)}
                                      placeholder="451"
                                      className="w-full bg-white border border-gray-200 rounded-lg py-2 px-3 text-xs outline-none focus:border-iqra-green text-gray-800 transition-all font-mono"
                                      required
                                    />
                                  </div>
                                </div>
                              </div>
                            ) : paymentMethod.includes("Easypaisa") || paymentMethod.includes("JazzCash") ? (
                              <div className="space-y-3">
                                <div>
                                  <label className="block text-[10px] font-bold text-gray-500 uppercase mb-0.5">Mobile Account Number</label>
                                  <input
                                    type="text"
                                    placeholder="+92 321 8293183"
                                    className="w-full bg-white border border-gray-200 rounded-lg py-2 px-3 text-xs outline-none focus:border-iqra-green text-gray-800 transition-all font-mono"
                                    required
                                  />
                                </div>
                                <p className="text-[10px] text-gray-450">A security checkout verification prompt will appear directly on your mobile app instantly.</p>
                              </div>
                            ) : (
                              // Cryptocurrency portal
                              <div className="space-y-3 font-sans">
                                <div className="flex gap-2">
                                  {["USDT", "BTC", "ETH"].map(c => (
                                    <button
                                      key={c}
                                      type="button"
                                      onClick={() => setCryptoCurrency(c)}
                                      className={`px-2.5 py-1 rounded-lg text-xs font-bold font-mono border ${cryptoCurrency === c ? "bg-iqra-green text-white border-iqra-green" : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"}`}
                                    >
                                      {c}
                                    </button>
                                  ))}
                                </div>
                                <div className="flex justify-between items-center bg-emerald-50 text-emerald-800 p-2.5 rounded-lg border border-emerald-100">
                                  <span className="text-[10px] font-bold uppercase">Rate Converted Amount:</span>
                                  <span className="font-mono text-xs font-black">
                                    {cryptoCurrency === "USDT" && `${(paymentAmount * 0.0036).toFixed(2)} USDT`}
                                    {cryptoCurrency === "BTC" && `${(paymentAmount * 0.00000005).toFixed(7)} BTC`}
                                    {cryptoCurrency === "ETH" && `${(paymentAmount * 0.0000012).toFixed(5)} ETH`}
                                  </span>
                                </div>
                                <div className="bg-white border rounded-xl p-3 text-center space-y-2">
                                  <span className="text-[9px] font-bold uppercase block text-gray-400 font-sans">Official Registrar Wallet</span>
                                  <div className="w-24 h-24 bg-gray-100 mx-auto rounded-lg flex items-center justify-center border">
                                    <QrCode className="w-20 h-20 text-gray-700" />
                                  </div>
                                  <p className="text-[9px] text-gray-800 font-mono break-all font-bold">0x8F7bC2246a48D89e9f3b89E3A39b2CF47FD39AF1</p>
                                </div>
                                <div>
                                  <div className="flex justify-between items-center mb-0.5">
                                    <label className="block text-[10px] font-bold text-gray-500 uppercase">Transaction TX hash</label>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const mockHash = `0x${Array.from({length:40}, () => "0123456789abcdef"[Math.floor(Math.random()*16)]).join("")}`;
                                        setCryptoTx(mockHash);
                                        addToast("Simulated secure blockchain transaction TX hash generated!", "info");
                                      }}
                                      className="text-[9px] text-iqra-green hover:underline cursor-pointer font-bold"
                                    >
                                      Generate Mock TX Hash
                                    </button>
                                  </div>
                                  <input
                                    type="text"
                                    value={cryptoTx}
                                    onChange={(e) => setCryptoTx(e.target.value)}
                                    placeholder="0x932f... or hash reference"
                                    className="w-full bg-white border border-gray-200 rounded-lg py-2 px-3 text-xs outline-none focus:border-iqra-green text-gray-800 transition-all font-mono"
                                    required
                                  />
                                </div>
                              </div>
                            )}

                            <button
                              type="submit"
                              disabled={isPaying}
                              className="w-full bg-iqra-green hover:bg-iqra-green-dark text-white rounded-xl py-3 font-display font-bold text-xs tracking-wide transition-all shadow cursor-pointer text-center"
                            >
                              {isPaying ? "Verifying Transaction Stamp..." : "Authenticate Surcharge & Submit"}
                            </button>
                          </form>
                        </div>
                      )}
                    </div>

                  </div>

                  <div className="pt-4 border-t border-gray-100 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setWizardStep(3)}
                      className="border border-gray-200 text-gray-600 rounded-xl py-2 px-5 text-xs transition-all hover:bg-gray-50 cursor-pointer"
                    >
                      Back to Documents
                    </button>
                  </div>

                </div>
              )}

            </div>

          </div>
        </div>
      )}

      {/* IMMERSIVE CRYPTOGRAPHIC DEGREE ATTESTATION CERTIFICATE VIEWER MODAL */}
      {selectedCertApp && (
        <div className="fixed inset-0 z-55 bg-black/70 backdrop-blur-md flex justify-center items-center p-4 overflow-y-auto animate-in fade-in duration-300">
          <div className="bg-white rounded-3xl max-w-2xl w-full border border-gray-200 overflow-hidden shadow-2xl relative animate-in zoom-in-95 duration-300 flex flex-col max-h-[90vh]">
            
            {/* Header branding */}
            <div className="bg-iqra-green px-6 py-4 flex justify-between items-center shrink-0">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-iqra-gold animate-pulse" />
                <span className="text-xs font-display font-black tracking-wider text-white uppercase animate-pulse">IQRA UNIVERSITY DIGITAL SEAL ATTESTATION</span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedCertApp(null)}
                className="text-white/85 hover:text-white hover:bg-white/10 p-1.5 rounded-lg cursor-pointer transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Certificate body */}
            <div className="flex-1 p-6 md:p-10 overflow-y-auto space-y-8 text-center" id="printable-certificate">
              
              {/* Crest Frame */}
              <div className="border-[6px] border-double border-iqra-gold/50 rounded-2xl p-6 md:p-8 space-y-6 relative bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-white via-zinc-50/10 to-zinc-100/20 shadow-inner">
                
                {/* Watermark Logo */}
                <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] select-none pointer-events-none">
                  <GraduationCap className="w-80 h-80 text-iqra-green" />
                </div>

                {/* Double Logos */}
                <div className="flex justify-between items-center border-b border-gray-150 pb-5">
                  <div className="text-left">
                    <p className="text-[10px] font-black tracking-widest text-iqra-green font-display">IQRA UNIVERSITY</p>
                    <p className="text-[8px] tracking-wider text-gray-400 font-mono">ESTD. 1998 • KARACHI, PAKISTAN</p>
                  </div>
                  <div className="h-10 border border-blue-100 rounded-lg flex items-center justify-center p-1 bg-[#005596] shadow-sm shrink-0">
                    <img 
                      src="https://seeklogo.com/images/I/iqra-university-logo-D5BDE7EAA7-seeklogo.com.png" 
                      alt="Iqra University Official Logo" 
                      className="h-7 object-contain select-none px-1"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-black tracking-widest text-[#006A4E] font-display">HEC PAKISTAN</p>
                    <p className="text-[8px] tracking-wider text-gray-400 font-mono">HIGHER EDUCATION COMMISSION</p>
                  </div>
                </div>

                {/* Certificate Title */}
                <div className="space-y-2">
                  <h2 className="text-2xl md:text-3xl font-display font-black text-gray-950 tracking-tight leading-none uppercase">
                    Certificate of Degree Attestation
                  </h2>
                  <div className="h-[2px] w-28 bg-iqra-gold mx-auto rounded-full" />
                  <p className="text-[10px] text-gray-500 max-w-sm mx-auto leading-relaxed mt-2 font-medium">
                    This is to verify and officially seal that the Higher Education Commission & Iqra University Registrar's Directorate have verified and matched the undermentioned credentials with secure, high-integrity student record indexes.
                  </p>
                </div>

                {/* Graduate Particulars */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left font-sans text-xs bg-gray-50/50 p-4 rounded-xl border border-gray-100">
                  <div className="space-y-1">
                    <span className="text-[9px] uppercase font-bold text-gray-400 tracking-wider">Candidate Name</span>
                    <p className="font-bold text-gray-900 text-sm">{selectedCertApp.academicRecord?.fullName || student?.fullName || "Iqra Alumni"}</p>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[9px] uppercase font-bold text-gray-400 tracking-wider">Degree Verified & Attested</span>
                    <p className="font-bold text-iqra-green text-sm">{selectedCertApp.academicRecord?.degreeTitle || selectedCertApp.degreeType}</p>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[9px] uppercase font-bold text-gray-400 tracking-wider">Reg / Serialization ID</span>
                    <p className="font-bold text-gray-900 font-mono">{selectedCertApp.regNo || "Not Assigned"}</p>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[9px] uppercase font-bold text-gray-400 tracking-wider">Cumulative GPA (CGPA)</span>
                    <p className="font-bold text-gray-900 font-mono">{selectedCertApp.academicRecord?.cgpa || "3.50"} / 4.00</p>
                  </div>
                </div>

                {/* Secure Cryptographic Seals */}
                <div className="border-t border-gray-150 pt-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 text-left">
                  <div className="space-y-1 max-w-xs">
                    <span className="text-[9px] uppercase font-bold text-gray-400 tracking-wider block">Security Hash Stamp Seal</span>
                    <p className="font-mono text-[9px] font-bold text-gray-700 break-all select-all leading-normal bg-gray-100 p-2 rounded-lg border border-gray-200">
                      {selectedCertApp.verificationHash}
                    </p>
                  </div>
                  
                  {/* QR code and status stamp */}
                  <div className="flex items-center gap-3 bg-emerald-50 rounded-xl p-3 border border-emerald-100">
                    <QrCode className="w-10 h-10 text-emerald-800" />
                    <div>
                      <p className="font-mono text-[8px] font-bold text-emerald-600 leading-none">STATUS: SECURE SEALED</p>
                      <p className="text-[10px] font-black text-emerald-850 mt-1 uppercase">Attested & Verified</p>
                      <p className="text-[8px] text-emerald-700 leading-none mt-0.5">SHA-256 Ledger Block Encoded</p>
                    </div>
                  </div>
                </div>

                {/* Signatures */}
                <div className="grid grid-cols-2 gap-4 border-t border-gray-150 pt-5 text-center text-[10px] text-gray-400 font-mono">
                  <div className="space-y-1">
                    <div className="h-4 flex items-center justify-center font-serif font-bold italic text-gray-800 text-xs">
                      Aiman Fareed
                    </div>
                    <div className="border-t border-gray-200 pt-1">
                      <p className="font-bold uppercase text-gray-700 text-[8px]">Iqra Registrar Directorate</p>
                      <p className="text-[7px]">Authorized Signatory</p>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="h-4 flex items-center justify-center font-display font-bold italic text-gray-800 font-sans">
                      HEC.Attestation.Dept
                    </div>
                    <div className="border-t border-gray-200 pt-1">
                      <p className="font-bold uppercase text-gray-700 text-[8px]">HEC Pakistan Commission</p>
                      <p className="text-[7px]">Dynamic Verification Seal</p>
                    </div>
                  </div>
                </div>

              </div>

            </div>

            {/* Footer buttons */}
            <div className="bg-gray-50 px-6 py-4 border-t border-gray-150 flex justify-end gap-3 shrink-0">
              <button
                type="button"
                onClick={() => window.print()}
                className="bg-white hover:bg-gray-50 text-gray-800 rounded-xl py-2.5 px-5 text-[11px] font-display font-bold select-none cursor-pointer border border-gray-200 flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" /> Print / Save PDF
              </button>
              <button
                type="button"
                onClick={() => setSelectedCertApp(null)}
                className="bg-iqra-green hover:bg-iqra-green-dark text-white rounded-xl py-2.5 px-5 text-[11px] font-display font-medium select-none cursor-pointer"
              >
                Close Certificate
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
