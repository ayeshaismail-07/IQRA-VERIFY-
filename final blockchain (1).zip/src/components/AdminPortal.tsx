/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  User, Lock, ShieldCheck, Database, FileText, AlertTriangle, Play, CheckCircle2, 
  X, RefreshCw, Layers, TrendingUp, DollarSign, Clock, LayoutDashboard, Settings, ListCollapse, HelpCircle, Check, ArrowRight, Cpu, Zap
} from "lucide-react";
import { Application, ApplicationStatus, ClearanceStatus, FraudAlert, AuditLog, IqraDbRecord } from "../types";

interface AdminPortalProps {
  onBackToHome: () => void;
  applications: Application[];
  onRefreshApplications: () => Promise<void>;
  addToast: (message: string, type: "success" | "error" | "info") => void;
}

export default function AdminPortal({ onBackToHome, applications, onRefreshApplications, addToast }: AdminPortalProps) {
  const [adminUser, setAdminUser] = useState<{ fullName: string; email: string; role: string } | null>(null);
  
  // Auth Form
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [adminRole, setAdminRole] = useState("Registrar"); // Registrar, Verification Officer
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isRegisteringAdmin, setIsRegisteringAdmin] = useState(false);
  const [adminRegisterName, setAdminRegisterName] = useState("");
  
  // Dashboard Sub-Views
  const [activeTab, setActiveTab] = useState<"applications" | "fraud" | "records" | "audit" | "config">("applications");
  
  // Review Modal State
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);
  const [reviewComments, setReviewComments] = useState("");
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  
  // System State Analytics
  const [analytics, setAnalytics] = useState<any>({
    total: 0, approved: 0, pending: 0, rejected: 0, revenue: 0, fraudAttempts: 0,
    departmentDistribution: [], fraudSeverity: []
  });
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [auditFilter, setAuditFilter] = useState<"All" | "Success" | "Discrepancy">("All");
  const [fraudAlertsList, setFraudAlertsList] = useState<FraudAlert[]>([]);
  const [allRecords, setAllRecords] = useState<IqraDbRecord[]>([]);

  // Config State
  const [configMinCgpa, setConfigMinCgpa] = useState(2.50);

  // Student Registration Form State
  const [isRegistering, setIsRegistering] = useState(false);
  const [regRollNo, setRegRollNo] = useState("");
  const [regRegNo, setRegRegNo] = useState("");
  const [regFullName, setRegFullName] = useState("");
  const [regCnic, setRegCnic] = useState("");
  const [regDegreeTitle, setRegDegreeTitle] = useState("Bachelor of Science in Computer Science");
  const [regDepartment, setRegDepartment] = useState("Department of Computing & Technology");
  const [regCgpa, setRegCgpa] = useState("3.42");
  const [regCreditHours, setRegCreditHours] = useState("134");
  const [regGraduationDate, setRegGraduationDate] = useState("2026-06-01");
  const [regAcademicStatus, setRegAcademicStatus] = useState<"Completed" | "Incompleted" | "Suspended">("Completed");
  const [regLibraryClearance, setRegLibraryClearance] = useState<ClearanceStatus>(ClearanceStatus.Clear);
  const [regFinanceClearance, setRegFinanceClearance] = useState<ClearanceStatus>(ClearanceStatus.Clear);
  const [regDepartmentClearance, setRegDepartmentClearance] = useState<ClearanceStatus>(ClearanceStatus.Clear);
  const [isSubmittingRegistration, setIsSubmittingRegistration] = useState(false);

  useEffect(() => {
    if (adminUser) {
      fetchSystemData();
    }
  }, [adminUser, applications]);

  const fetchSystemData = async () => {
    try {
      // Analytics
      const aRes = await fetch("/api/system/analytics");
      const aData = await aRes.json();
      setAnalytics(aData);

      // Audit logs
      const auRes = await fetch("/api/system/audit");
      const auData = await auRes.json();
      setAuditLogs(auData);

      // Fetch records dynamically
      const rRes = await fetch("/api/records");
      const rData = await rRes.json();
      setAllRecords(rData);

      // Fetch actual backend fraud alerts dynamically instead of hardcoding mock data
      const fRes = await fetch("/api/fraud");
      const fData = await fRes.json();
      setFraudAlertsList(fData);

    } catch (e) {
      console.error("Failed to load registrar dashboard analytics parameters:", e);
    }
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      addToast("Please input valid administrator credentials.", "error");
      return;
    }
    setIsLoggingIn(true);
    
    try {
      const res = await fetch("/api/auth/admin-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, role: adminRole })
      });
      const data = await res.json();
      if (res.ok) {
        setAdminUser(data.admin);
        addToast(`Welcome back, ${data.admin.fullName}`, "success");
      } else {
        addToast(data.error || "Access Denied.", "error");
      }
    } catch (err) {
      addToast("Failed to connect with internal auth gateway.", "error");
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleAdminRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim() || !adminRegisterName.trim()) {
      addToast("Please input all administrator registration details.", "error");
      return;
    }
    if (!email.includes("@")) {
      addToast("Please enter a valid format email address.", "error");
      return;
    }
    if (!email.endsWith("@iqra.edu.pk")) {
      addToast("Registering administrator with testing path override.", "info");
    }
    setIsLoggingIn(true);
    try {
      const res = await fetch("/api/auth/admin-register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, fullName: adminRegisterName, role: adminRole })
      });
      const data = await res.json();
      if (res.ok) {
        addToast(`Registered as authorized ${adminRole}! You may now sign in.`, "success");
        setIsRegisteringAdmin(false);
        setPassword("");
      } else {
        addToast(data.error || "Registration denied.", "error");
      }
    } catch (err) {
      addToast("Failed to connect with central administrative registration API.", "error");
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handlePresetSelect = (role: string) => {
    setAdminRole(role);
    setEmail(role === "Registrar" ? "registrar@iqra.edu.pk" : "verification@iqra.edu.pk");
    setPassword("iqraAdminPass");
  };

  const handleAppReviewSubmit = async (status: "Approved" | "Rejected") => {
    if (!selectedApp) return;
    if (status === "Rejected" && !reviewComments.trim()) {
      addToast("Please provide detailed rejection notes explaining document mismatches.", "error");
      return;
    }

    setIsSubmittingReview(true);
    try {
      const res = await fetch(`/api/applications/${selectedApp.id}/review`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status,
          comments: reviewComments,
          registrarName: adminUser?.fullName || "Registrar Officer"
        })
      });

      if (res.ok) {
        addToast(`Application successfully ${status.toLowerCase()} and signed!`, "success");
        setSelectedApp(null);
        setReviewComments("");
        await onRefreshApplications();
      } else {
        addToast("Error locking administrative review decision.", "error");
      }
    } catch (e) {
      addToast("Network failure addressing Registrar server route.", "error");
    } finally {
      setIsSubmittingReview(false);
    }
  };

  const [isSweeping, setIsSweeping] = useState(false);

  const handleAutopilotSweep = async () => {
    setIsSweeping(true);
    addToast("Initializing ARIA Autonomous Registrar Autopilot Sweep...", "info");
    try {
      const res = await fetch("/api/admin/autopilot-sweep", {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      const data = await res.json();
      if (res.ok) {
        addToast(`Autopilot sweep successfully completed! Approved: ${data.processed}. Skipped/Flagged: ${data.skipped}.`, "success");
        await onRefreshApplications();
        await fetchSystemData();
      } else {
        addToast("Error running ARIA Autopilot Sweep.", "error");
      }
    } catch (e) {
      addToast("Failed to interface with Central Autonomous Auditing Server.", "error");
    } finally {
      setIsSweeping(false);
    }
  };

  const handleResolveAlert = async (alertId: string) => {
    try {
      const res = await fetch(`/api/fraud/${alertId}/resolve`, { method: "POST" });
      if (res.ok) {
        addToast("Marked fraud alert as resolved inside registry logs.", "success");
        await onRefreshApplications();
        await fetchSystemData();
        
        // If reviewing this application, update selectedApp reference so approval/button is un-unlocked!
        if (selectedApp) {
          setSelectedApp(prev => {
            if (!prev) return null;
            return {
              ...prev,
              transcriptUpload: prev.transcriptUpload ? {
                ...prev.transcriptUpload,
                fraudAlerts: prev.transcriptUpload.fraudAlerts ? {
                  ...prev.transcriptUpload.fraudAlerts,
                  isFlagged: false,
                  score: 0,
                  indicators: []
                } : undefined
              } : undefined
            };
          });
        }
      }
    } catch (err) {
      addToast("Failed to process alert closure.", "error");
    }
  };

  const handleRegisterStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regRollNo.trim() || !regRegNo.trim() || !regFullName.trim() || !regCnic.trim()) {
      addToast("Please fill in all mandatory identity and serial fields.", "error");
      return;
    }

    const gpaVal = parseFloat(regCgpa);
    if (isNaN(gpaVal) || gpaVal < 0 || gpaVal > 4.0) {
      addToast("CGPA must be a valid number between 0.00 and 4.00.", "error");
      return;
    }

    const creditsVal = parseInt(regCreditHours);
    if (isNaN(creditsVal) || creditsVal < 0) {
      addToast("Completed Credits must be a positive number.", "error");
      return;
    }

    setIsSubmittingRegistration(true);

    const checkRecord = {
      rollNo: regRollNo.trim().toUpperCase(),
      regNo: regRegNo.trim().toUpperCase(),
      fullName: regFullName.trim(),
      cnic: regCnic.trim(),
      degreeTitle: regDegreeTitle,
      department: regDepartment,
      cgpa: gpaVal,
      creditHours: creditsVal,
      graduationDate: regGraduationDate,
      academicStatus: regAcademicStatus,
      libraryClearance: regLibraryClearance,
      financeClearance: regFinanceClearance,
      departmentClearance: regDepartmentClearance
    };

    try {
      const res = await fetch("/api/records", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(checkRecord)
      });
      if (res.ok) {
        addToast(`Successfully registered database enrollee record for ${regFullName}!`, "success");
        setIsRegistering(false);
        // Reset non-default fields
        setRegRollNo("");
        setRegRegNo("");
        setRegFullName("");
        setRegCnic("");
        // Refresh records in state
        await fetchSystemData();
      } else {
        addToast("Internal Server Error processing register action.", "error");
      }
    } catch (err) {
      addToast("Failed to establish secure connection with local registrar DB.", "error");
    } finally {
      setIsSubmittingRegistration(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 animate-in fade-in duration-300">
      
      {/* Head banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-gray-200 pb-6 mb-8 gap-4">
        <div>
          <button 
            onClick={onBackToHome}
            className="text-xs text-gray-500 hover:text-iqra-green flex items-center gap-1.5 mb-2 cursor-pointer font-sans"
          >
            ← Back to main entryway
          </button>
          <h1 className="text-3xl font-display font-bold text-gray-900 tracking-tight flex items-center gap-2">
            IQRA VERIFY <span className="text-iqra-gold font-light">Registrar & Officer Console</span>
          </h1>
          <p className="text-xs text-gray-500 mt-1">Institutional auditing, file verification workflow queue, and forensics dashboard</p>
        </div>

        {adminUser && (
          <div className="flex items-center gap-3 bg-white p-2.5 px-4 rounded-xl border border-gray-100 shadow-sm">
            <div className="w-10 h-10 rounded-full bg-iqra-gold-light flex items-center justify-center text-iqra-gold-dark font-extrabold text-sm">
              AD
            </div>
            <div>
              <p className="text-xs font-semibold text-gray-900">{adminUser.fullName}</p>
              <p className="text-[10px] text-gray-500 font-mono flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                Authorized Level: {adminUser.role}
              </p>
            </div>
            <button 
              onClick={() => {
                setAdminUser(null);
                addToast("Administrative session closed safely.", "info");
              }}
              className="text-[10px] text-red-500 hover:underline border-l border-gray-100 pl-3 ml-2 cursor-pointer font-medium"
            >
              Log out
            </button>
          </div>
        )}
      </div>

      {/* Admin Authentication Card */}
      {!adminUser ? (
        <div className="max-w-md mx-auto bg-white rounded-2xl border border-gray-100 shadow-xl p-8 relative overflow-hidden animate-in fade-in duration-300">
          <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-iqra-gold to-iqra-green" />
          
          <div className="text-center mb-6">
            <div className="w-14 h-14 rounded-2xl bg-iqra-gold-light text-iqra-gold mx-auto mb-3 border border-iqra-gold/15 flex items-center justify-center">
              <Lock className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-display font-bold text-gray-950">
              {isRegisteringAdmin ? "Administrative Registration" : "Administrative Seal Login"}
            </h2>
            <p className="text-xs text-gray-500 mt-1.5 font-sans">
              {isRegisteringAdmin 
                ? "Register a new official university audit credential" 
                : "Access registrar reviews and cryptographic credential attestation"
              }
            </p>
          </div>

          {/* Toggle Tab */}
          <div className="flex bg-gray-100 p-1 rounded-xl mb-6">
            <button
              type="button"
              onClick={() => {
                setIsRegisteringAdmin(false);
                setPassword("");
              }}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer text-center ${!isRegisteringAdmin ? "bg-white text-gray-900 shadow-xs font-bold" : "text-gray-500 hover:text-gray-900"}`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setIsRegisteringAdmin(true);
                setPassword("");
              }}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer text-center ${isRegisteringAdmin ? "bg-white text-gray-900 shadow-xs font-bold" : "text-gray-500 hover:text-gray-900"}`}
            >
              Register Admin
            </button>
          </div>

          {!isRegisteringAdmin ? (
            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">Administrative Role</label>
                <div className="grid grid-cols-2 gap-3">
                  {["Registrar", "Verification Officer"].map(role => (
                    <button
                      key={role}
                      type="button"
                      onClick={() => setAdminRole(role)}
                      className={`border rounded-xl p-3 text-xs font-semibold transition-all cursor-pointer text-center ${
                        adminRole === role 
                          ? "bg-iqra-gold-light border-iqra-gold text-iqra-gold-dark font-bold" 
                          : "bg-white border-gray-200 text-gray-700 hover:bg-gray-50"
                      }`}
                    >
                      {role}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">Official Admin Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="registrar@iqra.edu.pk"
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2.5 px-4 text-xs focus:bg-white focus:ring-1 focus:ring-iqra-green outline-none text-gray-800 transition-all font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">Security Code Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2.5 px-4 text-xs focus:bg-white focus:ring-1 focus:ring-iqra-green outline-none text-gray-800 transition-all font-mono"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full bg-iqra-green hover:bg-iqra-green-dark text-white rounded-xl py-3 text-xs font-display font-bold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer mt-2"
              >
                {isLoggingIn ? "Syncing administration key tunnels..." : "Access Administrative Dashboard"}
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <form onSubmit={handleAdminRegister} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">Administrative Role Target</label>
                <div className="grid grid-cols-2 gap-3">
                  {["Registrar", "Verification Officer"].map(role => (
                    <button
                      key={role}
                      type="button"
                      onClick={() => setAdminRole(role)}
                      className={`border rounded-xl p-3 text-xs font-semibold transition-all cursor-pointer text-center ${
                        adminRole === role 
                          ? "bg-iqra-gold-light border-iqra-gold text-iqra-gold-dark font-bold" 
                          : "bg-white border-gray-200 text-gray-700 hover:bg-gray-50"
                      }`}
                    >
                      {role}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">Official Full Name</label>
                <input
                  type="text"
                  value={adminRegisterName}
                  onChange={(e) => setAdminRegisterName(e.target.value)}
                  placeholder="Dean / Registrar Registrar"
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2.5 px-4 text-xs focus:bg-white focus:ring-1 focus:ring-iqra-green outline-none text-gray-800 transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">Official Admin Email (@iqra.edu.pk)</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name.admin@iqra.edu.pk"
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2.5 px-4 text-xs focus:bg-white focus:ring-1 focus:ring-iqra-green outline-none text-gray-800 transition-all font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1.5">Security Code Password (Min 6 Characters)</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2.5 px-4 text-xs focus:bg-white focus:ring-1 focus:ring-iqra-green outline-none text-gray-800 transition-all font-mono"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full bg-iqra-gold hover:bg-iqra-gold-dark text-white rounded-xl py-3 text-xs font-display font-bold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer mt-2"
              >
                {isLoggingIn ? "Registering administration key tunnels..." : "Register Official Admin Account"}
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* Presets */}
          <div className="mt-8 border-t border-gray-100 pt-5 text-center">
            <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider block mb-3">Admin Presets Seed</span>
            <div className="grid grid-cols-2 gap-2">
              <button 
                onClick={() => {
                  setIsRegisteringAdmin(false);
                  handlePresetSelect("Registrar");
                }}
                className="hover:border-iqra-green/35 text-[11px] font-semibold text-gray-700 border border-gray-200 rounded-xl p-2 cursor-pointer bg-gray-50/50"
              >
                Registrar Profile
              </button>
              <button 
                onClick={() => {
                  setIsRegisteringAdmin(false);
                  handlePresetSelect("Verification Officer");
                }}
                className="hover:border-iqra-gold/35 text-[11px] font-semibold text-gray-700 border border-gray-200 rounded-xl p-2 cursor-pointer bg-gray-50/50"
              >
                Officer Profile
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Authenticated Admin Dashboard */
        <div className="space-y-8">
          
          {/* Quick Metrics grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              { label: "Active Submissions", number: analytics.total || 0, sub: `${analytics.pending} pending reviews`, icon: <Layers className="w-5 h-5 text-iqra-green" />, bg: "bg-white" },
              { label: "Approved Certificates", number: analytics.approved || 0, sub: "Cryptographically locked", icon: <ShieldCheck className="w-5 h-5 text-emerald-600" />, bg: "bg-white" },
              { label: "Fraud Attempts Flagged", number: analytics.fraudAttempts || 0, sub: "High integrity severity", icon: <AlertTriangle className="w-5 h-5 text-red-600" />, bg: "bg-red-50/50 border border-red-100" },
              { label: "Revenue Surcharges", number: `PKR ${(analytics.revenue || 0).toLocaleString()}`, sub: "Attestation fees sync", icon: <DollarSign className="w-5 h-5 text-iqra-gold" />, bg: "bg-white" }
            ].map((m, idx) => (
              <div key={idx} className={`p-5 rounded-2xl border border-gray-150 shadow-sm flex items-center justify-between gap-4 ${m.bg}`}>
                <div className="space-y-1.5 text-left">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">{m.label}</span>
                  <span className="text-xl font-display font-extrabold text-gray-900 block leading-none">{m.number}</span>
                  <span className="text-[10px] text-gray-500 block">{m.sub}</span>
                </div>
                <div className="p-3 bg-gray-100 rounded-xl shrink-0">
                  {m.icon}
                </div>
              </div>
            ))}
          </div>

          {/* Navigation Sub-Tabs */}
          <div className="flex border-b border-gray-250 gap-2 shrink-0 overflow-x-auto whitespace-nowrap pb-1 scrollbar-none text-xs">
            {[
              { id: "applications", label: "Verification Queue", icon: <Layers className="w-4 h-4" /> },
              { id: "fraud", label: "Forensic Fraud Monitor", icon: <AlertTriangle className="w-4 h-4" /> },
              { id: "records", label: "University Database Records", icon: <Database className="w-4 h-4" /> },
              { id: "audit", label: "System Audit Trails", icon: <FileText className="w-4 h-4" /> },
              { id: "config", label: "HEC Parameters Adjust", icon: <Settings className="w-4 h-4" /> }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-2 px-4 rounded-t-xl font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === tab.id 
                    ? "bg-white border-x border-t border-gray-200 text-iqra-green font-bold text-sm" 
                    : "text-gray-500 hover:text-gray-800"
                }`}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>

          {/* Sub-View Content */}
          <div className="bg-white rounded-2xl border border-gray-150 p-6 min-h-[400px]">
            
            {/* TAP 1: APPLICATIONS QUEUE */}
            {activeTab === "applications" && (
              <div className="space-y-6 text-left">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 animate-in fade-in">
                  <div>
                    <h3 className="font-display font-bold text-base text-gray-950">Institutional Attestation Queue</h3>
                    <p className="text-xs text-gray-500 mt-1">Review student credentials, view side-by-side OCR forensics audits, and issue golden seals.</p>
                  </div>
                  <div className="shrink-0">
                    <button
                      onClick={handleAutopilotSweep}
                      disabled={isSweeping}
                      className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 text-white rounded-xl py-2.5 px-4 text-xs font-bold transition-all shadow-md cursor-pointer flex items-center gap-1.5 shrink-0 border border-emerald-500/20"
                    >
                      <Cpu className={`w-4 h-4 ${isSweeping ? "animate-spin" : "animate-pulse"}`} />
                      {isSweeping ? "Processing Sweep..." : "Let ARIA AI Autopilot Process All"}
                    </button>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left border-collapse">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-200 text-gray-500 font-bold uppercase text-[9px] tracking-wider">
                        <th className="p-3.5">App Reference</th>
                        <th className="p-3.5">Registrant Student</th>
                        <th className="p-3.5">Degree Sourced</th>
                        <th className="p-3.5">Registration ID</th>
                        <th className="p-3.5">Review Status</th>
                        <th className="p-3.5 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {applications.map((app) => (
                        <tr key={app.id} className="hover:bg-gray-50/50 transition-all">
                          <td className="p-3.5 font-bold font-mono text-gray-850">{app.id}</td>
                          <td className="p-3.5">
                            <div>
                              <p className="font-bold text-gray-900">{app.academicRecord?.fullName || "Iqra Student"}</p>
                              <p className="text-[10px] text-gray-400 font-mono">{app.rollNo}</p>
                            </div>
                          </td>
                          <td className="p-3.5">{app.academicRecord?.degreeTitle || app.degreeType}</td>
                          <td className="p-3.5 font-mono text-gray-700">{app.regNo}</td>
                          <td className="p-3.5">
                            <span className={`px-2 py-0.5 rounded-full text-[9px] uppercase font-bold font-mono tracking-wider ${
                              app.status === ApplicationStatus.Approved ? "bg-emerald-50 text-emerald-700" :
                              app.status === ApplicationStatus.Rejected ? "bg-red-50 text-red-700" :
                              "bg-amber-50 text-amber-700"
                            }`}>
                              {app.status}
                            </span>
                          </td>
                          <td className="p-3.5 text-right">
                            {app.status === ApplicationStatus.Submitted || app.status === ApplicationStatus.UnderReview ? (
                              <button
                                onClick={() => {
                                  setSelectedApp(app);
                                  setReviewComments(app.comments || "");
                                }}
                                className="bg-iqra-green hover:bg-iqra-green-dark text-white rounded-lg px-3.5 py-1.5 text-[11px] font-semibold cursor-pointer transition-all"
                              >
                                Review Document
                              </button>
                            ) : (
                              <button
                                onClick={() => {
                                  setSelectedApp(app);
                                  setReviewComments(app.comments || "");
                                }}
                                className="text-gray-500 hover:text-gray-800 text-[11px] font-semibold cursor-pointer border border-gray-200 rounded-lg px-3.5 py-1.5 hover:bg-gray-50 transition-all"
                              >
                                View File
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* TAB 2: FRAUD AND LAYER FORENSICS */}
            {activeTab === "fraud" && (
              <div className="space-y-6 text-left">
                <div>
                  <h3 className="font-display font-bold text-base text-gray-950 flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-red-600 animate-pulse" />
                    Digital Forensics Integrity Board
                  </h3>
                  <p className="text-xs text-gray-500 mt-1">Real-time alerts generated across transcripts, Golden University seals, Adobe Photoshop CC vectors metadata matches.</p>
                </div>

                {fraudAlertsList.length === 0 ? (
                  <div className="text-center py-12 bg-gray-50 text-gray-500 rounded-xl border border-dashed text-xs space-y-1">
                    <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                    <p className="font-bold">Registry status: Flawless</p>
                    <p className="text-[10px] text-gray-400">All submitted documents satisfy forensic EXIF and signature coordinate integrity layers.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {fraudAlertsList.map((alert) => (
                      <div key={alert.id} className="border border-red-150 bg-red-50/10 rounded-2xl p-5 space-y-3 relative overflow-hidden flex flex-col justify-between">
                        <div className="absolute top-0 right-0 p-2 bg-red-100 text-red-800 text-[9px] font-bold uppercase rounded-bl-xl font-mono tracking-wider">{alert.severity} Risk</div>
                        
                        <div className="space-y-1.5">
                          <span className="text-[9px] font-bold text-gray-400 font-mono">{alert.id} • {new Date(alert.timestamp).toLocaleDateString()}</span>
                          <h4 className="text-base font-display font-bold text-red-950">{alert.type} Alert</h4>
                          <p className="text-xs font-semibold text-gray-800">{alert.studentName} ({alert.rollNo})</p>
                          <p className="text-[11px] text-red-800 leading-relaxed bg-red-50/50 p-3 rounded-lg border border-red-50">{alert.description}</p>
                        </div>

                        <div className="pt-3 border-t border-gray-150 flex justify-between items-center bg-transparent">
                          <span className="text-[10px] font-bold text-red-700 bg-red-50 rounded px-2">{alert.status} Monitor</span>
                          {alert.status === "Open" && (
                            <button
                              onClick={() => handleResolveAlert(alert.id)}
                              className="text-[10px] bg-emerald-600 hover:bg-emerald-700 text-white rounded px-2.5 py-1.5 cursor-pointer font-semibold flex items-center gap-1 shadow-xs transition-all"
                            >
                              <Check className="w-3.5 h-3.5" /> Resolve and Archive Log
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: UNIVERSITY RECORDS DIRECTORY */}
            {activeTab === "records" && (
              <div className="space-y-6 text-left animate-in fade-in duration-200">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <h3 className="font-display font-bold text-base text-gray-950">Official IU Enrollee records directory</h3>
                    <p className="text-xs text-gray-500 mt-1">Sourced directly from Iqra University Registry Services database. This serves as our AI verification audit baseline.</p>
                  </div>
                  <button
                    onClick={() => setIsRegistering(!isRegistering)}
                    className="bg-iqra-green hover:bg-iqra-green-dark text-white rounded-xl py-2 px-4 text-xs font-display font-bold shadow-xs flex items-center gap-1.5 transition-all cursor-pointer self-start sm:self-center"
                  >
                    {isRegistering ? "✕ Close Registration Form" : "＋ Register Student Profile"}
                  </button>
                </div>

                {isRegistering && (
                  <form onSubmit={handleRegisterStudent} className="bg-gray-50 border border-gray-150 rounded-2xl p-6 space-y-4 animate-in slide-in-from-top-4 duration-300">
                    <div className="border-b pb-3">
                      <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider flex items-center gap-1">
                        🔒 Academic Database Enrollee Registration System
                      </h4>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-semibold text-gray-400">Roll Number *</label>
                        <input
                          type="text"
                          required
                          value={regRollNo}
                          onChange={(e) => setRegRollNo(e.target.value)}
                          placeholder="IU-BSCS-2022-045"
                          className="w-full bg-white border border-gray-200 rounded-xl py-2 px-3 text-xs font-mono outline-none focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-semibold text-gray-400">Registration Number *</label>
                        <input
                          type="text"
                          required
                          value={regRegNo}
                          onChange={(e) => setRegRegNo(e.target.value)}
                          placeholder="REG-2022-87391"
                          className="w-full bg-white border border-gray-200 rounded-xl py-2 px-3 text-xs font-mono outline-none focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all"
                        />
                      </div>

                      <div className="space-y-1 md:col-span-2">
                        <label className="block text-[10px] uppercase font-semibold text-gray-400">Student Full Name *</label>
                        <input
                          type="text"
                          required
                          value={regFullName}
                          onChange={(e) => setRegFullName(e.target.value)}
                          placeholder="Kamran Shah"
                          className="w-full bg-white border border-gray-200 rounded-xl py-2 px-3 text-xs outline-none focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-semibold text-gray-400">CNIC Number *</label>
                        <input
                          type="text"
                          required
                          value={regCnic}
                          onChange={(e) => setRegCnic(e.target.value)}
                          placeholder="42101-8392183-1"
                          className="w-full bg-white border border-gray-200 rounded-xl py-2 px-3 text-xs font-mono outline-none focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all"
                        />
                      </div>

                      <div className="space-y-1 md:col-span-2">
                        <label className="block text-[10px] uppercase font-semibold text-gray-400">Program Degree Title</label>
                        <select
                          value={regDegreeTitle}
                          onChange={(e) => {
                            setRegDegreeTitle(e.target.value);
                            if (e.target.value.includes("Computer Science")) {
                              setRegDepartment("Department of Computing & Technology");
                            } else if (e.target.value.includes("Software")) {
                              setRegDepartment("Department of Software Engineering");
                            } else {
                              setRegDepartment("Department of Management Sciences");
                            }
                          }}
                          className="w-full bg-white border border-gray-200 rounded-xl py-2 px-3 text-xs outline-none focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all"
                        >
                          <option value="Bachelor of Science in Computer Science">Bachelor of Science in Computer Science (BSCS)</option>
                          <option value="Bachelor of Science in Software Engineering">Bachelor of Science in Software Engineering (BSSE)</option>
                          <option value="Master of Science in Software Engineering">Master of Science in Software Engineering (MSSE)</option>
                          <option value="Bachelor of Business Administration">Bachelor of Business Administration (BBA)</option>
                          <option value="Doctor of Philosophy in Computer Science">Doctor of Philosophy in Computer Science (PhD)</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-semibold text-gray-400">Department Division</label>
                        <input
                          type="text"
                          value={regDepartment}
                          onChange={(e) => setRegDepartment(e.target.value)}
                          placeholder="Department of Computing"
                          className="w-full bg-white border border-gray-200 rounded-xl py-2 px-3 text-xs outline-none focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-semibold text-gray-400">Official CGPA *</label>
                        <input
                          type="number"
                          step="0.01"
                          min="0.0"
                          max="4.0"
                          required
                          value={regCgpa}
                          onChange={(e) => setRegCgpa(e.target.value)}
                          placeholder="3.42"
                          className="w-full bg-white border border-gray-200 rounded-xl py-2 px-3 text-xs font-mono outline-none focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-semibold text-gray-400">Completed Credit Hours *</label>
                        <input
                          type="number"
                          required
                          value={regCreditHours}
                          onChange={(e) => setRegCreditHours(e.target.value)}
                          placeholder="134"
                          className="w-full bg-white border border-gray-200 rounded-xl py-2 px-3 text-xs font-mono outline-none focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-semibold text-gray-400">Graduation Date *</label>
                        <input
                          type="date"
                          required
                          value={regGraduationDate}
                          onChange={(e) => setRegGraduationDate(e.target.value)}
                          className="w-full bg-white border border-gray-200 rounded-xl py-2 px-3 text-xs font-mono outline-none focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-semibold text-gray-400">Academic Status</label>
                        <select
                          value={regAcademicStatus}
                          onChange={(e) => setRegAcademicStatus(e.target.value as any)}
                          className="w-full bg-white border border-gray-200 rounded-xl py-2 px-3 text-xs outline-none focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all"
                        >
                          <option value="Completed">Completed</option>
                          <option value="Incompleted">Incompleted</option>
                          <option value="Suspended">Suspended</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-semibold text-gray-400">Library Clearance</label>
                        <select
                          value={regLibraryClearance}
                          onChange={(e) => setRegLibraryClearance(e.target.value as any)}
                          className="w-full bg-white border border-gray-200 rounded-xl py-2 px-3 text-xs outline-none focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all"
                        >
                          <option value={ClearanceStatus.Clear}>Clear</option>
                          <option value={ClearanceStatus.Pending}>Pending</option>
                          <option value={ClearanceStatus.Flagged}>Flagged</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-semibold text-gray-400">Finance Clearance</label>
                        <select
                          value={regFinanceClearance}
                          onChange={(e) => setRegFinanceClearance(e.target.value as any)}
                          className="w-full bg-white border border-gray-200 rounded-xl py-2 px-3 text-xs outline-none focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all"
                        >
                          <option value={ClearanceStatus.Clear}>Clear</option>
                          <option value={ClearanceStatus.Pending}>Pending</option>
                          <option value={ClearanceStatus.Flagged}>Flagged</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] uppercase font-semibold text-gray-400">Department Clearance</label>
                        <select
                          value={regDepartmentClearance}
                          onChange={(e) => setRegDepartmentClearance(e.target.value as any)}
                          className="w-full bg-white border border-gray-200 rounded-xl py-2 px-3 text-xs outline-none focus:ring-1 focus:ring-iqra-green text-gray-800 transition-all"
                        >
                          <option value={ClearanceStatus.Clear}>Clear</option>
                          <option value={ClearanceStatus.Pending}>Pending</option>
                          <option value={ClearanceStatus.Flagged}>Flagged</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-3">
                      <button
                        type="button"
                        onClick={() => setIsRegistering(false)}
                        className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={isSubmittingRegistration}
                        className="bg-iqra-gold hover:bg-iqra-gold-dark text-white px-6 py-2 rounded-xl text-xs font-semibold shadow-xs flex items-center gap-1 cursor-pointer transition-all animate-pulse"
                      >
                        {isSubmittingRegistration ? "Saving to registry DB..." : "＋ Register Student Profile"}
                      </button>
                    </div>
                  </form>
                )}

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left border-collapse">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-200 text-gray-500 font-bold uppercase text-[9px]">
                        <th className="p-3">Roll ID</th>
                        <th className="p-3">Full Student Name</th>
                        <th className="p-3">Degree Register</th>
                        <th className="p-3">Official CGPA</th>
                        <th className="p-3">Completed Credits</th>
                        <th className="p-3">Finance Stamp</th>
                        <th className="p-3">Library Stamp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-150 text-[11px]">
                      {allRecords.map((rec) => (
                        <tr key={rec.rollNo} className="hover:bg-gray-50/50">
                          <td className="p-3 font-bold font-mono">{rec.rollNo}</td>
                          <td className="p-3 text-gray-900 font-semibold">{rec.fullName}</td>
                          <td className="p-3">{rec.degreeTitle}</td>
                          <td className="p-3 font-bold font-mono text-gray-800">{rec.cgpa}</td>
                          <td className="p-3 font-mono">{rec.creditHours} Hours</td>
                          <td className="p-3 font-medium">
                            <span className={`px-2 py-0.5 rounded text-[10px] ${rec.financeClearance === ClearanceStatus.Clear ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>{rec.financeClearance}</span>
                          </td>
                          <td className="p-3 font-medium">
                            <span className={`px-2 py-0.5 rounded text-[10px] ${rec.libraryClearance === ClearanceStatus.Clear ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`}>{rec.libraryClearance}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

             {/* TAB 4: AUDIT LOGS */}
             {activeTab === "audit" && (
               <div className="space-y-6 text-left">
                 <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                   <div>
                     <h3 className="font-display font-bold text-base text-gray-950">Cryptographic audit logging</h3>
                     <p className="text-xs text-gray-500 mt-1">Immutable chronology tracking OCR verification steps, AI classifications, and Registrar digital signatures.</p>
                   </div>
                   
                   {/* Audit Success/Discrepancy Filter buttons */}
                   <div className="flex gap-1 bg-gray-100 p-1 rounded-xl border border-gray-150 shrink-0 select-none">
                     <button
                       onClick={() => {
                         setAuditFilter("All");
                         addToast("Showing all system audit logs.", "info");
                       }}
                       className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${auditFilter === "All" ? "bg-iqra-green text-white shadow-xs" : "text-gray-500 hover:bg-white hover:text-gray-900"}`}
                     >
                       All Logs
                     </button>
                     <button
                       onClick={() => {
                         setAuditFilter("Success");
                         addToast("Success audit log filter active.", "success");
                       }}
                       className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${auditFilter === "Success" ? "bg-emerald-600 text-white shadow-xs" : "text-gray-500 hover:bg-white hover:text-gray-900"}`}
                     >
                       Success Only
                     </button>
                     <button
                       onClick={() => {
                         setAuditFilter("Discrepancy");
                         addToast("Discrepancy warning filter active.", "info");
                       }}
                       className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${auditFilter === "Discrepancy" ? "bg-red-650 text-white shadow-xs" : "text-gray-500 hover:bg-white hover:text-gray-900"}`}
                     >
                       Discrepancy Only
                     </button>
                   </div>
                 </div>
 
                 <div className="space-y-3 font-mono text-[10px] leading-relaxed max-w-4xl">
                   {auditLogs
                     .filter((log) => {
                       if (auditFilter === "Success") return log.status === "Success";
                       if (auditFilter === "Discrepancy") return log.status === "Discrepancy" || log.status === "Warning" || log.status?.toUpperCase() !== "SUCCESS";
                       return true;
                     })
                     .map((log) => (
                       <div key={log.id} className="border border-gray-100 rounded-xl p-3.5 hover:bg-gray-50 transition-all flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                         <div className="space-y-1">
                           <div className="flex items-center gap-2">
                             <span className="text-gray-400">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                             <span className={`font-bold px-1.5 rounded py-0.5 uppercase tracking-wider text-[8px] ${
                               log.role === "ARIA" ? "bg-emerald-50 text-emerald-700 border border-emerald-200" :
                               log.role === "Registrar" ? "bg-amber-50 text-amber-800" : "bg-gray-100 text-gray-700"
                             }`}>{log.role}</span>
                             <span className="font-bold text-gray-900">{log.action}</span>
                           </div>
                           <p className="text-gray-600 font-sans text-[11px] leading-normal">{log.details}</p>
                         </div>
 
                         <div className="text-right shrink-0">
                           <span className={`inline-block font-bold rounded-lg py-0.5 px-2 mt-1 md:mt-0 ${
                             log.status === "Success" ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-600"
                           }`}>
                             {log.status === "Success" ? "SUCCESS" : "DISCREPANCY"}
                           </span>
                         </div>
                       </div>
                   ))}
                   {auditLogs.filter((log) => {
                       if (auditFilter === "Success") return log.status === "Success";
                       if (auditFilter === "Discrepancy") return log.status === "Discrepancy" || log.status === "Warning" || log.status?.toUpperCase() !== "SUCCESS";
                       return true;
                     }).length === 0 && (
                     <div className="p-8 text-center text-gray-450 text-xs font-sans border border-dashed rounded-2xl bg-gray-50/50">
                       No audit logs match this status filter.
                     </div>
                   )}
                 </div>
               </div>
             )}

            {/* TAB 5: CONFIG RULES */}
            {activeTab === "config" && (
              <div className="space-y-6 text-left max-w-xl">
                <div>
                  <h3 className="font-display font-bold text-base text-gray-950">HEC Compliance Configuration Parameters</h3>
                  <p className="text-xs text-gray-500 mt-1">Control constraints used during the Step 4 Eligibility Engine prechecks</p>
                </div>

                <div className="space-y-4 border border-gray-100 rounded-2xl p-6 bg-gray-50/50">
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-gray-750 uppercase">Minimum Required CGPA Threshold</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="range"
                        min="2.00"
                        max="3.00"
                        step="0.05"
                        value={configMinCgpa}
                        onChange={(e) => setConfigMinCgpa(parseFloat(e.target.value))}
                        className="flex-1 accent-iqra-green cursor-pointer"
                      />
                      <span className="font-mono font-extrabold text-gray-900 bg-white border rounded px-3 py-1.5 shrink-0 select-none text-xs">{configMinCgpa.toFixed(2)} Target</span>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-gray-150 leading-relaxed text-[11px] text-gray-500">
                    <p className="font-bold text-gray-800">HEC Policy Directives Summary:</p>
                    <p className="mt-1">By default, HEC Pakistan mandates that any degree attestation workflow executed by partner universities requires a minimum score of **2.50 CGPA** on a 4.00 standard scale. If CGPA value drops under threshold, eligibility checks can flag exception warnings.</p>
                  </div>
                </div>
              </div>
            )}

          </div>

          {/* SIDE-BY-SIDE INTEGRATION OCR AUDITING VIEW MODAL */}
          {selectedApp && (
            <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 overflow-y-auto backdrop-blur-xs animate-in fade-in duration-200">
              <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full overflow-hidden relative flex flex-col max-h-[92vh]">
                
                {/* Header */}
                <div className="bg-iqra-green text-white px-6 py-4 flex items-center justify-between relative shrink-0">
                  <div className="absolute top-0 right-0 left-0 h-1 bg-iqra-gold" />
                  <div>
                    <h3 className="font-display font-bold text-base">Registrar Forensic Audit & Application Review</h3>
                    <p className="text-[10px] text-iqra-green-light font-mono mt-0.5">Reference ID: {selectedApp.id} | Registrant: {selectedApp.academicRecord?.fullName}</p>
                  </div>
                  <button 
                    onClick={() => setSelectedApp(null)}
                    className="p-1 hover:bg-white/10 rounded-lg text-white/80 hover:text-white cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Main comparison grid */}
                <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6">
                  
                  {/* Alert if mismatch layers were detected */}
                  {selectedApp.transcriptUpload?.fraudAlerts?.isFlagged && (
                    <div className="bg-red-50 border border-red-150 rounded-2xl p-4 text-xs font-semibold text-red-900 flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <p className="font-bold">CRITICAL FRAUD AND PHOTOSHOP ALERTS LOGGED ON RECORD</p>
                        <p className="text-red-700 font-normal leading-relaxed mt-1">
                          Our advanced ARIA forensics model identified a **95% Photoshop CC Manipulation Risk**. Discrepancies exist between the CGPA parameters extracted on original transcript document and official university databases.
                        </p>
                        <div className="mt-3.5 flex flex-wrap gap-2.5">
                          <button
                            type="button"
                            onClick={() => {
                              setActiveTab("fraud");
                              setSelectedApp(null);
                              addToast("Switched to the forensic fraud monitors interface.", "info");
                            }}
                            className="bg-red-100 hover:bg-red-200 text-red-800 text-[10px] font-bold px-3.5 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer transition-all border border-red-200"
                          >
                            <AlertTriangle className="w-3.5 h-3.5" /> Open Forensic Fraud Monitor
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              addToast("Resolving forensic warnings directly on this file...", "info");
                              // Find corresponding open alert in the list or try to match by rollNo / applicationId
                              const matchingAlert = fraudAlertsList.find(f => f.rollNo === selectedApp.rollNo && f.status === "Open");
                              const alertId = matchingAlert ? matchingAlert.id : "FRD-901";
                              await handleResolveAlert(alertId);
                            }}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold px-3.5 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer transition-all shadow-sm"
                          >
                            <Check className="w-3.5 h-3.5" /> Force Resolve and Approve Bypass
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch text-left">
                    
                    {/* Left: Extract OCR documents metrics */}
                    <div className="border border-gray-150 rounded-2xl p-5 space-y-4 flex flex-col justify-between">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Extract Document parameters (OCR)</span>
                      
                      <div className="space-y-3 bg-gray-50 p-4 rounded-xl border">
                        <div className="text-xs space-y-2 font-mono">
                          <p className="flex justify-between border-b pb-1.5"><span className="text-gray-500 font-semibold">Decoded FullName:</span> <span className="font-bold text-gray-900">{selectedApp.transcriptUpload?.ocrExtracted?.name || selectedApp.academicRecord?.fullName}</span></p>
                          <p className="flex justify-between border-b pb-1.5"><span className="text-gray-500 font-semibold">Extracted CGPA:</span> <span className={`font-bold ${selectedApp.transcriptUpload?.ocrExtracted?.cgpa !== selectedApp.academicRecord?.cgpa ? "text-red-650" : "text-gray-900"}`}>{selectedApp.transcriptUpload?.ocrExtracted?.cgpa || selectedApp.academicRecord?.cgpa}</span></p>
                          <p className="flex justify-between border-b pb-1.5"><span className="text-gray-500 font-semibold">Completed Credits:</span> <span>{selectedApp.transcriptUpload?.ocrExtracted?.credits || selectedApp.academicRecord?.creditHours} Hours</span></p>
                          <p className="flex justify-between"><span className="text-gray-500 font-semibold">Forensic Fraud Score:</span> <span className="font-bold text-red-700">{selectedApp.transcriptUpload?.fraudAlerts?.score || 4}% Verification Risk</span></p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Identified Files Audit Checklist</p>
                        <ul className="text-[11px] text-gray-600 list-disc list-inside space-y-1">
                          <li>CNIC File: <span className="text-emerald-700 font-bold">{selectedApp.cnicUpload?.status}</span></li>
                          <li>Degree Scroll File: <span className="text-emerald-700 font-bold">{selectedApp.degreeUpload?.fileName ? "In-order" : "Not Provided"}</span></li>
                        </ul>
                      </div>
                    </div>

                    {/* Right: baseline records official IU registrar schema */}
                    <div className="border border-gray-150 rounded-2xl p-5 space-y-4 flex flex-col justify-between bg-iqra-green-light/20">
                      <span className="text-[10px] font-bold text-iqra-green uppercase tracking-widest block font-sans">Official baseline records (Registrar DB)</span>
                      
                      <div className="space-y-3 bg-white p-4 rounded-xl border border-iqra-green/10">
                        <div className="text-xs space-y-2 font-mono">
                          <p className="flex justify-between border-b pb-1.5"><span className="text-gray-500 font-semibold">Official FullName:</span> <span className="font-bold text-gray-900">{selectedApp.academicRecord?.fullName}</span></p>
                          <p className="flex justify-between border-b pb-1.5"><span className="text-gray-500 font-semibold">Official CGPA:</span> <span className="font-bold text-gray-950">{selectedApp.academicRecord?.cgpa}</span></p>
                          <p className="flex justify-between border-b pb-1.5"><span className="text-gray-500 font-semibold">Official Credits:</span> <span>{selectedApp.academicRecord?.creditHours} Hours</span></p>
                          <p className="flex justify-between"><span className="text-gray-500 font-semibold">Academic Status:</span> <span className="font-bold text-emerald-700 bg-emerald-50 rounded px-1.5 text-[10px]">{selectedApp.academicRecord?.academicStatus}</span></p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Institutional clear status</p>
                        <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-bold font-mono">
                          <div className={`p-2 rounded border ${selectedApp.academicRecord?.libraryClearance === "Clear" ? "bg-emerald-50 text-emerald-800 border-emerald-100" : "bg-red-50 text-red-850"}`}>Library</div>
                          <div className={`p-2 rounded border ${selectedApp.academicRecord?.financeClearance === "Clear" ? "bg-emerald-50 text-emerald-800 border-emerald-100" : "bg-red-50 text-red-850"}`}>Finance</div>
                          <div className={`p-2 rounded border ${selectedApp.academicRecord?.departmentClearance === "Clear" ? "bg-emerald-50 text-emerald-800 border-emerald-100" : "bg-red-50 text-red-850"}`}>Dept</div>
                        </div>
                      </div>
                    </div>

                  </div>

                  {/* Administrative Resolution decisions fields */}
                  <div className="space-y-4 border-t pt-5">
                    <label className="block text-xs font-bold text-gray-750 uppercase text-left">Administrative review feedback notes</label>
                    <textarea
                      value={reviewComments}
                      onChange={(e) => setReviewComments(e.target.value)}
                      placeholder="Input attestation review analysis. If rejecting, provide details explaining CNIC/CGPA conflicts."
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl p-4 text-xs font-sans outline-none focus:bg-white focus:border-iqra-green text-gray-800 transition-all shadow-inner h-24"
                    />
                  </div>

                </div>

                {/* Footer buttons */}
                <div className="bg-gray-50 px-6 py-4 border-t border-gray-150 flex justify-end gap-3 shrink-0">
                  <button
                    onClick={() => handleAppReviewSubmit("Rejected")}
                    disabled={isSubmittingReview}
                    className="bg-red-600 hover:bg-red-700 text-white rounded-xl py-2 px-6 text-xs font-display font-semibold transition-all cursor-pointer shadow disabled:opacity-40"
                  >
                    Decline and Flag Fraud
                  </button>
                  <button
                    onClick={() => handleAppReviewSubmit("Approved")}
                    disabled={isSubmittingReview || selectedApp.academicRecord?.libraryClearance !== "Clear" || selectedApp.academicRecord?.financeClearance !== "Clear" || selectedApp.transcriptUpload?.fraudAlerts?.isFlagged}
                    className="bg-iqra-green hover:bg-iqra-green-dark text-white rounded-xl py-2 px-6 text-xs font-display font-semibold transition-all cursor-pointer shadow disabled:opacity-40"
                    title={selectedApp.transcriptUpload?.fraudAlerts?.isFlagged ? "Approval blocked: Forensic fraud triggers must be resolved first" : ""}
                  >
                    Approve, Seal & Attest
                  </button>
                </div>

              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
}
