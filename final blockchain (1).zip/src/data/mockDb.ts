/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { IqraDbRecord, Application, ApplicationStatus, DegreeType, ClearanceStatus, FraudAlert, AuditLog } from "../types";

export const MOCK_UNIVERSITY_DATABASE: IqraDbRecord[] = [
  {
    rollNo: "IU-BSCS-2022-045",
    regNo: "REG-2022-87391",
    fullName: "Kamran Shah",
    cnic: "42101-8392183-1",
    degreeTitle: "Bachelor of Science in Computer Science",
    department: "Department of Computing & Technology",
    cgpa: 3.42,
    creditHours: 134,
    graduationDate: "2026-02-15",
    academicStatus: "Completed",
    libraryClearance: ClearanceStatus.Clear,
    financeClearance: ClearanceStatus.Clear,
    departmentClearance: ClearanceStatus.Clear
  },
  {
    rollNo: "IU-BBA-2021-120",
    regNo: "REG-2021-55122",
    fullName: "Ayesha Ahmed",
    cnic: "35201-9283712-2",
    degreeTitle: "Bachelor of Business Administration",
    department: "Department of Management Sciences",
    cgpa: 2.85,
    creditHours: 136,
    graduationDate: "2025-10-30",
    academicStatus: "Completed",
    libraryClearance: ClearanceStatus.Clear,
    financeClearance: ClearanceStatus.Clear,
    departmentClearance: ClearanceStatus.Clear
  },
  {
    rollNo: "IU-MSSE-2023-012",
    regNo: "REG-2023-93812",
    fullName: "Bilal Raza",
    cnic: "42201-1938217-1",
    degreeTitle: "Master of Science in Software Engineering",
    department: "Department of Software Engineering",
    cgpa: 3.10,
    creditHours: 33,
    graduationDate: "2025-12-20",
    academicStatus: "Completed",
    libraryClearance: ClearanceStatus.Clear,
    financeClearance: ClearanceStatus.Clear,
    departmentClearance: ClearanceStatus.Clear
  },
  {
    rollNo: "IU-BSSE-2022-094",
    regNo: "REG-2022-10821",
    fullName: "Zainab Malik",
    cnic: "37405-8391823-2",
    degreeTitle: "Bachelor of Science in Software Engineering",
    department: "Department of Software Engineering",
    cgpa: 2.31, // Under 2.50 limit
    creditHours: 110, // Under 130 credit hours
    graduationDate: "2025-11-10",
    academicStatus: "Incompleted",
    libraryClearance: ClearanceStatus.Pending,
    financeClearance: ClearanceStatus.Flagged, // Flagged clearance
    departmentClearance: ClearanceStatus.Clear
  },
  {
    rollNo: "IU-PHD-2021-003",
    regNo: "REG-2021-00213",
    fullName: "Dr. Muhammad Faisal",
    cnic: "42101-7392183-5",
    degreeTitle: "Doctor of Philosophy in Computer Science",
    department: "Department of Computing & Technology",
    cgpa: 3.89,
    creditHours: 24,
    graduationDate: "2025-08-05",
    academicStatus: "Completed",
    libraryClearance: ClearanceStatus.Clear,
    financeClearance: ClearanceStatus.Clear,
    departmentClearance: ClearanceStatus.Clear
  }
];

export const INITIAL_APPLICATIONS: Application[] = [
  {
    id: "APP-401928",
    studentId: "student1",
    rollNo: "IU-BSCS-2022-045",
    regNo: "REG-2022-87391",
    degreeType: DegreeType.BS,
    academicRecord: MOCK_UNIVERSITY_DATABASE[0],
    status: ApplicationStatus.Approved,
    step: 4,
    cnicUpload: {
      id: "doc1",
      title: "CNIC Certificate",
      fileName: "cnic_front_kamran.jpg",
      fileSize: "1.2 MB",
      status: "Processed",
      ocrExtracted: { name: "Kamran Shah", cnicNo: "42101-8392183-1", expiryDate: "2028-12-11" },
      crossVerifyResult: { isMatch: true, issues: [] }
    },
    transcriptUpload: {
      id: "doc2",
      title: "Official BSCS Transcript",
      fileName: "bscs_transcript.pdf",
      fileSize: "4.5 MB",
      status: "Processed",
      ocrExtracted: { name: "Kamran Shah", cgpa: 3.42, credits: 134, completionDate: "2026-02-15" },
      crossVerifyResult: { isMatch: true, issues: [] }
    },
    degreeUpload: {
      id: "doc3",
      title: "Degree Certificate",
      fileName: "bscs_degree_kamran.jpg",
      fileSize: "3.1 MB",
      status: "Processed",
      ocrExtracted: { name: "Kamran Shah", degreeTitle: "Bachelor of Science in Computer Science", serialNo: "IU-DG-2026-9021" },
      crossVerifyResult: { isMatch: true, issues: [] }
    },
    paymentVerified: true,
    paymentMethod: "HBL Bank Transfer",
    paymentTxRef: "TXN9832718919",
    paymentAmount: 5000,
    verificationHash: "8f7bc2246a48d89e9f3b89e3a39b2cf47fd39af183d29a513bf89df201de38e2",
    submittedAt: "2026-06-01T09:30:00Z",
    reviewedAt: "2026-06-03T14:15:00Z",
    comments: "Academic qualifications are thoroughly verified by IU Registrar team and matching official records."
  },
  {
    id: "APP-551029",
    studentId: "student2",
    rollNo: "IU-BBA-2021-120",
    regNo: "REG-2021-55122",
    degreeType: DegreeType.BS,
    academicRecord: MOCK_UNIVERSITY_DATABASE[1],
    status: ApplicationStatus.UnderReview,
    step: 4,
    cnicUpload: {
      id: "doc4",
      title: "CNIC Certificate",
      fileName: "ayesha_cnic.png",
      fileSize: "920 KB",
      status: "Processed",
      ocrExtracted: { name: "Ayesha Ahmed", cnicNo: "35201-9283712-2", expiryDate: "2031-08-14" },
      crossVerifyResult: { isMatch: true, issues: [] }
    },
    transcriptUpload: {
      id: "doc5",
      title: "BBA Transcript",
      fileName: "bba_transcript.pdf",
      fileSize: "3.8 MB",
      status: "Processed",
      ocrExtracted: { name: "Ayesha Ahmed", cgpa: 2.85, credits: 136 },
      crossVerifyResult: { isMatch: true, issues: [] }
    },
    paymentVerified: true,
    paymentMethod: "Easypaisa Mobile Wallet",
    paymentTxRef: "EP1092831821",
    paymentAmount: 5000,
    submittedAt: "2026-06-05T12:10:00Z"
  },
  {
    id: "APP-110293",
    studentId: "student3",
    rollNo: "IU-BSSE-2022-094",
    regNo: "REG-2022-10821",
    degreeType: DegreeType.BS,
    academicRecord: MOCK_UNIVERSITY_DATABASE[3],
    status: ApplicationStatus.Rejected,
    step: 4,
    cnicUpload: {
      id: "doc6",
      title: "CNIC Certificate",
      fileName: "tampered_cnic.jpg",
      fileSize: "1.5 MB",
      status: "Error",
      ocrExtracted: { name: "Zainab Malik", cnicNo: "37405-8391823-2", expiryDate: "2024-03-10" }, // EXPIRED
      crossVerifyResult: { isMatch: false, issues: ["Identity CNIC card is expired."] }
    },
    transcriptUpload: {
      id: "doc7",
      title: "Tampered Transcript",
      fileName: "tampered_transcript_3.9.pdf",
      fileSize: "4.2 MB",
      status: "Error",
      ocrExtracted: { name: "Zainab Malik", cgpa: 3.90, credits: 134 }, // Tampered CGPA (Database says 2.31 CGPA, 110 credits!)
      crossVerifyResult: { isMatch: false, issues: ["CGPA Mismatch: OCR detected 3.90 but Database holds 2.31", "Credit Hours Mismatch: OCR detected 134/130 but Database holds 110/130."] },
      fraudAlerts: {
        isFlagged: true,
        score: 95,
        indicators: ["Photoshop digital layer detected on GPA font style", "Calculated semester weighted average does not equal metadata CGPA"]
      }
    },
    paymentVerified: false,
    paymentAmount: 5000,
    submittedAt: "2026-06-04T08:00:00Z",
    reviewedAt: "2026-06-05T10:00:00Z",
    comments: "Major academic discrepancies detected. CGPA and credit hours have been heavily edited on the transcript document. Clearances are pending and flagged with finance department. Expired CNIC submitted."
  }
];

export const INITIAL_FRAUD_ALERTS: FraudAlert[] = [
  {
    id: "FRD-901",
    applicationId: "APP-110293",
    studentName: "Zainab Malik",
    rollNo: "IU-BSSE-2022-094",
    type: "CGPA Alteration",
    severity: "High",
    description: "OCR extracted transcript CGPA (3.90) conflicts with Iqra official registrar database records (2.31). Deep forensics detect font modification layers.",
    timestamp: "2026-06-04T08:02:11Z",
    status: "Open"
  },
  {
    id: "FRD-902",
    applicationId: "APP-110293",
    studentName: "Zainab Malik",
    rollNo: "IU-BSSE-2022-094",
    type: "Photoshop Manipulation",
    severity: "High",
    description: "Analysis of 'tampered_transcript_3.9.pdf' reveals inconsistent EXIF metadata indicating Adobe Photoshop CC editing on 2026-06-03.",
    timestamp: "2026-06-04T08:05:44Z",
    status: "Open"
  }
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: "LOG-1001",
    actor: "Kamran Shah",
    role: "Student",
    action: "Attestation Submission",
    details: "Student applied for BSCS Degree attestation and initiated document verification pipeline.",
    timestamp: "2026-06-01T09:30:00Z",
    status: "Success"
  },
  {
    id: "LOG-1002",
    actor: "ARIA",
    role: "ARIA",
    action: "Automatic Document OCR Scan",
    details: "ARIA compiled OCR results from cnic_front_kamran.jpg. Extracted Name matching 'Kamran Shah'. No fraud alerts found.",
    timestamp: "2026-06-01T09:31:05Z",
    status: "Success"
  },
  {
    id: "LOG-1003",
    actor: "ARIA",
    role: "ARIA",
    action: "Database Consistency Verification",
    details: "Checked BSCS Degree records against roll no 'IU-BSCS-2022-045'. Perfect correlation.",
    timestamp: "2026-06-01T09:31:12Z",
    status: "Success"
  },
  {
    id: "LOG-1004",
    actor: "Registrar Officer",
    role: "Registrar",
    action: "Application Approval & Signing",
    details: "Approved application APP-401928, generated verification hash 8f7bc224... and locked digital signature.",
    timestamp: "2026-06-03T14:15:00Z",
    status: "Success"
  },
  {
    id: "LOG-1005",
    actor: "Zainab Malik",
    role: "Student",
    action: "Workflow Submission",
    details: "User submitted application APP-110293 for software engineering attestation.",
    timestamp: "2026-06-04T08:00:00Z",
    status: "Success"
  },
  {
    id: "LOG-1006",
    actor: "ARIA",
    role: "ARIA",
    action: "Security Forensics & OCR Flagging",
    details: "FLAGGED high discrepancy: Student submitted transcript CGPA (3.90) mismatched with database (2.31). Alert FRD-901 generated.",
    timestamp: "2026-06-04T08:02:15Z",
    status: "Failed"
  }
];
