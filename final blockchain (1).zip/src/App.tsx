/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  ShieldCheck, Award, User, Lock, Search, GraduationCap, 
  HelpCircle, Sparkles, Server, Zap, QrCode, FileCheck, CheckCircle2, X, AlertTriangle, Info, Bot
} from "lucide-react";
import { Application } from "./types";
import StudentPortal from "./components/StudentPortal";
import VerificationPortal from "./components/VerificationPortal";
import AdminPortal from "./components/AdminPortal";
import AriaAgent from "./components/AriaAgent";

interface Toast {
  id: string;
  message: string;
  type: "success" | "error" | "info";
}

export default function App() {
  const [currentView, setCurrentView] = useState<"home" | "student" | "verify" | "admin">("home");
  const [applications, setApplications] = useState<Application[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Toast manager
  const addToast = (message: string, type: "success" | "error" | "info") => {
    const id = `toast-${Date.now()}`;
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Synchronize applications with in-memory Express DB
  const loadApplications = async () => {
    try {
      const res = await fetch("/api/applications");
      const data = await res.json();
      if (res.ok) {
        setApplications(data);
      }
    } catch (e) {
      console.error("Failed to connect applications registry:", e);
    }
  };

  useEffect(() => {
    loadApplications();
    
    // Look at initial route hash for public lookup redirects
    const handleUrlHash = () => {
      const hash = window.location.hash;
      if (hash && hash.startsWith("#verify-")) {
        setCurrentView("verify");
      }
    };
    handleUrlHash();
    window.addEventListener("hashchange", handleUrlHash);
    return () => window.removeEventListener("hashchange", handleUrlHash);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-between selection:bg-iqra-green/10 selection:text-iqra-green">
      
      {/* GLOBAL TOAST NOTIFICATIONS */}
      <div className="fixed top-5 right-5 z-55 max-w-sm w-full space-y-2.5">
        {toasts.map(t => (
          <div 
            key={t.id} 
            className={`p-4 rounded-xl shadow-lg border text-xs flex items-start justify-between gap-3 animate-in slide-in-from-top-4 duration-300 ${
              t.type === "success" ? "bg-emerald-50 border-emerald-100 text-emerald-800" :
              t.type === "error" ? "bg-red-50 border-red-100 text-red-800" :
              "bg-blue-50 border-blue-100 text-blue-800"
            }`}
          >
            <div className="flex gap-2">
              {t.type === "success" && <CheckCircle2 className="w-4.5 h-4.5 text-emerald-600 shrink-0 mt-0.5" />}
              {t.type === "error" && <AlertTriangle className="w-4.5 h-4.5 text-red-600 shrink-0 mt-0.5" />}
              {t.type === "info" && <Info className="w-4.5 h-4.5 text-blue-600 shrink-0 mt-0.5" />}
              <span className="font-sans leading-normal font-medium">{t.message}</span>
            </div>
            <button 
              onClick={() => removeToast(t.id)}
              className="text-gray-400 hover:text-gray-600 cursor-pointer shrink-0 ml-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      {/* INSTITUTION SYSTEM WRAPPER VIEWPORT */}
      <div className="flex-1 flex flex-col">
        
        {/* TOP LEVEL NAVIGATION BRAND BAR */}
        <header className="bg-white border-b border-gray-150 py-3.5 sticky top-0 z-40 shadow-xs">
          <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
            
            {/* Logo Crest */}
            <div 
              onClick={() => setCurrentView("home")}
              className="flex items-center gap-3 cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-xl bg-iqra-green flex items-center justify-center text-white border border-iqra-green-light shrink-0 relative overflow-hidden shadow-sm">
                <GraduationCap className="w-6 h-6 text-iqra-gold group-hover:scale-110 transition-all" />
              </div>
              <div className="text-left leading-none">
                <span className="text-sm font-display font-black tracking-tight text-gray-900 block">IQRA UNIVERSITY</span>
                <span className="text-[10px] font-mono tracking-widest text-iqra-gold uppercase font-extrabold mt-0.5 block">VERIFY PORTAL</span>
              </div>
            </div>

            {/* Nav choices */}
            <nav className="hidden md:flex items-center gap-1.5 text-xs font-semibold text-gray-600">
              {[
                { id: "verify", label: "Verification Portal", desc: "For Employers & Embassies" },
                { id: "student", label: "Student Desk", desc: "Uploads & Attestation" },
                { id: "admin", label: "Registrar Console", desc: "Official Audit Log" }
              ].map(n => (
                <button
                  key={n.id}
                  onClick={() => setCurrentView(n.id as any)}
                  className={`px-4 py-2 rounded-xl transition-all cursor-pointer text-left ${
                    currentView === n.id 
                      ? "bg-iqra-green-light text-iqra-green font-bold border border-iqra-green/10" 
                      : "hover:bg-gray-50"
                  }`}
                >
                  <p className="leading-tight">{n.label}</p>
                  <p className="text-[9px] text-gray-400 font-normal leading-tight mt-0.5">{n.desc}</p>
                </button>
              ))}
            </nav>

            {/* CTA Help button */}
            <div className="flex items-center gap-2">
              <a 
                href="#aria-direct"
                onClick={() => addToast("Floating ARIA helper widget active at bottom right corner.", "info")}
                className="text-xs bg-gray-50 border hover:bg-gray-100 text-gray-700 py-2 px-3.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 font-bold"
              >
                ARIA Help
              </a>
            </div>

          </div>
        </header>

        {/* CONTAINER VIEW SEGMENT ROUTING */}
        <main className="flex-1 flex flex-col justify-between">
          
          {currentView === "home" && (
            /* --- MAJESTIC LANDING PAGE --- */
            <div className="space-y-16 py-12 max-w-7xl mx-auto px-4">
              
              {/* HERO BOARD BRAND SECTION */}
              <section className="bg-white rounded-3xl border border-gray-100 shadow-xl overflow-hidden grid grid-cols-1 md:grid-cols-2 relative">
                <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-iqra-green via-iqra-gold to-iqra-green-dark" />
                
                {/* Brand description left */}
                <div className="p-8 md:p-14 flex flex-col justify-center space-y-6 text-left relative z-10">
                  <div className="inline-flex items-center gap-1.5 bg-iqra-green-light text-iqra-green border border-iqra-green/10 font-mono text-[9px] tracking-widest uppercase font-bold py-1 px-3 rounded-full">
                    <Sparkles className="w-3.5 h-3.5 text-iqra-gold animate-spin" /> High Integrity attestation
                  </div>
                  
                  <h1 className="text-4xl md:text-5xl font-display font-black text-gray-900 tracking-tight leading-none">
                    Security Authenticated <br />
                    <span className="text-iqra-green">Degree Registry</span>
                  </h1>
                  
                  <p className="text-xs text-gray-500 leading-relaxed">
                    Verify transcripts authenticity and complete HEC-compliant degree attestations. Our Autonomous registrar AI ARIA performs side-by-side OCR validations & Photoshop forensics, instantly mapping seals and serial numbers to official University databases.
                  </p>

                  <div className="flex flex-col sm:flex-row gap-3 pt-4">
                    <button
                      onClick={() => setCurrentView("verify")}
                      className="bg-iqra-green hover:bg-iqra-green-dark text-white rounded-xl py-3 px-6 text-xs font-display font-medium shadow-md transition-all cursor-pointer text-center flex items-center justify-center gap-2"
                    >
                      Verify Document Status <Search className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setCurrentView("student")}
                      className="bg-white border border-gray-200 hover:bg-gray-50 text-gray-800 rounded-xl py-3 px-6 text-xs font-display font-medium shadow-xs transition-all cursor-pointer text-center flex items-center justify-center gap-2"
                    >
                      Student Portal Access <User className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Simulated Visual Certificate display lock right */}
                <div className="bg-gray-50/50 p-8 flex items-center justify-center border-t md:border-t-0 md:border-l border-gray-150 relative overflow-hidden select-none">
                  <div className="absolute right-0 bottom-0 text-gray-100 font-extrabold text-[15rem] leading-none select-none font-display">
                    IQRA
                  </div>
                  
                  {/* Digital seal widget */}
                  <div className="bg-white border rounded-2xl shadow-lg p-5 max-w-sm w-full space-y-4 relative w-80">
                    <div className="flex justify-between items-start">
                      <div className="space-y-0.5">
                        <span className="text-[9px] text-gray-400 font-bold uppercase block">Iqra Verify System</span>
                        <span className="text-xs font-mono font-bold text-gray-900">IU-DG-2026-9021</span>
                      </div>
                      <div className="p-1 px-1.5 bg-emerald-50 text-emerald-700 rounded-lg text-[9px] font-bold font-mono uppercase border border-emerald-100 flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5" /> Approved
                      </div>
                    </div>

                    <div className="border-y border-gray-100 py-3 space-y-1">
                      <span className="text-[10px] text-gray-400 block">Student Degree Holder</span>
                      <span className="text-sm font-display font-bold text-gray-950 block">Kamran Shah</span>
                      <span className="text-[10px] text-gray-600 block font-medium">B.S. Computer Science</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-50 border rounded flex items-center justify-center shrink-0">
                        <QrCode className="w-8 h-8 text-gray-700" />
                      </div>
                      <div className="text-[9px] text-gray-500 font-mono leading-tight">
                        <p className="font-bold text-gray-900">SHA-256 Stamp Seal</p>
                        <p className="truncate w-44 mt-0.5">8f7bc2246a48d89e9f3b89e3a39b...</p>
                      </div>
                    </div>
                  </div>
                </div>

              </section>

              {/* FEATURES BENTO GRID SERVICE SCHEME */}
              <section className="space-y-8 text-left">
                <div>
                  <h2 className="text-xl font-display font-bold text-gray-900 tracking-tight">Enterprise Compliance Framework</h2>
                  <p className="text-xs text-gray-500 mt-1">Engineered to satisty HEC Pakistan regulations, NADRA identity mapping, and PECA standards securely.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  
                  {/* Feature 1 */}
                  <div className="bg-white border border-gray-100 rounded-2xl p-6 space-y-4 hover:shadow-md transition-all">
                    <div className="w-10 h-10 rounded-xl bg-iqra-green-light text-iqra-green flex items-center justify-center border border-iqra-green/10 shrink-0">
                      <Bot className="w-5 h-5 text-iqra-gold animate-pulse" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-display font-bold text-sm text-gray-900">ARIA AI Registrar Engine</h3>
                      <p className="text-xs text-gray-500 leading-relaxed font-light">
                        Our integrated neural assistant instantly processes student uploaded documents, maps GPA entries and coursework records, checking library and financial parameters.
                      </p>
                    </div>
                  </div>

                  {/* Feature 2 */}
                  <div className="bg-white border border-gray-100 rounded-2xl p-6 space-y-4 hover:shadow-md transition-all">
                    <div className="w-10 h-10 rounded-xl bg-iqra-green-light text-iqra-green flex items-center justify-center border border-iqra-green/10 shrink-0">
                      <Zap className="w-5 h-5 text-iqra-gold" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-display font-bold text-sm text-gray-900">Digital Layer Forensics</h3>
                      <p className="text-xs text-gray-500 leading-relaxed font-light">
                        Automated inspection scans file EXIF metadata layers, exposing Photoshop manipulations, altered grades text, expired identification dates, or mismatched serial numbers.
                      </p>
                    </div>
                  </div>

                  {/* Feature 3 */}
                  <div className="bg-white border border-gray-100 rounded-2xl p-6 space-y-4 hover:shadow-md transition-all">
                    <div className="w-10 h-10 rounded-xl bg-iqra-green-light text-iqra-green flex items-center justify-center border border-iqra-green/10 shrink-0">
                      <QrCode className="w-5 h-5 text-iqra-gold" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-display font-bold text-sm text-gray-900">SHA-256 Sealed QR Codes</h3>
                      <p className="text-xs text-gray-500 leading-relaxed font-light">
                        Approved degrees are compiled with unique cryptographic hashes and golden stamps. Scanning the QR code launches a verification card verifying authenticity instantly.
                      </p>
                    </div>
                  </div>

                </div>
              </section>

              {/* QUICK STATISTICS CAROUSEL */}
              <section className="bg-gray-50 border border-gray-150 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row justify-around items-center text-center gap-6">
                <div className="space-y-1">
                  <span className="text-2xl md:text-3xl font-display font-extrabold text-iqra-green block">99.8%</span>
                  <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block">Automatic OCR Match Score</span>
                </div>
                <div className="hidden md:block h-10 w-px bg-gray-200" />
                <div className="space-y-1">
                  <span className="text-2xl md:text-3xl font-display font-extrabold text-iqra-green block">1.5 Seconds</span>
                  <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block">Cryptographic Hash Dispatch</span>
                </div>
                <div className="hidden md:block h-10 w-px bg-gray-200" />
                <div className="space-y-1">
                  <span className="text-2xl md:text-3xl font-display font-extrabold text-iqra-green block">HEC / HBL</span>
                  <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block">Seamless Surcharge Routing</span>
                </div>
              </section>

            </div>
          )}

          {currentView === "student" && (
            <StudentPortal 
              onBackToHome={() => setCurrentView("home")} 
              applications={applications}
              onRefreshApplications={loadApplications}
              addToast={addToast}
            />
          )}

          {currentView === "verify" && (
            <VerificationPortal 
              onBackToHome={() => setCurrentView("home")} 
              addToast={addToast}
            />
          )}

          {currentView === "admin" && (
            <AdminPortal 
              onBackToHome={() => setCurrentView("home")} 
              applications={applications}
              onRefreshApplications={loadApplications}
              addToast={addToast}
            />
          )}

        </main>
      </div>

      {/* FLOAT CHAT HELPER WIDGET */}
      <AriaAgent compactMode={false} />

      {/* DECENT INSTITUTION FOOTER */}
      <footer className="bg-white border-t border-gray-150 py-5 text-center text-[10px] text-gray-400 font-sans tracking-wide shrink-0">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-3">
          <p>© 2026 Iqra University Registrar Services Division. All Rights Reserved. Complied with HEC Pakistan Guidelines & PECA 2016.</p>
          <div className="flex gap-4">
            <a href="#verify" onClick={() => setCurrentView("verify")} className="hover:underline hover:text-gray-600 cursor-pointer">Verify Portal</a>
            <a href="#student" onClick={() => setCurrentView("student")} className="hover:underline hover:text-gray-600 cursor-pointer">Student Desk</a>
            <a href="#admin" onClick={() => setCurrentView("admin")} className="hover:underline hover:text-gray-600 cursor-pointer">Registrar Login</a>
          </div>
        </div>
      </footer>

    </div>
  );
}
