/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum DegreeType {
  BS = "BS",
  MS = "MS",
  MPhil = "MPhil",
  PhD = "PhD"
}

export enum ApplicationStatus {
  Draft = "Draft",
  Submitted = "Submitted",
  UnderReview = "Under Review",
  Approved = "Approved",
  Rejected = "Rejected"
}

export enum ClearanceStatus {
  Clear = "Clear",
  Pending = "Pending",
  Flagged = "Flagged"
}

export interface StudentProfile {
  id: string;
  email: string;
  fullName: string;
  cnic: string;
  dob: string;
  phone: string;
  gender: string;
  address: string;
}

export interface IqraDbRecord {
  rollNo: string;
  regNo: string;
  fullName: string;
  cnic: string;
  degreeTitle: string;
  department: string;
  cgpa: number;
  creditHours: number;
  graduationDate: string;
  academicStatus: "Completed" | "Incompleted" | "Suspended";
  libraryClearance: ClearanceStatus;
  financeClearance: ClearanceStatus;
  departmentClearance: ClearanceStatus;
}

export interface DocumentUpload {
  id: string;
  title: string;
  fileName: string;
  fileSize: string;
  status: "Unprocessed" | "Processing" | "Processed" | "Error";
  ocrExtracted?: Record<string, any>;
  crossVerifyResult?: {
    isMatch: boolean;
    issues: string[];
  };
  fraudAlerts?: {
    isFlagged: boolean;
    score: number; // 0-100
    indicators: string[];
  };
}

export interface Application {
  id: string;
  studentId: string;
  rollNo: string;
  regNo: string;
  degreeType: DegreeType;
  academicRecord?: IqraDbRecord;
  status: ApplicationStatus;
  step: number; // 1 to 4
  cnicUpload?: DocumentUpload;
  matricUpload?: DocumentUpload;
  interUpload?: DocumentUpload;
  transcriptUpload?: DocumentUpload;
  degreeUpload?: DocumentUpload;
  paymentVerified: boolean;
  paymentMethod?: string;
  paymentTxRef?: string;
  paymentAmount: number;
  verificationHash?: string;
  attestedPdfUrl?: string; // Generated link
  submittedAt?: string;
  reviewedAt?: string;
  comments?: string;
}

export interface FraudAlert {
  id: string;
  applicationId: string;
  studentName: string;
  rollNo: string;
  type: "Signature Mismatch" | "Photoshop Manipulation" | "Metadata Mismatch" | "CGPA Alteration" | "Duplicate Submission" | "Anomalous Record";
  severity: "High" | "Medium" | "Low";
  description: string;
  timestamp: string;
  status: "Open" | "Resolved" | "Ignored";
}

export interface AuditLog {
  id: string;
  actor: string;
  role: "Student" | "Registrar" | "Verification Officer" | "ARIA";
  action: string;
  details: string;
  timestamp: string;
  status: "Success" | "Failed";
}

export interface ChatMessage {
  id: string;
  sender: "user" | "aria";
  text: string;
  timestamp: string;
  isOcrIntervention?: boolean;
}
